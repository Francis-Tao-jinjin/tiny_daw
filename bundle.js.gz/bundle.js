(function(){function r(e,n,t){function o(i,f){if(!n[i]){if(!e[i]){var c="function"==typeof require&&require;if(!f&&c)return c(i,!0);if(u)return u(i,!0);var a=new Error("Cannot find module '"+i+"'");throw a.code="MODULE_NOT_FOUND",a}var p=n[i]={exports:{}};e[i][0].call(p.exports,function(r){var n=e[i][1][r];return o(n||r)},p,p.exports,r,e,n,t)}return n[i].exports}for(var u="function"==typeof require&&require,i=0;i<t.length;i++)o(t[i]);return o}return r})()({1:[function(require,module,exports){
if (typeof Object.create === 'function') {
  // implementation from standard node.js 'util' module
  module.exports = function inherits(ctor, superCtor) {
    ctor.super_ = superCtor
    ctor.prototype = Object.create(superCtor.prototype, {
      constructor: {
        value: ctor,
        enumerable: false,
        writable: true,
        configurable: true
      }
    });
  };
} else {
  // old school shim for old browsers
  module.exports = function inherits(ctor, superCtor) {
    ctor.super_ = superCtor
    var TempCtor = function () {}
    TempCtor.prototype = superCtor.prototype
    ctor.prototype = new TempCtor()
    ctor.prototype.constructor = ctor
  }
}

},{}],2:[function(require,module,exports){
// shim for using process in browser
var process = module.exports = {};

// cached from whatever global is present so that test runners that stub it
// don't break things.  But we need to wrap it in a try catch in case it is
// wrapped in strict mode code which doesn't define any globals.  It's inside a
// function because try/catches deoptimize in certain engines.

var cachedSetTimeout;
var cachedClearTimeout;

function defaultSetTimout() {
    throw new Error('setTimeout has not been defined');
}
function defaultClearTimeout () {
    throw new Error('clearTimeout has not been defined');
}
(function () {
    try {
        if (typeof setTimeout === 'function') {
            cachedSetTimeout = setTimeout;
        } else {
            cachedSetTimeout = defaultSetTimout;
        }
    } catch (e) {
        cachedSetTimeout = defaultSetTimout;
    }
    try {
        if (typeof clearTimeout === 'function') {
            cachedClearTimeout = clearTimeout;
        } else {
            cachedClearTimeout = defaultClearTimeout;
        }
    } catch (e) {
        cachedClearTimeout = defaultClearTimeout;
    }
} ())
function runTimeout(fun) {
    if (cachedSetTimeout === setTimeout) {
        //normal enviroments in sane situations
        return setTimeout(fun, 0);
    }
    // if setTimeout wasn't available but was latter defined
    if ((cachedSetTimeout === defaultSetTimout || !cachedSetTimeout) && setTimeout) {
        cachedSetTimeout = setTimeout;
        return setTimeout(fun, 0);
    }
    try {
        // when when somebody has screwed with setTimeout but no I.E. maddness
        return cachedSetTimeout(fun, 0);
    } catch(e){
        try {
            // When we are in I.E. but the script has been evaled so I.E. doesn't trust the global object when called normally
            return cachedSetTimeout.call(null, fun, 0);
        } catch(e){
            // same as above but when it's a version of I.E. that must have the global object for 'this', hopfully our context correct otherwise it will throw a global error
            return cachedSetTimeout.call(this, fun, 0);
        }
    }


}
function runClearTimeout(marker) {
    if (cachedClearTimeout === clearTimeout) {
        //normal enviroments in sane situations
        return clearTimeout(marker);
    }
    // if clearTimeout wasn't available but was latter defined
    if ((cachedClearTimeout === defaultClearTimeout || !cachedClearTimeout) && clearTimeout) {
        cachedClearTimeout = clearTimeout;
        return clearTimeout(marker);
    }
    try {
        // when when somebody has screwed with setTimeout but no I.E. maddness
        return cachedClearTimeout(marker);
    } catch (e){
        try {
            // When we are in I.E. but the script has been evaled so I.E. doesn't  trust the global object when called normally
            return cachedClearTimeout.call(null, marker);
        } catch (e){
            // same as above but when it's a version of I.E. that must have the global object for 'this', hopfully our context correct otherwise it will throw a global error.
            // Some versions of I.E. have different rules for clearTimeout vs setTimeout
            return cachedClearTimeout.call(this, marker);
        }
    }



}
var queue = [];
var draining = false;
var currentQueue;
var queueIndex = -1;

function cleanUpNextTick() {
    if (!draining || !currentQueue) {
        return;
    }
    draining = false;
    if (currentQueue.length) {
        queue = currentQueue.concat(queue);
    } else {
        queueIndex = -1;
    }
    if (queue.length) {
        drainQueue();
    }
}

function drainQueue() {
    if (draining) {
        return;
    }
    var timeout = runTimeout(cleanUpNextTick);
    draining = true;

    var len = queue.length;
    while(len) {
        currentQueue = queue;
        queue = [];
        while (++queueIndex < len) {
            if (currentQueue) {
                currentQueue[queueIndex].run();
            }
        }
        queueIndex = -1;
        len = queue.length;
    }
    currentQueue = null;
    draining = false;
    runClearTimeout(timeout);
}

process.nextTick = function (fun) {
    var args = new Array(arguments.length - 1);
    if (arguments.length > 1) {
        for (var i = 1; i < arguments.length; i++) {
            args[i - 1] = arguments[i];
        }
    }
    queue.push(new Item(fun, args));
    if (queue.length === 1 && !draining) {
        runTimeout(drainQueue);
    }
};

// v8 likes predictible objects
function Item(fun, array) {
    this.fun = fun;
    this.array = array;
}
Item.prototype.run = function () {
    this.fun.apply(null, this.array);
};
process.title = 'browser';
process.browser = true;
process.env = {};
process.argv = [];
process.version = ''; // empty string to avoid regexp issues
process.versions = {};

function noop() {}

process.on = noop;
process.addListener = noop;
process.once = noop;
process.off = noop;
process.removeListener = noop;
process.removeAllListeners = noop;
process.emit = noop;
process.prependListener = noop;
process.prependOnceListener = noop;

process.listeners = function (name) { return [] }

process.binding = function (name) {
    throw new Error('process.binding is not supported');
};

process.cwd = function () { return '/' };
process.chdir = function (dir) {
    throw new Error('process.chdir is not supported');
};
process.umask = function() { return 0; };

},{}],3:[function(require,module,exports){
(function (setImmediate,clearImmediate){
var nextTick = require('process/browser.js').nextTick;
var apply = Function.prototype.apply;
var slice = Array.prototype.slice;
var immediateIds = {};
var nextImmediateId = 0;

// DOM APIs, for completeness

exports.setTimeout = function() {
  return new Timeout(apply.call(setTimeout, window, arguments), clearTimeout);
};
exports.setInterval = function() {
  return new Timeout(apply.call(setInterval, window, arguments), clearInterval);
};
exports.clearTimeout =
exports.clearInterval = function(timeout) { timeout.close(); };

function Timeout(id, clearFn) {
  this._id = id;
  this._clearFn = clearFn;
}
Timeout.prototype.unref = Timeout.prototype.ref = function() {};
Timeout.prototype.close = function() {
  this._clearFn.call(window, this._id);
};

// Does not start the time, just sets up the members needed.
exports.enroll = function(item, msecs) {
  clearTimeout(item._idleTimeoutId);
  item._idleTimeout = msecs;
};

exports.unenroll = function(item) {
  clearTimeout(item._idleTimeoutId);
  item._idleTimeout = -1;
};

exports._unrefActive = exports.active = function(item) {
  clearTimeout(item._idleTimeoutId);

  var msecs = item._idleTimeout;
  if (msecs >= 0) {
    item._idleTimeoutId = setTimeout(function onTimeout() {
      if (item._onTimeout)
        item._onTimeout();
    }, msecs);
  }
};

// That's not how node.js implements it but the exposed api is the same.
exports.setImmediate = typeof setImmediate === "function" ? setImmediate : function(fn) {
  var id = nextImmediateId++;
  var args = arguments.length < 2 ? false : slice.call(arguments, 1);

  immediateIds[id] = true;

  nextTick(function onNextTick() {
    if (immediateIds[id]) {
      // fn.call() is faster so we optimize for the common use-case
      // @see http://jsperf.com/call-apply-segu
      if (args) {
        fn.apply(null, args);
      } else {
        fn.call(null);
      }
      // Prevent ids from leaking
      exports.clearImmediate(id);
    }
  });

  return id;
};

exports.clearImmediate = typeof clearImmediate === "function" ? clearImmediate : function(id) {
  delete immediateIds[id];
};
}).call(this,require("timers").setImmediate,require("timers").clearImmediate)
},{"process/browser.js":2,"timers":3}],4:[function(require,module,exports){
"use strict";
/**
 * Base class for custom errors.
 *
 * Copyright (C) 2015 Martin Poelstra
 * License: MIT
 */
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    }
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
/**
 * Base class for custom errors, which preserves stack and
 * has correct prototype chain.
 */
var BaseError = /** @class */ (function (_super) {
    __extends(BaseError, _super);
    function BaseError(name, message) {
        var _newTarget = this.constructor;
        var _this = 
        /* istanbul ignore next: internal TypeScript code */
        _super.call(this, message) || this;
        var fixStack = false;
        // This fixes the prototype chain if it's broken (when emitting for ES 5 or lower)
        /* istanbul ignore else: only run tests with ES5 emit for now */
        if (_this.constructor !== _newTarget) {
            // Object.setPrototypeOf is IE>=11 and ES6
            /* istanbul ignore else: only run tests on Node for now */
            if (Object.setPrototypeOf) {
                Object.setPrototypeOf(_this, _newTarget.prototype);
            }
            fixStack = true;
        }
        // This occurs when the error is not thrown but only created in IE
        /* istanbul ignore if: only run tests on Node for now */
        if (!("stack" in _this)) {
            fixStack = true;
        }
        _this.name = name;
        /* istanbul ignore else: only run tests on Node for now */
        if (fixStack) {
            // This.name and this.message must be set correctly in order to fix the stack correctly
            /* istanbul ignore else: only run tests on Node for now */
            if (Error.captureStackTrace) {
                Error.captureStackTrace(_this, _newTarget);
            }
            else {
                var error = new Error(message);
                error.name = name;
                try {
                    throw error;
                }
                catch (error) {
                    _this.stack = error.stack || String(error);
                }
            }
        }
        return _this;
    }
    return BaseError;
}(Error));
exports.default = BaseError;

},{}],5:[function(require,module,exports){
"use strict";
/**
 * Promise implementation in TypeScript.
 *
 * Copyright (C) 2015 Martin Poelstra
 * License: MIT
 */
Object.defineProperty(exports, "__esModule", { value: true });
/* tslint:disable:no-unused-expression */ // prevent errors on `trace && trace(....)`
/* tslint:disable:no-bitwise */ // for flags
var async_1 = require("./async");
var rejections_1 = require("./rejections");
var Trace_1 = require("./Trace");
var util_1 = require("./util");
var trace;
var longTraces = false;
var State;
(function (State) {
    State[State["Pending"] = 0] = "Pending";
    State[State["Fulfilled"] = 1] = "Fulfilled";
    State[State["Rejected"] = 2] = "Rejected";
})(State || (State = {}));
/**
 * Bit flags about a Promise's internal state.
 */
var Flags;
(function (Flags) {
    Flags[Flags["RejectionHandled"] = 1] = "RejectionHandled";
    Flags[Flags["UnhandledRejectionNotified"] = 2] = "UnhandledRejectionNotified";
})(Flags || (Flags = {}));
function internalResolver(fulfill, reject) {
    /* no-op, sentinel value */
}
internalResolver(undefined, undefined); // just for code coverage...
function noop() {
    /* no-op */
}
var getThenError = {
    error: undefined,
};
function wrapNonError(a) {
    // This is basically a marker for the places where we need to check
    // handling of errors for .error() support.
    // A no-op for now.
    return a;
}
var dummyDoneTrace = new Trace_1.default();
/**
 * Currently unwrapping promise, while running one of its then-callbacks.
 * Used to set the source of newly created promises.
 * We guarantee that at most one callback of a then() is running at any time.
 */
var unwrappingPromise;
var promiseIdCounter = 0;
/**
 * Fast, robust, type-safe promise implementation.
 */
var Promise = /** @class */ (function () {
    /**
     * Create new Promise.
     *
     * Pass a callback that will receive a `resolve()` and `reject()` function
     * to seal the promise's fate.
     *
     * @param  resolver Called with resolve and reject functions
     */
    function Promise(resolver) {
        var _this = this;
        this._id = promiseIdCounter++;
        this._state = 0 /* Pending */;
        this._result = undefined; // Can be fulfillment value or rejection reason
        this._handlers = undefined;
        this._flags = 0;
        this._trace = undefined;
        trace && trace(this, "construct");
        if (longTraces) {
            this._trace = new Trace_1.default(Promise);
            if (unwrappingPromise) {
                this._setSource(unwrappingPromise);
            }
        }
        if (resolver === internalResolver) {
            // Internally created promises pass 'internalResolver', signalling
            // that resolving will be done by calling private methods on the
            // Promise. This saves having to create 2 closures.
            return;
        }
        if (typeof resolver !== "function") {
            throw new TypeError("Promise resolver is not a function");
        }
        var called = false;
        try {
            resolver(function (y) {
                if (called) {
                    // 2.3.3.3.3: If both `resolvePromise` and `rejectPromise` are called,
                    // or multiple calls to the same argument are made, the first call
                    // takes precedence, and any further calls are ignored.
                    return;
                }
                // 2.3.3.3.1: If/when `resolvePromise` is called with value `y`,
                // run `[[Resolve]](promise, y)`
                called = true;
                _this._resolve(y);
            }, function (r) {
                if (called) {
                    // 2.3.3.3.3: If both `resolvePromise` and `rejectPromise` are called,
                    // or multiple calls to the same argument are made, the first call
                    // takes precedence, and any further calls are ignored.
                    return;
                }
                // 2.3.3.3.2: If/when `rejectPromise` is called with reason `r`,
                // reject `promise` with `r`
                called = true;
                _this._reject(wrapNonError(r));
            });
        }
        catch (e) {
            // 2.3.3.3.4: If calling `then` throws an exception `e`,
            // 2.3.3.3.4.1: If `resolvePromise` or `rejectPromise` have been called, ignore it.
            if (!called) {
                // 2.3.3.3.4.2: Otherwise, reject `promise` with `e` as the reason.
                called = true;
                this._reject(wrapNonError(e));
            }
        }
    }
    /**
     * Run either `onFulfilled` or `onRejected` callbacks when the promise is
     * resolved. Returns another promise for the return value of such a
     * callback.
     *
     * The callback will always be called at most once, and always
     * asynchronously (i.e. some time after e.g. the `resolver` passed to the
     * constructor has resolved the promise).
     *
     * Any error thrown or rejected promise returned from a callback will cause
     * the returned promise to be rejected with that error.
     *
     * If either or both callbacks are missing, the fulfillment or rejection is
     * passed on unmodified.
     *
     * Use `.catch(onRejected)` instead of `.then(undefined, onRejected)` for
     * stronger typing, better readability, and more functionality (predicates).
     *
     * @param onFulfilled Callback called with promise's fulfillment
     *                    value iff promise is fulfilled. Callback can return
     *                    another value or promise for a value.
     * @param onRejected  Optional callback called with promise's rejection
     *                    reason iff promise is rejected. Callback can return
     *                    another value or promise for a value.
     * @return Promise for value returned by either of the callbacks
     */
    Promise.prototype.then = function (onFulfilled, onRejected) {
        trace && trace(this, "then(" + typeof onFulfilled + ", " + typeof onRejected + ")");
        if (this._state === 1 /* Fulfilled */ && typeof onFulfilled !== "function" ||
            this._state === 2 /* Rejected */ && typeof onRejected !== "function") {
            // Optimization: handler is short-circuited, so pass the result (value/rejection)
            // through unmodified.
            // The typecast is safe, because we either have a fulfillment value
            // but no handler that could change the type, or a rejection without a
            // handler that could change it, so R === T in this case.
            // TODO: verify whether longTraces etc still work as expected
            return this;
        }
        // Construct new Promise, but use subclassed constructor, if any
        var slave = new (Object.getPrototypeOf(this).constructor)(internalResolver);
        slave._setSource(this);
        this._enqueue(onFulfilled, onRejected, slave, undefined);
        return slave;
    };
    /**
     * Run either `onFulfilled` or `onRejected` callbacks when the promise is
     * resolved. If the callback throws an error or the returned value resolves
     * to a rejection, the library will (asynchronously) throw an
     * `UnhandledRejectionError` with that error.
     *
     * The callback will always be called at most once, and always
     * asynchronously (i.e. some time after e.g. the `resolver` passed to the
     * constructor has resolved the promise).
     *
     * @param onFulfilled Optional callback called with promise's fulfillment
     *                    value iff promise is fulfilled. Any error thrown or
     *                    rejection returned will cause an UnhandledRejectionError
     *                    to be thrown.
     * @param onRejected  Optional callback called with promise's rejection
     *                    reason iff promise is rejected. Any error thrown or
     *                    rejection returned will cause an UnhandledRejectionError
     *                    to be thrown.
     */
    Promise.prototype.done = function (onFulfilled, onRejected) {
        trace && trace(this, "done(" + typeof onFulfilled + ", " + typeof onRejected + ")");
        if (this._state === 1 /* Fulfilled */ && typeof onFulfilled !== "function") {
            return;
        }
        var doneTrace = dummyDoneTrace;
        if (longTraces) {
            doneTrace = new Trace_1.default();
            if (this._trace) {
                doneTrace.setSource(this._trace);
            }
        }
        this._enqueue(onFulfilled, onRejected, undefined, doneTrace);
    };
    /**
     * Catch only errors that match predicate in case promise is rejected.
     * Predicate can be an Error (sub-)class, array of Error classes, or a
     * function that can return true to indicate a match.
     *
     * The returned promise is resolved with the output of the callback, so it
     * is possible to re-throw the error, but also to return a 'replacement'
     * value that should be used instead.
     *
     * @param predicate   Optional Error class, array of Error classes or match
     *                    function
     * @param onRejected  Callback called with promise's rejection reason iff
     *                    promise is rejected. Callback can return another value
     *                    or promise for a value.
     * @return Promise for original value, or 'replaced' value in case of error
     */
    Promise.prototype.catch = function () {
        if (arguments.length === 1) {
            var onRejected = arguments[0];
            return this.then(undefined, onRejected);
        }
        else {
            var predicate_1 = arguments[0];
            var onRejected_1 = arguments[1];
            return this.then(undefined, function (reason) {
                var match = false;
                if (typeof predicate_1 === "function") {
                    if (predicate_1.prototype instanceof Error || predicate_1 === Error) {
                        match = reason instanceof predicate_1;
                    }
                    else {
                        match = predicate_1(reason);
                    }
                }
                else if (Array.isArray(predicate_1)) {
                    for (var _i = 0, predicate_2 = predicate_1; _i < predicate_2.length; _i++) {
                        var p = predicate_2[_i];
                        if (reason instanceof p) {
                            match = true;
                            break;
                        }
                    }
                }
                else {
                    throw new TypeError("invalid predicate to .catch(), got " + typeof predicate_1);
                }
                if (match) {
                    return onRejected_1(reason);
                }
                return Promise.reject(reason);
            });
        }
    };
    /**
     * Asynchronous equivalent of try { } finally { }.
     *
     * Runs `handler` when promise resolves (fulfilled or rejected).
     * Handler is passed the current promise (which is guaranteed to be
     * resolved), and can be interrogated with e.g. `isFulfilled()`, `.value()`,
     * etc.
     *
     * When `handler` returns `undefined` or its promise is fulfilled, the
     * promise from `finally()` is resolved to the original promise's resolved
     * value or rejection reason.
     * If `handler` throws an error or returns a rejection, the result of
     * `finally()` will be rejected with that error.
     *
     * Example:
     * someLenghtyOperation().finally((result) => {
     *   if (result.isFulfilled()) {
     *     console.log("succeeded");
     *   } else {
     *     console.log("failed", result.reason());
     *   }
     * });
     *
     * @param  handler Callback called with promise when it is resolved.
     * @return promise with same value/reason as this one, after `handler`'s
     *         result (if any) has been fulfilled, or a promise rejected with
     *         `handler`'s error if it threw one or returned a rejection.
     */
    Promise.prototype.finally = function (handler) {
        var _this = this;
        var runner = function () { return handler(_this); };
        return this.then(runner, runner).return(this);
    };
    /**
     * Return `true` when promise is fulfilled, `false` otherwise.
     *
     * @return `true` when promise is fulfilled, `false` otherwise.
     */
    Promise.prototype.isFulfilled = function () {
        return this._state === 1 /* Fulfilled */;
    };
    /**
     * Return `true` when promise is rejected, `false` otherwise.
     *
     * Note: this does not consider the rejection to be 'handled', if
     * it is rejected.
     *
     * @return `true` when promise is rejected, `false` otherwise.
     */
    Promise.prototype.isRejected = function () {
        return this._state === 2 /* Rejected */;
    };
    /**
     * Return `true` when promise is pending (may be resolved to another pending
     * promise), `false` otherwise.
     *
     * @return `true` when promise is pending (may be resolved to another pending
     *         promise), `false` otherwise.
     */
    Promise.prototype.isPending = function () {
        return this._state === 0 /* Pending */;
    };
    /**
     * Return fulfillment value if fulfilled, otherwise throws an error.
     *
     * @return Fulfillment value if fulfilled, otherwise throws an error.
     */
    Promise.prototype.value = function () {
        if (!this.isFulfilled()) {
            throw new Error("Promise is not fulfilled");
        }
        return this._result;
    };
    /**
     * Return rejection value if rejected, otherwise throws an error.
     *
     * Note: this does not consider the rejection to be 'handled', if
     * it is rejected. To do so, explicitly call e.g.
     * `.suppressUnhandledRejections()`.
     *
     * @return Rejection value if rejected, otherwise throws an error.
     */
    Promise.prototype.reason = function () {
        if (!this.isRejected()) {
            throw new Error("Promise is not rejected");
        }
        return this._result;
    };
    /**
     * Prevent this promise from throwing a PossiblyUnhandledRejection in
     * case it becomes rejected. Useful when the rejection will be handled later
     * (i.e. after the current 'tick'), or when the rejection is to be ignored
     * completely.
     *
     * This is equivalent to calling `.catch(() => {})`, but more efficient.
     *
     * Note: any derived promise (e.g. by calling `.then(cb)`) causes a new
     * promise to be created, which can still cause the rejection to be thrown.
     *
     * Note: if the rejection was already notified, the rejection-handled handler
     * will be called.
     */
    Promise.prototype.suppressUnhandledRejections = function () {
        this._setRejectionHandled();
    };
    /**
     * @return A human-readable representation of the promise and its status.
     */
    Promise.prototype.inspect = function () {
        return this.toString();
    };
    /**
     * @return A human-readable representation of the promise and its status.
     */
    Promise.prototype.toString = function () {
        var state;
        switch (this._state) {
            case 0 /* Pending */:
                state = "pending";
                break;
            case 1 /* Fulfilled */:
                state = "fulfilled";
                break;
            case 2 /* Rejected */:
                state = "rejected";
                break;
            default: state = "unknown";
        }
        return "[Promise " + this._id + ": " + state + "]";
    };
    /**
     * Create a promise that resolves with the same value of this promise, after
     * `ms` milliseconds. The timer will start when the current promise is
     * resolved.
     * If the current promise is rejected, the resulting promise is also
     * rejected, without waiting for the timer.
     *
     * @param ms Number of milliseconds to wait before resolving
     * @return Promise that fulfills `ms` milliseconds after this promise fulfills
     */
    Promise.prototype.delay = function (ms) {
        return this.then(function (value) {
            return new Promise(function (resolve) {
                setTimeout(function () { return resolve(value); }, ms);
            });
        });
    };
    /**
     * Return a promise that resolves to `value` after this promise is
     * fulfilled.
     * Returned promise is rejected if this promise is rejected.
     *
     * Equivalent to `.then(() => value)`.
     *
     * @param value Value or promise for value of returned promise
     * @return Promise resolved to value after this promise fulfills
     */
    Promise.prototype.return = function (value) {
        if (value === undefined) {
            // In TypeScript, we often need to 'force' a promise to become a
            // void promise, so this is a common case. Prevents the closure.
            // (Note: the any cast is just because TS assumes were going to
            // return an R, but we're in fact going to return a void.)
            return this.then(noop);
        }
        return this.then(function () { return value; });
    };
    /**
     * Return a promise that is rejected with `reason` after this promise is
     * fulfilled.
     * If this promise is rejected, returned promise will rejected with that
     * error instead.
     *
     * Equivalent to `.then(() => { throw value; })`.
     *
     * @param reason Error reason to reject returned promise with
     * @return Promise rejected with `reason` after this promise fulfills
     */
    Promise.prototype.throw = function (reason) {
        return this.then(function () { return Promise.reject(reason); });
    };
    Promise.prototype._setSource = function (source) {
        if (!this._trace || !source._trace) {
            return;
        }
        this._trace.setSource(source._trace);
    };
    Promise.prototype._resolve = function (x) {
        // 2.1.2.1 When fulfilled, a promise must not transition to any other state.
        // 2.1.3.1 When rejected, a promise must not transition to any other state.
        util_1.assert(this._state === 0 /* Pending */);
        if (!x) {
            // Shortcut for falsy values, most notably void-Promises
            // 2.3.4: If `x` is not an object or function, fulfill `promise` with `x`
            this._fulfill(x);
            return;
        }
        // 2.3.1: If promise and x refer to the same object, reject promise with a TypeError as the reason.
        if (this === x) {
            this._reject(new TypeError("cannot resolve Promise to self"));
            return;
        }
        // 2.3.2: If `x` is a promise, adopt its state
        if (x instanceof Promise) {
            x._setSource(this);
            x._setRejectionHandled(); // we take over responsibility now
            if (x._state === 0 /* Pending */) {
                // 2.3.2.1: If `x` is pending, `promise` must remain pending until `x` is fulfilled or rejected.
                this._followPromise(x);
            }
            else if (x._state === 1 /* Fulfilled */) {
                // 2.3.2.2: If/when `x` is fulfilled, fulfill `promise` with the same value.
                this._fulfill(x._result);
            }
            else {
                // 2.3.2.3: If/when `x` is rejected, reject `promise` with the same reason.
                this._reject(x._result);
            }
            return;
        }
        // 2.3.3: Otherwise, if `x` is an object or function,
        if (typeof x === "object" || typeof x === "function") {
            // 2.3.3.1: Let `then` be `x.then`
            var then = this._tryGetThen(x);
            // 2.3.3.2: If retrieving the property `x.then` results in a thrown
            // exception `e`, reject `promise` with `e` as the reason.
            if (then === getThenError) {
                this._reject(wrapNonError(getThenError.error));
                return;
            }
            // 2.3.3.3: If `then` is a function, call it with `x` as `this`,
            //          first argument `resolvePromise`, and second argument `rejectPromise`
            if (typeof then === "function") {
                this._followThenable(x, then);
                return;
            }
            // 2.3.3.4: If `then` is not a function, fulfill promise with `x`
        }
        // 2.3.4: If `x` is not an object or function, fulfill `promise` with `x`
        this._fulfill(x);
    };
    Promise.prototype._tryGetThen = function (x) {
        try {
            // 2.3.3.1: Let `then` be `x.then`
            var then = x.then;
            return then;
        }
        catch (e) {
            // 2.3.3.2: If retrieving the property `x.then` results in a thrown
            // exception `e`, reject `promise` with `e` as the reason.
            getThenError.error = e;
            return getThenError;
        }
    };
    Promise.prototype._fulfill = function (value) {
        // 2.1.2.1 When fulfilled, a promise must not transition to any other state.
        // 2.1.3.1 When rejected, a promise must not transition to any other state.
        util_1.assert(this._state === 0 /* Pending */);
        trace && trace(this, "_fulfill(" + typeof value + ")");
        // 2.1.2.2 When fulfilled, a promise must have a value, which must not change.
        this._state = 1 /* Fulfilled */;
        this._result = value;
        this._flush();
    };
    Promise.prototype._reject = function (reason) {
        // 2.1.2.1 When fulfilled, a promise must not transition to any other state.
        // 2.1.3.1 When rejected, a promise must not transition to any other state.
        util_1.assert(this._state === 0 /* Pending */);
        trace && trace(this, "_reject(" + reason + ")");
        // 2.1.3.2 When rejected, a promise must have a reason, which must not change.
        this._state = 2 /* Rejected */;
        this._result = reason;
        if (this._trace && this._result instanceof Error && !this._result.trace) {
            var stackTrace_1 = this._trace;
            this._result.trace = stackTrace_1;
            // TODO: Meh, this always accesses '.stack', which is supposed to be expensive
            var originalStack_1 = this._result.stack;
            // Stack may be undefined if e.g. a Stack Overflow occurred
            if (originalStack_1) {
                Object.defineProperty(this._result, "stack", {
                    enumerable: false,
                    get: function () { return originalStack_1 + "\n  from Promise at:\n" + stackTrace_1.inspect(); },
                });
            }
        }
        // Schedule check for possibly unhandled rejections, if not already handled
        if (!(this._flags & 1 /* RejectionHandled */)) {
            async_1.default.enqueueIdle(Promise._unhandledRejectionChecker, this);
        }
        this._flush();
    };
    Promise.prototype._setRejectionHandled = function () {
        if (!(this._flags & 1 /* RejectionHandled */) && (this._flags & 2 /* UnhandledRejectionNotified */)) {
            // The rejection has been declared as PossiblyUnhandledRejection
            // before, so declare it handled again.
            async_1.default.enqueue(Promise._onPossiblyUnhandledRejectionHandledHandler, this);
        }
        this._flags |= 1 /* RejectionHandled */;
        trace && trace(this, "rejectionHandled");
    };
    Promise.prototype._doCheckUnhandledRejection = function () {
        // We get here if this promise is rejected, and wasn't handled at the
        // time it was rejected. Emit a PossiblyUnhandledRejection in case
        // it still isn't handled yet.
        if (!(this._flags & 1 /* RejectionHandled */) && !(this._flags & 2 /* UnhandledRejectionNotified */)) {
            this._flags |= 2 /* UnhandledRejectionNotified */;
            async_1.default.enqueue(Promise._onPossiblyUnhandledRejectionHandler, this);
        }
    };
    Promise.prototype._followPromise = function (slave) {
        // 2.1.2.1 When fulfilled, a promise must not transition to any other state.
        // 2.1.3.1 When rejected, a promise must not transition to any other state.
        util_1.assert(this._state === 0 /* Pending */);
        trace && trace(this, "_follow([Promise " + slave._id + "])");
        slave._enqueue(undefined, undefined, this, undefined);
    };
    Promise.prototype._followThenable = function (slave, then) {
        var _this = this;
        // 2.1.2.1 When fulfilled, a promise must not transition to any other state.
        // 2.1.3.1 When rejected, a promise must not transition to any other state.
        util_1.assert(this._state === 0 /* Pending */);
        trace && trace(this, "_follow([Thenable])");
        var called = false;
        try {
            // 2.3.3.3: If `then` is a function, call it with `x` as `this`,
            //          first argument `resolvePromise`, and second argument `rejectPromise`
            then.call(slave, function (y) {
                if (called) {
                    // 2.3.3.3.3: If both `resolvePromise` and `rejectPromise` are called,
                    // or multiple calls to the same argument are made, the first call
                    // takes precedence, and any further calls are ignored.
                    return;
                }
                // 2.3.3.3.1: If/when `resolvePromise` is called with value `y`,
                // run `[[Resolve]](promise, y)`
                called = true;
                _this._resolve(y);
            }, function (r) {
                if (called) {
                    // 2.3.3.3.3: If both `resolvePromise` and `rejectPromise` are called,
                    // or multiple calls to the same argument are made, the first call
                    // takes precedence, and any further calls are ignored.
                    return;
                }
                // 2.3.3.3.2: If/when `rejectPromise` is called with reason `r`,
                // reject `promise` with `r`
                called = true;
                _this._reject(wrapNonError(r));
            });
        }
        catch (e) {
            // 2.3.3.3.4: If calling `then` throws an exception `e`,
            // 2.3.3.3.4.1: If `resolvePromise` or `rejectPromise` have been called, ignore it.
            if (!called) {
                // 2.3.3.3.4.2: Otherwise, reject `promise` with `e` as the reason.
                called = true;
                this._reject(wrapNonError(e));
            }
        }
    };
    Promise.prototype._enqueue = function (onFulfilled, onRejected, slave, done) {
        var h = {
            promise: this,
            onFulfilled: onFulfilled,
            onRejected: onRejected,
            slave: slave,
            done: done,
        };
        if (this._state !== 0 /* Pending */) {
            async_1.default.enqueue(Promise._unwrapper, h);
        }
        else {
            if (!this._handlers) {
                this._handlers = [h];
            }
            else {
                var i = this._handlers.length;
                this._handlers[i] = h;
            }
        }
        this._setRejectionHandled();
    };
    /**
     * Schedule any pending .then()/.done() callbacks and follower-promises to
     * be called/resolved.
     * Clears our queue, any callbacks/followers attached after this will be
     * scheduled without going through our handlers queue.
     */
    Promise.prototype._flush = function () {
        if (!this._handlers) {
            return;
        }
        var i = 0;
        var h = this._handlers;
        var l = h.length;
        this._handlers = undefined;
        while (i < l) {
            // Note: we enqueue every single callback/follower separately,
            // because e.g. .done() might throw and we need to ensure we can
            // continue after that. async handles that for us.
            // And because the queue needs to be processed in-order, we can't
            // 'filter' the non-callback operations out either.
            async_1.default.enqueue(Promise._unwrapper, h[i++]);
        }
    };
    /**
     * 'Unwrap' a promise handler, i.e. call a .then()/.done() callback, or
     * resolve a promise that's following us.
     * @param handler The handler being processed
     */
    Promise.prototype._unwrap = function (handler) {
        var callback = this._state === 1 /* Fulfilled */ ? handler.onFulfilled : handler.onRejected;
        if (handler.done) {
            // Unwrap .done() callbacks
            trace && trace(this, "_unwrap()");
            if (typeof callback !== "function") {
                // No callback: if we ended in a rejection, throw it, otherwise
                // all was good.
                if (this._state === 2 /* Rejected */) {
                    Promise._onUnhandledRejectionHandler(this._result, handler.done);
                }
                return;
            }
            util_1.assert(!unwrappingPromise);
            unwrappingPromise = this;
            try {
                var result = callback(this._result);
                if (result) { // skips the common cases like `undefined`
                    // May be a thenable, need to start following it...
                    var p = (result instanceof Promise) ? result : Promise.resolve(result);
                    p.done(); // Ensure it throws as soon as it's rejected
                }
                unwrappingPromise = undefined;
            }
            catch (e) {
                unwrappingPromise = undefined;
                Promise._onUnhandledRejectionHandler(e, handler.done);
            }
            return;
        }
        // Unwrap .then() callbacks, or resolve 'parent' promise
        //
        // Three scenarios are handled here:
        // 1. An onFulfilled callback was registered and promise is fulfilled,
        //    or onRejected callback was registered and promise is rejected
        //    -> callback is a function, slave is the promise that was returned
        //       from the .then() call, so resolve slave with outcome of callback
        // 2. An onFulfilled callback was registered but promise is rejected,
        //    or onRejected callback was registered but promise is fulfilled
        //    -> callback is not a function (typically `undefined`), slave is
        //       promise that was returned from the .then() call, so resolve it
        //       with our own result (thereby 'skipping' the .then())
        // 3. Another promise attached itself on our 'callback queue' to be
        //    resolved when we do (i.e. its fate is determined by us)
        //    -> callbacks will both be undefined, slave is that other promise
        //       that wants to be resolved with our result
        var slave = handler.slave;
        trace && trace(this, "_unwrap(" + slave._id + ")");
        if (typeof callback === "function") {
            // Case 1
            util_1.assert(!unwrappingPromise);
            unwrappingPromise = slave;
            try {
                // 2.2.5 handlers must be called as functions
                slave._resolve(callback(this._result));
            }
            catch (e) {
                slave._reject(wrapNonError(e));
            }
            unwrappingPromise = undefined;
        }
        else {
            // Case 2 and 3
            if (this._state === 1 /* Fulfilled */) {
                slave._fulfill(this._result);
            }
            else {
                slave._reject(this._result);
            }
        }
    };
    /**
     * Create an immediately resolved promise (in case of a 'normal' value), or
     * a promise that 'follows' another `Thenable` (e.g. a Promise from another
     * library).
     *
     * @param value Value (or Thenable for value) for returned promise
     * @return Promise resolved to `value`
     */
    Promise.resolve = function (value) {
        var p = new Promise(internalResolver);
        p._resolve(value);
        return p;
    };
    /**
     * Create an immediately rejected promise.
     *
     * Note: to create a rejected promise of a certain type, use e.g.
     * `Promise.reject<number>(myError)`
     *
     * @param reason Error object to set rejection reason
     * @return Promise resolved to rejection `reason`
     */
    Promise.reject = function (reason) {
        var p = new Promise(internalResolver);
        p._reject(reason);
        return p;
    };
    /**
     * Return a promise for an array of all resolved input promises (or values).
     * If any of the input promises is rejected, the returned promise is
     * rejected with that reason.
     * When passing an empty array, the promises is immediately resolved to an
     * empty array.
     *
     * @param thenables Array of values or promises for them
     * @return promise that resolves with array of all resolved values
     */
    Promise.all = function (thenables) {
        return new Promise(function (resolve, reject) {
            util_1.assert(Array.isArray(thenables), "thenables must be an Array");
            if (thenables.length === 0) {
                resolve([]);
                return;
            }
            var result = new Array(thenables.length);
            var remaining = thenables.length;
            for (var i = 0; i < thenables.length; i++) {
                follow(thenables[i], i);
            }
            function follow(t, index) {
                var slave = t instanceof Promise ? t : Promise.resolve(t);
                slave.done(function (v) {
                    result[index] = v;
                    remaining--;
                    if (remaining === 0) {
                        resolve(result);
                    }
                }, function (reason) { return reject(reason); });
            }
        });
    };
    /**
     * Return a promise that resolves to the fulfillment or rejection of the
     * first input promise that resolves.
     * When passing an empty array, the promise will never resolve.
     *
     * @param thenables Array of values or promises for them
     * @return promise that resolves to first resolved input promise
     */
    Promise.race = function (thenables) {
        return new Promise(function (resolve, reject) {
            util_1.assert(Array.isArray(thenables), "thenables must be an Array");
            for (var _i = 0, thenables_1 = thenables; _i < thenables_1.length; _i++) {
                var t = thenables_1[_i];
                var slave = t instanceof Promise ? t : Promise.resolve(t);
                Promise.resolve(slave).done(resolve, reject);
            }
        });
    };
    /**
     * Create tuple of a promise and its resolve and reject functions.
     *
     * It is generally better (and slightly faster) to use the Promise
     * constructor to create a promise, as that will also catch any exception
     * thrown while running the resolver.
     *
     * A Deferred can be useful in some scenarios though, e.g. when working with
     * timers, protocol request/response pairs, etc.
     *
     * @return Deferred object, containing unresolved promise and its
     *         resolve/reject functions
     */
    Promise.defer = function () {
        var resolve;
        var reject;
        var p = new Promise(function (res, rej) {
            resolve = res;
            reject = rej;
        });
        return {
            promise: p,
            reject: reject,
            resolve: resolve,
        };
    };
    /**
     * Create a promise that resolves to the given value (or promise for a
     * value) after `ms` milliseconds. The timer will start when the given value
     * is resolved.
     * If the input value is a rejected promise, the resulting promise is also
     * rejected, without waiting for the timer.
     *
     * @param value Value or promise for value to be delayed
     * @param ms Number of milliseconds to wait before resolving
     * @return Promise that fulfills `ms` milliseconds after given (promise for)
     *         value is fulfilled
     */
    Promise.delay = function () {
        var args = [];
        for (var _i = 0; _i < arguments.length; _i++) {
            args[_i] = arguments[_i];
        }
        if (arguments[1] === undefined) {
            // delay(ms)
            var ms_1 = arguments[0];
            return new Promise(function (resolve) {
                setTimeout(resolve, ms_1);
            });
        }
        // delay(value, ms)
        return Promise.resolve(arguments[0]).delay(arguments[1]);
    };
    /**
     * Register a callback to be called whenever a rejected Promise reaches a `.done()` call
     * without `rejectHandler` argument, or either of the `.done()` callbacks itself
     * throws/rejects.
     *
     * This is similar to Node's `unhandledException` event, in that it is guaranteed to be
     * an error, because the programmer explicitly marked the chain with `.done()`.
     *
     * Node also has an `unhandledRejection` event, which is actually closer to ts-promise's
     * `onPossiblyUnhandledRejection` handler.
     *
     * The default handler will throw an `UnhandledRejection` error, which contains the
     * original reason of the rejection.
     * In Node, if you don't have an `unhandledException` event handler, that will cause your
     * program to terminate after printing the error.
     * When overriding the default handler, it is recommended to keep a similar behavior,
     * as your program is likely in an unknown state.
     *
     * @see onPossiblyUnhandledRejection
     *
     * @param handler Callback called with the rejection reason (typically an `Error`), and a
     *                `Trace` to the `.done()` call that terminated the chain. Call e.g.
     *                `trace.inspect()` to get the full trace.
     *                If `true` is given, the default handler is installed.
     *                If `false` is given, a no-op handler is installed.
     */
    Promise.onUnhandledRejection = function (handler) {
        if (handler === true) {
            Promise._onUnhandledRejectionHandler = rejections_1.defaultUnhandledRejectionHandler;
        }
        else if (handler === false) {
            Promise._onUnhandledRejectionHandler = noop;
        }
        else if (typeof handler !== "function") {
            throw new TypeError("invalid handler: boolean or function expected");
        }
        else {
            Promise._onUnhandledRejectionHandler = handler;
        }
    };
    /**
     * Register a callback to be called whenever a rejected Promise is not handled
     * by any `.catch()` (or second argument to `.then()`) at the end of one turn of the
     * event loop.
     *
     * Note that such a rejected promise may be handled later (by e.g. calling `.catch(() => {})`
     * on it). In that case, a subsequent call to an `onPossiblyUnhandledRejectionHandled` callback
     * will be made.
     *
     * This mechanism is equivalent to Node's `unhandledRejection` event.
     *
     * The default handler will:
     * - emit Node's `unhandledRejection` event if present, or
     * - emit an `unhandledrejection` (note small R) `PromiseRejectionEvent` on `window` or `self` if present, or
     * - log the rejection using `console.warn()`.
     *
     * Note: when attaching an `unhandledrejection` handler in the browser, make sure to
     * call `event.preventDefault()` to prevent ts-promise's default fallback logging.
     *
     * @see onUnhandledRejection
     * @see onPossiblyUnhandledRejectionHandled
     *
     * @param handler Callback called with the (so-far) unhandled rejected promise.
     *                If `true` is given, the default handler is installed.
     *                If `false` is given, a no-op handler is installed.
     */
    Promise.onPossiblyUnhandledRejection = function (handler) {
        if (handler === true) {
            Promise._onPossiblyUnhandledRejectionHandler = rejections_1.defaultPossiblyUnhandledRejectionHandler;
        }
        else if (handler === false) {
            Promise._onPossiblyUnhandledRejectionHandler = noop;
        }
        else if (typeof handler !== "function") {
            throw new TypeError("invalid handler: boolean or function expected");
        }
        else {
            Promise._onPossiblyUnhandledRejectionHandler = handler;
        }
    };
    /**
     * Register a callback to be called whenever a rejected promise previously reported as
     * 'possibly unhandled', now becomes handled.
     *
     * This mechanism is equivalent to Node's `rejectionHandled` event.
     *
     * The default handler will emit Node's `rejectionHandled` event if present, or emit a
     * `rejectionhandled` (note small R) event on `window` (or `self`) if present.
     *
     * @see onPossiblyUnhandledRejection
     *
     * @param handler Callback called with a rejected promise that was previously reported as
     *                'possibly unhandled'.
     *                If `true` is given, the default handler is installed.
     *                If `false` is given, a no-op handler is installed.
     */
    Promise.onPossiblyUnhandledRejectionHandled = function (handler) {
        if (handler === true) {
            Promise._onPossiblyUnhandledRejectionHandledHandler = rejections_1.defaultPossiblyUnhandledRejectionHandledHandler;
        }
        else if (handler === false) {
            Promise._onPossiblyUnhandledRejectionHandledHandler = noop;
        }
        else if (typeof handler !== "function") {
            throw new TypeError("invalid handler: boolean or function expected");
        }
        else {
            Promise._onPossiblyUnhandledRejectionHandledHandler = handler;
        }
    };
    /**
     * Enable or disable long stack trace tracking on promises.
     *
     * This allows tracing a promise chain through the various asynchronous
     * actions in a program. For example, when a promise is rejected, the last
     * few locations of any preceding promises are included in the error's stack
     * trace.
     *
     * Note: it is possible to enable/disable long tracing at runtime.
     *
     * When chaining off of a promise that was created while tracing was enabled
     * (e.g. through `.then()`), all children will also have long traces, even
     * when tracing is turned off. This allows to trace just some promise paths.
     *
     * Tracing is disabled by default as it incurs a memory and performance
     * overhead, although it's still faster with tracing than some major
     * promise libraries without tracing, so don't worry too much about it.
     *
     * @param enable Set to true to enable long traces, false to disable
     */
    Promise.setLongTraces = function (enable) {
        longTraces = enable;
    };
    /**
     * Set trace function that is called for internal state changes of a
     * promise.
     * Call with `undefined` or `null` to disable such tracing (this is the
     * default).
     *
     * @param tracer Callback called for various stages during lifetime of a promise
     */
    // tslint:disable-next-line:no-null-keyword
    Promise.setTracer = function (tracer) {
        if (typeof tracer === "function") {
            trace = tracer;
        }
        else {
            trace = undefined;
        }
    };
    /**
     * Recursively flush the async callback queue until all `.then()` and
     * `.done()` callbacks for fulfilled and rejected Promises have been called.
     * Useful in e.g. unit tests to advance program state to the next 'tick'.
     *
     * Note that if e.g. `.done()` encounters a rejected promise, `flush()` will
     * immediately throw an error (e.g. `UnhandledRejectionError`).
     * It is safe to call `flush()` again afterwards, but it will also be called
     * automatically by the async queue on the next 'real' tick.
     *
     * It is an error to call `flush()` while it is already running (e.g. from
     * a `.then()` callback).
     */
    Promise.flush = function () {
        async_1.default.flush();
    };
    /**
     * Helper for unwrapping promise handler.
     * It's not a closure so it's cheap to schedule, and because it directly
     * calls the _unwrap() method on a promise, it's (way) faster than having to
     * use e.g. .call().
     * @param handler The handler being processed
     */
    Promise._unwrapper = function (handler) {
        handler.promise._unwrap(handler);
    };
    /**
     * Helper for checking for possibly unhandled rejections.
     * @param promise The Promise to check
     */
    Promise._unhandledRejectionChecker = function (promise) {
        promise._doCheckUnhandledRejection();
    };
    return Promise;
}());
exports.Promise = Promise;
// Install default rejection handlers
Promise.onUnhandledRejection(true);
Promise.onPossiblyUnhandledRejection(true);
Promise.onPossiblyUnhandledRejectionHandled(true);
exports.default = Promise;

},{"./Trace":7,"./async":8,"./rejections":11,"./util":12}],6:[function(require,module,exports){
"use strict";
/**
 * Helper class for capturing stack traces.
 *
 * Copyright (C) 2015 Martin Poelstra
 * License: MIT
 */
Object.defineProperty(exports, "__esModule", { value: true });
// TODO:
// - test/make it work in non-V8
// - parse stacks into platform-independent object-arrays
var hasStacks = (typeof Error.captureStackTrace === "function");
var Stack = /** @class */ (function () {
    function Stack(ignoreUntil) {
        if (ignoreUntil === void 0) { ignoreUntil = Stack; }
        /* istanbul ignore else */ // TODO: remove when testing for non-V8
        if (hasStacks) {
            Error.captureStackTrace(this, ignoreUntil);
        }
        else {
            this.stack = "dummy\n<no trace>";
        }
    }
    Stack.prototype.inspect = function () {
        var lines = this.stack.split("\n");
        lines.shift(); // Strip the "[object Object]" line
        return lines.join("\n");
    };
    return Stack;
}());
exports.default = Stack;

},{}],7:[function(require,module,exports){
"use strict";
/**
 * Helper class for capturing stack traces.
 *
 * Copyright (C) 2015 Martin Poelstra
 * License: MIT
 */
Object.defineProperty(exports, "__esModule", { value: true });
// TODO:
// - test/make it work in non-V8
var Stack_1 = require("./Stack");
/**
 * Stack trace container with optional source traces.
 *
 * Typically used for capturing traces across asynchronous calls (e.g.
 * with Promises or Events).
 */
var Trace = /** @class */ (function () {
    function Trace(ignoreUntil) {
        if (ignoreUntil === void 0) { ignoreUntil = Trace; }
        this.stack = new Stack_1.default(ignoreUntil);
    }
    /**
     * Assign another Trace as the source of this Trace.
     *
     * Note: the stack of `source` is copied to this Trace, in order to allow
     * truncating the trace length to `Trace.traceLimit` to prevent memory
     * exhaustion on e.g. recursive traces.
     *
     * @param source Trace to use as source.
     */
    Trace.prototype.setSource = function (source) {
        if (!source.sources) {
            this.sources = [source.stack];
        }
        else {
            this.sources = source.sources.concat(source.stack);
            if (this.sources.length > Trace.traceLimit) {
                this.sources = this.sources.slice(0, Trace.traceLimit);
            }
        }
    };
    Trace.prototype.inspect = function () {
        var result = this.stack.inspect();
        if (this.sources) {
            for (var i = this.sources.length - 1; i >= 0; i--) {
                result += "\n  from previous:\n" + this.sources[i].inspect();
            }
        }
        return result;
    };
    Trace.traceLimit = 10;
    return Trace;
}());
exports.default = Trace;

},{"./Stack":6}],8:[function(require,module,exports){
(function (setImmediate){
"use strict";
/**
 * Call queue for executing callbacks asynchronously.
 *
 * Prevents releasing Zalgo.
 *
 * Copyright (C) 2015 Martin Poelstra
 * License: MIT
 */
Object.defineProperty(exports, "__esModule", { value: true });
var util_1 = require("./util");
var CallQueue = /** @class */ (function () {
    function CallQueue() {
        this.length = 0;
        // Basically twice the number of simultaneously resolving promises
        this._max = 1000;
        this._first = 0;
    }
    /**
     * Push a new callback to the queue.
     * @return true when the queue still has space, false if it's now 'full'
     */
    CallQueue.prototype.push = function (callback, arg) {
        this[this.length++] = callback;
        this[this.length++] = arg;
        return this.length < this._max;
    };
    /**
     * Flush all callbacks in this queue.
     * Note that it is 'ok' for callbacks to throw an error;
     * the next call to flush() will flush the remainder of the queue.
     * When this function returns, the queue will be 'reset' to its beginning.
     */
    CallQueue.prototype.flush = function () {
        while (this._first < this.length) {
            var callback = this[this._first];
            var arg = this[this._first + 1];
            this[this._first] = this[this._first + 1] = undefined;
            this._first += 2;
            callback(arg);
        }
        this.length = 0;
        this._first = 0;
    };
    CallQueue.prototype.empty = function () {
        return this._first === this.length;
    };
    return CallQueue;
}());
var Ring = /** @class */ (function () {
    function Ring(pool) {
        /**
         * Ring of queues.
         * Guaranteed to always contain at least one queue.
         */
        this._ring = [new CallQueue()];
        /**
         * Queue to put new callbacks in, i.e. the last queue in the ring.
         * If `undefined`, a new queue will be obtained and added to ring on next enqueue.
         */
        this._current = this._ring[0];
        this._pool = pool;
    }
    Ring.prototype.enqueue = function (callback, arg) {
        // Make sure this._current points to a queue: obtain one
        // from pool or create a new one if necessary.
        if (!this._current) {
            this._current = this._pool.pop();
            if (!this._current) {
                this._current = new CallQueue();
            }
            this._ring.push(this._current);
        }
        // Add callback to queue
        if (!this._current.push(callback, arg)) {
            // Queue full, load a new one next time
            this._current = undefined;
        }
    };
    /**
     * Call all callbacks in all queues in this ring, until it is empty.
     * Note: it is 'OK' for a callback to throw an error; ring/queue state
     * will remain valid and remaining items will be flushed on next call
     * to `flush()`.
     */
    Ring.prototype.flush = function () {
        while (true) {
            // Ring is guaranteed to have at least one queue (even though
            // queue might be empty when flush() is e.g. called manually).
            this._ring[0].flush();
            // If this is the last queue in the ring, we're done
            if (this._ring.length === 1) {
                break;
            }
            // Shift the now empty ring into pool.
            // Queue at index 0 is empty, and ring length >= 2.
            // So, this._current is guaranteed to point to something 'later'
            // than queue at index 0, and we can safely move index 0 to the
            // pool.
            this._pool.push(this._ring.shift());
        }
        // Ring is now guaranteed to contain only a single, empty queue, so we
        // could move it to the pool.
        // However, because it's the last item remaining, better to simply
        // leave it in the ring, saves unnecessary re-move on next enqueue.
        // Also, make sure that new items will be loaded into that queue.
        this._current = this._ring[0];
    };
    /**
     * Return true if no callbacks are enqueued in this ring.
     */
    Ring.prototype.empty = function () {
        return this._ring.length === 1 && this._ring[0].empty();
    };
    return Ring;
}());
function defaultScheduler(callback) {
    // Note: we explicitly re-check types and call it here (instead of
    // e.g. assigning it to a variable once at startup), to allow
    // setImmediate / setTimeout to be replaced by mocked ones
    // (e.g. Sinon's useFakeTimers())
    if (typeof setImmediate === "function") {
        setImmediate(callback);
    }
    else {
        setTimeout(callback, 0);
    }
}
var Async = /** @class */ (function () {
    function Async() {
        var _this = this;
        this._pool = [];
        this._mainRing = new Ring(this._pool);
        this._idleRing = new Ring(this._pool);
        this._flushing = false;
        this._scheduled = false;
        this._scheduler = undefined;
        this._flusher = function () { return _this._scheduledFlush(); };
    }
    /**
     * Configure alternative scheduler to use.
     * The scheduler function will be called with a flusher, which needs to be
     * executed to flush the queue. Note: the flusher may throw an
     * exception, if any of the callbacks on the queue throws one.
     * This will result in another flush to be scheduled before returning.
     *
     * Call with `undefined` to reset the scheduler to the default (setImmediate).
     *
     * Example usage (this is basically the default):
     *   setScheduler((flusher) => setImmediate(flusher));
     * Note: this is slightly different from just setScheduler(setImmediate), in that
     * the former allows overriding setImmediate in e.g. unit tests.
     */
    Async.prototype.setScheduler = function (scheduler) {
        /* tslint:disable:no-null-keyword */ // 'old' API told you to use `null` instead of `undefined`
        util_1.assert(scheduler === undefined || scheduler === null || typeof scheduler === "function");
        /* tslint:enable:no-null-keyword */
        this._scheduler = scheduler;
    };
    Async.prototype.enqueue = function (callback, arg) {
        if (!this._flushing && !this._scheduled) {
            this._schedule();
        }
        this._mainRing.enqueue(callback, arg);
    };
    Async.prototype.enqueueIdle = function (callback, arg) {
        if (!this._flushing && !this._scheduled) {
            this._schedule();
        }
        this._idleRing.enqueue(callback, arg);
    };
    /**
     * Flush callback queues.
     * First, the 'normal' callback queues are flushed until they are empty (i.e.
     * new callbacks that are added while executing will also be processed).
     * Then, the 'idle' queues are flushed (also until they are empty).
     * Flushing repeats until no more items are enqueued in normal or idle queues.
     * It is an error to call flush from within an enqueued callback.
     */
    Async.prototype.flush = function () {
        util_1.assert(!this._flushing, "cannot recursively flush");
        this._flushing = true;
        try {
            while (true) {
                this._mainRing.flush();
                if (this._idleRing.empty()) {
                    // Both rings now empty: done
                    break;
                }
                // Main ring empty, idle ring not empty.
                // Start flushing idle ring, making sure it is completely
                // processed before processing new 'normal' callbacks (even
                // if it is interrupted by a thrown error in one of them).
                // Also, make sure that any new normal callbacks are going
                // to be processed before any new idle callbacks.
                var emptyRing = this._mainRing;
                this._mainRing = this._idleRing;
                this._idleRing = emptyRing;
            }
        }
        finally {
            this._flushing = false;
            // If one of the callbacks in the queue throws an exception,
            // (e.g. when Promise#done() detects a rejection) make sure to
            // reschedule the remainder of the queue(s) for another iteration.
            // This approach has the advantage of immediately allowing to stop
            // the program in e.g. NodeJS, but also allows to continue running
            // correctly in a browser.
            // Note: we may be called explicitly, even though we were also
            // already scheduled, before.
            if ((!this._mainRing.empty() || !this._idleRing.empty()) && !this._scheduled) {
                this._schedule();
            }
        }
    };
    Async.prototype._schedule = function () {
        util_1.assert(!this._scheduled);
        var scheduler = this._scheduler || defaultScheduler;
        // Call scheduler without a `this`
        scheduler(this._flusher);
        this._scheduled = true;
    };
    Async.prototype._scheduledFlush = function () {
        // Indicate that this 'iteration' of the flush is complete.
        this._scheduled = false;
        this.flush();
    };
    return Async;
}());
exports.Async = Async;
exports.async = new Async();
exports.default = exports.async;

}).call(this,require("timers").setImmediate)
},{"./util":12,"timers":3}],9:[function(require,module,exports){
"use strict";
/**
 * TS-Promise - fast, robust, type-safe promises
 *
 * Copyright (C) 2015 Martin Poelstra
 * License: MIT
 */
Object.defineProperty(exports, "__esModule", { value: true });
var Promise_1 = require("./Promise");
exports.default = Promise_1.default;
exports.Promise = Promise_1.Promise;
var Trace_1 = require("./Trace");
exports.Trace = Trace_1.default;
var rejections_1 = require("./rejections");
exports.UnhandledRejection = rejections_1.UnhandledRejection;
exports.PossiblyUnhandledRejection = rejections_1.PossiblyUnhandledRejection;
var rejections_2 = require("./rejections"); // backwards compatibility
exports.UnhandledRejectionError = rejections_2.UnhandledRejection;
var polyfill_1 = require("./polyfill");
exports.polyfill = polyfill_1.default;
// Temporary, should be moved to its own package some day
var BaseError_1 = require("./BaseError");
exports.BaseError = BaseError_1.default;

},{"./BaseError":4,"./Promise":5,"./Trace":7,"./polyfill":10,"./rejections":11}],10:[function(require,module,exports){
"use strict";
/**
 * Polyfill implementation.
 *
 * Copyright (C) 2016 Martin Poelstra
 * License: MIT
 */
Object.defineProperty(exports, "__esModule", { value: true });
var Promise_1 = require("./Promise");
var util_1 = require("./util");
/**
 * Polyfill global `Promise` instance with ts-promise version.
 * By default, it will only install a ts-promise version if no other
 * implementation is present. Use `force = true` to unconditionally replace the
 * promise implementation.
 *
 * Warning: in general, it's not really recommended to use polyfills, because
 * other libraries may e.g. use the fact that certain platform features are
 * absent to create a 'fingerprint' of a platform, and it may conflict with
 * other libraries that are trying to do the same thing.
 * If you're writing your own library, it's much better to simply directly
 * require/import ts-promise, and use its class directly.
 * However, if you're the 'end-user' (i.e. application, not a library), it may
 * be a viable solution to make Promises available on platforms that otherwise
 * don't have them.
 *
 * @param  {boolean}  force (Optional, default false) Forcibly overwrite existing Promise implementation with
 *                          ts-promise version.
 * @return {boolean}        Returns true when global Promise is (now) a ts-promise (or derived class), false otherwise.
 */
function polyfill(force) {
    if (force === void 0) { force = false; }
    // Get reference to globals (`global`, `window`, etc.)
    var global = util_1.getGlobal();
    if (!global) {
        return false;
    }
    if (force || typeof global.Promise !== "function") {
        global.Promise = Promise_1.Promise;
        return true;
    }
    return global.Promise instanceof Promise_1.Promise;
}
exports.default = polyfill;

},{"./Promise":5,"./util":12}],11:[function(require,module,exports){
(function (process){
"use strict";
/**
 * Definitely- and possibly-unhandled rejection handling.
 *
 * Copyright (C) 2017 Martin Poelstra
 * License: MIT
 */
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    }
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
var BaseError_1 = require("./BaseError");
var util_1 = require("./util");
/**
 * Base class for errors thrown when a (possibly) rejected promise is detected.
 */
var BaseUnhandledRejection = /** @class */ (function (_super) {
    __extends(BaseUnhandledRejection, _super);
    function BaseUnhandledRejection(name, message, reason) {
        var _this = _super.call(this, name, message + ": " + reason) /* istanbul ignore next (TS emitted code) */ || this;
        _this.reason = reason;
        // In case we have a reason, and it has a stack: use it instead of our
        // own stack, as it's more helpful to see where the original error was
        // thrown, than where it was thrown inside the promise lib.
        // In case we don't have a stack, explicitly state so, to not let people
        // chase a problem in the promise lib that isn't there...
        var stack = _this.reason && typeof _this.reason === "object" && _this.reason.stack;
        if (typeof stack !== "string") {
            stack = String(_this.reason);
        }
        _this.stack = _this.name + ": " + stack;
        return _this;
    }
    return BaseUnhandledRejection;
}(BaseError_1.default));
exports.BaseUnhandledRejection = BaseUnhandledRejection;
/**
 * Thrown when a rejected promise is explicitly terminated with `.done()`.
 */
var UnhandledRejection = /** @class */ (function (_super) {
    __extends(UnhandledRejection, _super);
    function UnhandledRejection(reason, trace) {
        var _this = _super.call(this, "UnhandledRejection", "unhandled rejection", reason) /* istanbul ignore next (TS emitted code) */ || this;
        // TODO: Find a better way to merge the location of `.done()` in the
        // trace, because nobody will look for this property...
        _this.trace = trace;
        return _this;
    }
    return UnhandledRejection;
}(BaseUnhandledRejection));
exports.UnhandledRejection = UnhandledRejection;
/**
 * Emitted when a rejected promise isn't handled.
 * @see Promise.onPossiblyUnhandledRejection
 */
var PossiblyUnhandledRejection = /** @class */ (function (_super) {
    __extends(PossiblyUnhandledRejection, _super);
    function PossiblyUnhandledRejection(promise) {
        var _this = _super.call(this, "PossiblyUnhandledRejection", "possibly unhandled rejection", promise.reason()) /* istanbul ignore next (TS emitted code) */ || this;
        _this.promise = promise;
        return _this;
    }
    return PossiblyUnhandledRejection;
}(BaseUnhandledRejection));
exports.PossiblyUnhandledRejection = PossiblyUnhandledRejection;
/**
 * Emit PromiseRejectionEvent (in browser environment).
 * Dispatches the event to all registered handlers, e.g.
 * - window.onunhandledrejection / window.onrejectionhandled
 * - window.addEventListener("unhandledrejection", (event) => { ... }), etc
 * Uses self in case of WebWorker.
 *
 * @param type Either "unhandledrejection" or "rejectionhandled"
 * @param reason Value used to reject promise
 * @param promise ts-promise instance
 * @return true when event was 'handled' (i.e. someone called preventDefault() on it), false otherwise
 */
function emitRejectionEvent(type, reason, promise) {
    // Browsers do a native Promise.resolve() on the promise given in PromiseRejectEvent,
    // which causes an unhandled rejection error due to that native promise not being handled,
    // and prevents the user's unhandled rejection handler from accessing the actual
    // ts-promise Promise. This would make the handled rejection handler useless, because that
    // gets another native promise.
    // So, prevent the unhandled rejection when constructing the event, then override the
    // property to return the 'real' promise.
    // MDN says it isn't cancelable, but both Chrome and Firefox do have it cancelable.
    var event = new PromiseRejectionEvent(type, {
        cancelable: true,
        promise: true,
        reason: reason,
    });
    Object.defineProperty(event, "promise", {
        value: promise,
    });
    var global = util_1.getGlobal();
    if (global.dispatchEvent && !global.dispatchEvent(event)) {
        // Someone called preventDefault()
        return true;
    }
    return false;
}
/**
 * Default handler for an`UnhandledRejection` error, which contains the
 * original reason of the rejection.
 * In Node, if you don't have an `unhandledException` event handler, that will cause your
 * program to terminate after printing the error.
 * When overriding the default handler, it is recommended to keep a similar behavior,
 * as your program is likely in an unknown state.
 */
function defaultUnhandledRejectionHandler(reason, doneTrace) {
    var unhandledRejection = new UnhandledRejection(reason, doneTrace);
    // Leave the comment after the throw: may show up in source line in node
    throw unhandledRejection; // Unhandled rejection caught by .done()
}
exports.defaultUnhandledRejectionHandler = defaultUnhandledRejectionHandler;
/**
 * Default handler for possibly unhandled rejection. It will:
 * - emit Node's `unhandledRejection` event if present, or
 * - emit an `unhandledrejection` (note small R) `PromiseRejectionEvent` on `window` or `self` if present, or
 * - log the rejection using `console.warn()`.
 *
 * Note: when attaching an `unhandledrejection` handler in the browser, make sure to
 * call `event.preventDefault()` to prevent ts-promise's default fallback logging.
 */
function defaultPossiblyUnhandledRejectionHandler(promise) {
    var log = true;
    // First try to emit Node event
    if (typeof process !== "undefined" && typeof process.emit === "function") {
        if (process.emit("unhandledRejection", promise.reason(), promise)) {
            // A handler was called
            log = false;
        }
    }
    else if (typeof PromiseRejectionEvent === "function") {
        // Then fire a browser event if supported by the browser
        if (emitRejectionEvent("unhandledrejection", promise.reason(), promise)) {
            log = false;
        }
    }
    // Fallback to log to console
    if (log) {
        var possiblyUnhandledRejection = new PossiblyUnhandledRejection(promise);
        // tslint:disable-next-line:no-console
        console.warn(possiblyUnhandledRejection.stack);
    }
}
exports.defaultPossiblyUnhandledRejectionHandler = defaultPossiblyUnhandledRejectionHandler;
/**
 * Default handler for handled rejections.
 * It will emit Node's `rejectionHandled` event if present, or emit a
 * `rejectionhandled` (note small R) event on `window` (or `self`) if present.
 */
function defaultPossiblyUnhandledRejectionHandledHandler(promise) {
    // First try to emit Node event
    if (typeof process !== "undefined" && typeof process.emit === "function") {
        process.emit("rejectionHandled", promise);
    }
    else if (typeof PromiseRejectionEvent === "function") {
        // Then fire a browser event if supported by the browser
        emitRejectionEvent("rejectionhandled", promise.reason(), promise);
    }
}
exports.defaultPossiblyUnhandledRejectionHandledHandler = defaultPossiblyUnhandledRejectionHandledHandler;

}).call(this,require('_process'))
},{"./BaseError":4,"./util":12,"_process":2}],12:[function(require,module,exports){
(function (global){
"use strict";
/**
 * Helper utilities.
 *
 * Copyright (C) 2015 Martin Poelstra
 * License: MIT
 */
Object.defineProperty(exports, "__esModule", { value: true });
/**
 * Throw an Error when given condition is false.
 *
 * @param {any}    condition Condition, no-op when truthy, error thrown when falsy
 * @param {string} msg       Optional text to include in error message
 */
function assert(condition, msg) {
    if (!condition) {
        throw new Error(msg ? "assertion failed: " + msg : "assertion failed");
    }
}
exports.assert = assert;
/**
 * Return reference to the global object (if possible).
 *
 * @return {any} Reference to the global object (e.g. `window`, `global`, etc.),
 *               or `undefined` if it could not be determined.
 */
function getGlobal() {
    if (typeof self !== "undefined") { // WebWorkers
        return self;
    }
    if (typeof window !== "undefined") { // Browsers
        return window;
    }
    if (typeof global !== "undefined") { // Serverside (Node)
        return global;
    }
    // Otherwise, try to use `this`.
    // We use eval-like behavior, because it will not inherit our "use strict",
    // see http://stackoverflow.com/questions/3277182/how-to-get-the-global-object-in-javascript
    var g;
    try {
        g = new Function("return this")();
    }
    catch (e) {
        // Content Security Policy might not allow the eval()-evilness above,
        // so just ignore then...
    }
    return g;
}
exports.getGlobal = getGlobal;

}).call(this,typeof global !== "undefined" ? global : typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : {})
},{}],13:[function(require,module,exports){
module.exports = function isBuffer(arg) {
  return arg && typeof arg === 'object'
    && typeof arg.copy === 'function'
    && typeof arg.fill === 'function'
    && typeof arg.readUInt8 === 'function';
}
},{}],14:[function(require,module,exports){
(function (process,global){
// Copyright Joyent, Inc. and other Node contributors.
//
// Permission is hereby granted, free of charge, to any person obtaining a
// copy of this software and associated documentation files (the
// "Software"), to deal in the Software without restriction, including
// without limitation the rights to use, copy, modify, merge, publish,
// distribute, sublicense, and/or sell copies of the Software, and to permit
// persons to whom the Software is furnished to do so, subject to the
// following conditions:
//
// The above copyright notice and this permission notice shall be included
// in all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
// OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
// MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN
// NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
// DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
// OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE
// USE OR OTHER DEALINGS IN THE SOFTWARE.

var formatRegExp = /%[sdj%]/g;
exports.format = function(f) {
  if (!isString(f)) {
    var objects = [];
    for (var i = 0; i < arguments.length; i++) {
      objects.push(inspect(arguments[i]));
    }
    return objects.join(' ');
  }

  var i = 1;
  var args = arguments;
  var len = args.length;
  var str = String(f).replace(formatRegExp, function(x) {
    if (x === '%%') return '%';
    if (i >= len) return x;
    switch (x) {
      case '%s': return String(args[i++]);
      case '%d': return Number(args[i++]);
      case '%j':
        try {
          return JSON.stringify(args[i++]);
        } catch (_) {
          return '[Circular]';
        }
      default:
        return x;
    }
  });
  for (var x = args[i]; i < len; x = args[++i]) {
    if (isNull(x) || !isObject(x)) {
      str += ' ' + x;
    } else {
      str += ' ' + inspect(x);
    }
  }
  return str;
};


// Mark that a method should not be used.
// Returns a modified function which warns once by default.
// If --no-deprecation is set, then it is a no-op.
exports.deprecate = function(fn, msg) {
  // Allow for deprecating things in the process of starting up.
  if (isUndefined(global.process)) {
    return function() {
      return exports.deprecate(fn, msg).apply(this, arguments);
    };
  }

  if (process.noDeprecation === true) {
    return fn;
  }

  var warned = false;
  function deprecated() {
    if (!warned) {
      if (process.throwDeprecation) {
        throw new Error(msg);
      } else if (process.traceDeprecation) {
        console.trace(msg);
      } else {
        console.error(msg);
      }
      warned = true;
    }
    return fn.apply(this, arguments);
  }

  return deprecated;
};


var debugs = {};
var debugEnviron;
exports.debuglog = function(set) {
  if (isUndefined(debugEnviron))
    debugEnviron = process.env.NODE_DEBUG || '';
  set = set.toUpperCase();
  if (!debugs[set]) {
    if (new RegExp('\\b' + set + '\\b', 'i').test(debugEnviron)) {
      var pid = process.pid;
      debugs[set] = function() {
        var msg = exports.format.apply(exports, arguments);
        console.error('%s %d: %s', set, pid, msg);
      };
    } else {
      debugs[set] = function() {};
    }
  }
  return debugs[set];
};


/**
 * Echos the value of a value. Trys to print the value out
 * in the best way possible given the different types.
 *
 * @param {Object} obj The object to print out.
 * @param {Object} opts Optional options object that alters the output.
 */
/* legacy: obj, showHidden, depth, colors*/
function inspect(obj, opts) {
  // default options
  var ctx = {
    seen: [],
    stylize: stylizeNoColor
  };
  // legacy...
  if (arguments.length >= 3) ctx.depth = arguments[2];
  if (arguments.length >= 4) ctx.colors = arguments[3];
  if (isBoolean(opts)) {
    // legacy...
    ctx.showHidden = opts;
  } else if (opts) {
    // got an "options" object
    exports._extend(ctx, opts);
  }
  // set default options
  if (isUndefined(ctx.showHidden)) ctx.showHidden = false;
  if (isUndefined(ctx.depth)) ctx.depth = 2;
  if (isUndefined(ctx.colors)) ctx.colors = false;
  if (isUndefined(ctx.customInspect)) ctx.customInspect = true;
  if (ctx.colors) ctx.stylize = stylizeWithColor;
  return formatValue(ctx, obj, ctx.depth);
}
exports.inspect = inspect;


// http://en.wikipedia.org/wiki/ANSI_escape_code#graphics
inspect.colors = {
  'bold' : [1, 22],
  'italic' : [3, 23],
  'underline' : [4, 24],
  'inverse' : [7, 27],
  'white' : [37, 39],
  'grey' : [90, 39],
  'black' : [30, 39],
  'blue' : [34, 39],
  'cyan' : [36, 39],
  'green' : [32, 39],
  'magenta' : [35, 39],
  'red' : [31, 39],
  'yellow' : [33, 39]
};

// Don't use 'blue' not visible on cmd.exe
inspect.styles = {
  'special': 'cyan',
  'number': 'yellow',
  'boolean': 'yellow',
  'undefined': 'grey',
  'null': 'bold',
  'string': 'green',
  'date': 'magenta',
  // "name": intentionally not styling
  'regexp': 'red'
};


function stylizeWithColor(str, styleType) {
  var style = inspect.styles[styleType];

  if (style) {
    return '\u001b[' + inspect.colors[style][0] + 'm' + str +
           '\u001b[' + inspect.colors[style][1] + 'm';
  } else {
    return str;
  }
}


function stylizeNoColor(str, styleType) {
  return str;
}


function arrayToHash(array) {
  var hash = {};

  array.forEach(function(val, idx) {
    hash[val] = true;
  });

  return hash;
}


function formatValue(ctx, value, recurseTimes) {
  // Provide a hook for user-specified inspect functions.
  // Check that value is an object with an inspect function on it
  if (ctx.customInspect &&
      value &&
      isFunction(value.inspect) &&
      // Filter out the util module, it's inspect function is special
      value.inspect !== exports.inspect &&
      // Also filter out any prototype objects using the circular check.
      !(value.constructor && value.constructor.prototype === value)) {
    var ret = value.inspect(recurseTimes, ctx);
    if (!isString(ret)) {
      ret = formatValue(ctx, ret, recurseTimes);
    }
    return ret;
  }

  // Primitive types cannot have properties
  var primitive = formatPrimitive(ctx, value);
  if (primitive) {
    return primitive;
  }

  // Look up the keys of the object.
  var keys = Object.keys(value);
  var visibleKeys = arrayToHash(keys);

  if (ctx.showHidden) {
    keys = Object.getOwnPropertyNames(value);
  }

  // IE doesn't make error fields non-enumerable
  // http://msdn.microsoft.com/en-us/library/ie/dww52sbt(v=vs.94).aspx
  if (isError(value)
      && (keys.indexOf('message') >= 0 || keys.indexOf('description') >= 0)) {
    return formatError(value);
  }

  // Some type of object without properties can be shortcutted.
  if (keys.length === 0) {
    if (isFunction(value)) {
      var name = value.name ? ': ' + value.name : '';
      return ctx.stylize('[Function' + name + ']', 'special');
    }
    if (isRegExp(value)) {
      return ctx.stylize(RegExp.prototype.toString.call(value), 'regexp');
    }
    if (isDate(value)) {
      return ctx.stylize(Date.prototype.toString.call(value), 'date');
    }
    if (isError(value)) {
      return formatError(value);
    }
  }

  var base = '', array = false, braces = ['{', '}'];

  // Make Array say that they are Array
  if (isArray(value)) {
    array = true;
    braces = ['[', ']'];
  }

  // Make functions say that they are functions
  if (isFunction(value)) {
    var n = value.name ? ': ' + value.name : '';
    base = ' [Function' + n + ']';
  }

  // Make RegExps say that they are RegExps
  if (isRegExp(value)) {
    base = ' ' + RegExp.prototype.toString.call(value);
  }

  // Make dates with properties first say the date
  if (isDate(value)) {
    base = ' ' + Date.prototype.toUTCString.call(value);
  }

  // Make error with message first say the error
  if (isError(value)) {
    base = ' ' + formatError(value);
  }

  if (keys.length === 0 && (!array || value.length == 0)) {
    return braces[0] + base + braces[1];
  }

  if (recurseTimes < 0) {
    if (isRegExp(value)) {
      return ctx.stylize(RegExp.prototype.toString.call(value), 'regexp');
    } else {
      return ctx.stylize('[Object]', 'special');
    }
  }

  ctx.seen.push(value);

  var output;
  if (array) {
    output = formatArray(ctx, value, recurseTimes, visibleKeys, keys);
  } else {
    output = keys.map(function(key) {
      return formatProperty(ctx, value, recurseTimes, visibleKeys, key, array);
    });
  }

  ctx.seen.pop();

  return reduceToSingleString(output, base, braces);
}


function formatPrimitive(ctx, value) {
  if (isUndefined(value))
    return ctx.stylize('undefined', 'undefined');
  if (isString(value)) {
    var simple = '\'' + JSON.stringify(value).replace(/^"|"$/g, '')
                                             .replace(/'/g, "\\'")
                                             .replace(/\\"/g, '"') + '\'';
    return ctx.stylize(simple, 'string');
  }
  if (isNumber(value))
    return ctx.stylize('' + value, 'number');
  if (isBoolean(value))
    return ctx.stylize('' + value, 'boolean');
  // For some reason typeof null is "object", so special case here.
  if (isNull(value))
    return ctx.stylize('null', 'null');
}


function formatError(value) {
  return '[' + Error.prototype.toString.call(value) + ']';
}


function formatArray(ctx, value, recurseTimes, visibleKeys, keys) {
  var output = [];
  for (var i = 0, l = value.length; i < l; ++i) {
    if (hasOwnProperty(value, String(i))) {
      output.push(formatProperty(ctx, value, recurseTimes, visibleKeys,
          String(i), true));
    } else {
      output.push('');
    }
  }
  keys.forEach(function(key) {
    if (!key.match(/^\d+$/)) {
      output.push(formatProperty(ctx, value, recurseTimes, visibleKeys,
          key, true));
    }
  });
  return output;
}


function formatProperty(ctx, value, recurseTimes, visibleKeys, key, array) {
  var name, str, desc;
  desc = Object.getOwnPropertyDescriptor(value, key) || { value: value[key] };
  if (desc.get) {
    if (desc.set) {
      str = ctx.stylize('[Getter/Setter]', 'special');
    } else {
      str = ctx.stylize('[Getter]', 'special');
    }
  } else {
    if (desc.set) {
      str = ctx.stylize('[Setter]', 'special');
    }
  }
  if (!hasOwnProperty(visibleKeys, key)) {
    name = '[' + key + ']';
  }
  if (!str) {
    if (ctx.seen.indexOf(desc.value) < 0) {
      if (isNull(recurseTimes)) {
        str = formatValue(ctx, desc.value, null);
      } else {
        str = formatValue(ctx, desc.value, recurseTimes - 1);
      }
      if (str.indexOf('\n') > -1) {
        if (array) {
          str = str.split('\n').map(function(line) {
            return '  ' + line;
          }).join('\n').substr(2);
        } else {
          str = '\n' + str.split('\n').map(function(line) {
            return '   ' + line;
          }).join('\n');
        }
      }
    } else {
      str = ctx.stylize('[Circular]', 'special');
    }
  }
  if (isUndefined(name)) {
    if (array && key.match(/^\d+$/)) {
      return str;
    }
    name = JSON.stringify('' + key);
    if (name.match(/^"([a-zA-Z_][a-zA-Z_0-9]*)"$/)) {
      name = name.substr(1, name.length - 2);
      name = ctx.stylize(name, 'name');
    } else {
      name = name.replace(/'/g, "\\'")
                 .replace(/\\"/g, '"')
                 .replace(/(^"|"$)/g, "'");
      name = ctx.stylize(name, 'string');
    }
  }

  return name + ': ' + str;
}


function reduceToSingleString(output, base, braces) {
  var numLinesEst = 0;
  var length = output.reduce(function(prev, cur) {
    numLinesEst++;
    if (cur.indexOf('\n') >= 0) numLinesEst++;
    return prev + cur.replace(/\u001b\[\d\d?m/g, '').length + 1;
  }, 0);

  if (length > 60) {
    return braces[0] +
           (base === '' ? '' : base + '\n ') +
           ' ' +
           output.join(',\n  ') +
           ' ' +
           braces[1];
  }

  return braces[0] + base + ' ' + output.join(', ') + ' ' + braces[1];
}


// NOTE: These type checking functions intentionally don't use `instanceof`
// because it is fragile and can be easily faked with `Object.create()`.
function isArray(ar) {
  return Array.isArray(ar);
}
exports.isArray = isArray;

function isBoolean(arg) {
  return typeof arg === 'boolean';
}
exports.isBoolean = isBoolean;

function isNull(arg) {
  return arg === null;
}
exports.isNull = isNull;

function isNullOrUndefined(arg) {
  return arg == null;
}
exports.isNullOrUndefined = isNullOrUndefined;

function isNumber(arg) {
  return typeof arg === 'number';
}
exports.isNumber = isNumber;

function isString(arg) {
  return typeof arg === 'string';
}
exports.isString = isString;

function isSymbol(arg) {
  return typeof arg === 'symbol';
}
exports.isSymbol = isSymbol;

function isUndefined(arg) {
  return arg === void 0;
}
exports.isUndefined = isUndefined;

function isRegExp(re) {
  return isObject(re) && objectToString(re) === '[object RegExp]';
}
exports.isRegExp = isRegExp;

function isObject(arg) {
  return typeof arg === 'object' && arg !== null;
}
exports.isObject = isObject;

function isDate(d) {
  return isObject(d) && objectToString(d) === '[object Date]';
}
exports.isDate = isDate;

function isError(e) {
  return isObject(e) &&
      (objectToString(e) === '[object Error]' || e instanceof Error);
}
exports.isError = isError;

function isFunction(arg) {
  return typeof arg === 'function';
}
exports.isFunction = isFunction;

function isPrimitive(arg) {
  return arg === null ||
         typeof arg === 'boolean' ||
         typeof arg === 'number' ||
         typeof arg === 'string' ||
         typeof arg === 'symbol' ||  // ES6 symbol
         typeof arg === 'undefined';
}
exports.isPrimitive = isPrimitive;

exports.isBuffer = require('./support/isBuffer');

function objectToString(o) {
  return Object.prototype.toString.call(o);
}


function pad(n) {
  return n < 10 ? '0' + n.toString(10) : n.toString(10);
}


var months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep',
              'Oct', 'Nov', 'Dec'];

// 26 Feb 16:19:34
function timestamp() {
  var d = new Date();
  var time = [pad(d.getHours()),
              pad(d.getMinutes()),
              pad(d.getSeconds())].join(':');
  return [d.getDate(), months[d.getMonth()], time].join(' ');
}


// log is just a thin wrapper to console.log that prepends a timestamp
exports.log = function() {
  console.log('%s - %s', timestamp(), exports.format.apply(exports, arguments));
};


/**
 * Inherit the prototype methods from one constructor into another.
 *
 * The Function.prototype.inherits from lang.js rewritten as a standalone
 * function (not on Function.prototype). NOTE: If this file is to be loaded
 * during bootstrapping this function needs to be rewritten using some native
 * functions as prototype setup using normal JavaScript does not work as
 * expected during bootstrapping (see mirror.js in r114903).
 *
 * @param {function} ctor Constructor function which needs to inherit the
 *     prototype.
 * @param {function} superCtor Constructor function to inherit prototype from.
 */
exports.inherits = require('inherits');

exports._extend = function(origin, add) {
  // Don't do anything if add isn't an object
  if (!add || !isObject(add)) return origin;

  var keys = Object.keys(add);
  var i = keys.length;
  while (i--) {
    origin[keys[i]] = add[keys[i]];
  }
  return origin;
};

function hasOwnProperty(obj, prop) {
  return Object.prototype.hasOwnProperty.call(obj, prop);
}

}).call(this,require('_process'),typeof global !== "undefined" ? global : typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : {})
},{"./support/isBuffer":13,"_process":2,"inherits":1}],15:[function(require,module,exports){
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var index_1 = require("./src/index");
var player = new index_1.Vox.Player({
    src: './audio/Jeff Beal - Rome Main Title Theme.mp3',
    onload: function () {
        console.log('loaded');
    }
});
player.toMaster();
window.player = player;
window.Vox = index_1.Vox;
window.onload = function () {
    var playBtn = document.getElementById('playBtn');
    playBtn.onclick = function () {
        player.start();
    };
    var stopBtn = document.getElementById('stopBtn');
    stopBtn.onclick = function () {
        player.stop();
    };
};

},{"./src/index":43}],16:[function(require,module,exports){
"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
var Vox_1 = require("../core/Vox");
var Time_1 = require("./Time");
var Frequency = /** @class */ (function (_super) {
    __extends(Frequency, _super);
    function Frequency(val, unit) {
        var _this = _super.call(this) || this;
        _this.TimeObject = true;
        _this._defaultUnits = 'hz';
        _this._val = val;
        _this._units = unit;
        if (_this._units !== undefined && Vox_1.Vox.isString(_this._val) &&
            !!parseFloat(_this._val) && _this._val.charAt(0) !== '+') {
            _this._val = parseFloat(_this._val);
            _this._units = _this._defaultUnits;
        }
        else if (val && val.constructor === _this.constructor) {
            _this._val = val.val;
            _this._units = val._units;
        }
        else if (val.TimeObject === true) {
            _this._val = val.toFrequency();
        }
        return _this;
    }
    Object.defineProperty(Frequency.prototype, "sampleRate", {
        get: function () {
            return Vox_1.Vox.context._ctx.sampleRate;
        },
        enumerable: true,
        configurable: true
    });
    Frequency.prototype.valueOf = function () {
        return Time_1.Time.prototype.valueOf.call(this);
    };
    Frequency.prototype.toFrequency = function () {
        return Time_1.Time.prototype.toFrequency.call(this);
    };
    Frequency.prototype.toSeconds = function () {
        return 1 / Time_1.Time.prototype.toSeconds.call(this);
    };
    Frequency.prototype.secondsToUnits = function (seconds) {
        return 1 / seconds;
    };
    Frequency.prototype.beatsToUnits = function (beats) {
        return 1 / Time_1.Time.prototype.beatsToUnits.call(this, beats);
    };
    Frequency.prototype.ticksToUnits = function (ticks) {
        return 1 / ((ticks * 60) / (Vox_1.Vox.VoxTransportCtrl.bpm.value * Vox_1.Vox.VoxTransportCtrl.PPQ));
    };
    Frequency.prototype.frequencyToUnits = function (freq) {
        return freq;
    };
    Frequency.prototype.toSamples = function () {
        return Time_1.Time.prototype.toSamples.call(this);
    };
    Frequency.prototype.toMilliseconds = function () {
        return Time_1.Time.prototype.toMilliseconds.call(this);
    };
    Frequency.prototype.toNotation = function () {
        return Time_1.Time.prototype.toNotation.call(this);
    };
    Frequency.prototype.getBpm = function () {
        return Time_1.Time.prototype.getBpm.call(this);
    };
    Frequency.prototype.getTimeSignature = function () {
        return Time_1.Time.prototype.getTimeSignature.call(this);
    };
    Frequency.prototype.getPPQ = function () {
        return Time_1.Time.prototype.getPPQ.call(this);
    };
    Frequency.prototype.toNote = function () {
        var freq = this.toFrequency();
        var log = Math.log2(freq / Vox_1.Vox.Frequency.A4);
        var noteNumber = Math.round(12 * log) + 57;
        var octave = Math.floor(noteNumber / 12);
        if (octave < 0) {
            noteNumber += -12 * octave;
        }
        var noteName = scaleIndexToNote[noteNumber % 12];
        return noteName + octave.toString;
    };
    Frequency.prototype.toTicks = function () {
        var quarterTime = this.beatsToUnits(1);
        var quarters = this.valueOf() / quarterTime;
        return Math.floor(quarters * Vox_1.Vox.VoxTransportCtrl.PPQ);
    };
    Frequency.mtof = function (midi) {
        return Vox_1.Vox.Frequency.A4 * Math.pow(2, (midi - 69) / 12);
    };
    Frequency.ftom = function (freq) {
        return 69 + Math.round(12 * Math.log2(freq / Vox_1.Vox.Frequency.A4));
    };
    Frequency.A4 = 440;
    return Frequency;
}(Vox_1.Vox));
exports.Frequency = Frequency;
var scaleIndexToNote = [
    'C', 'C#', 'D', 'D#', 'E',
    'F', 'F#', 'G', 'G#', 'A',
    'A#', 'B'
];
var noteToScaleIndex = {
    cb: -1, c: 0, 'c#': 1,
    db: 1, d: 2, 'd#': 3,
    eb: 3, e: 4, 'e#': 5,
    fb: 4, f: 5, 'f#': 6,
    gb: 6, g: 7, 'g#': 8,
    ab: 8, a: 9, 'a#': 10,
    bb: 10, b: 11, 'b#': 12,
};
Vox_1.Vox.Frequency = Frequency;

},{"../core/Vox":42,"./Time":19}],17:[function(require,module,exports){
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.expressions = {
    n: {
        regexp: /^(\d+)n(\.?)$/i,
        method: function (value, dot) {
            value = parseInt(value);
            var scalar = dot === '.' ? 1.5 : 1;
            if (value === 1) {
                return this.beatsToUnits(this.getTimeSignature()) * scalar;
            }
            else {
                return this.beatsToUnits(4 / value) * scalar;
            }
        }
    },
    t: {
        regexp: /^(\d+)t$/i,
        method: function (value) {
            value = parseInt(value);
            return this.beatsToUnits(8 / (parseInt(value) * 3));
        }
    },
    i: {
        regexp: /^(\d+)i$/i,
        method: function (value) {
            return this.ticksToUnits(parseInt(value));
        }
    },
    hz: {
        regexp: /^(\d+(?:\.\d+)?)hz$/i,
        method: function (value) {
            return this.freqcyToUnits(parseFloat(value));
        }
    },
    s: {
        regexp: /^(\d+(?:\.\d+)?)s$/,
        method: function (value) {
            return this.secondsToUnits(parseFloat(value));
        }
    },
    sample: {
        regexp: /^(\d+)samples$/,
        method: function (value) {
            return parseInt(value) / this.sampleRate;
        }
    },
    now: {
        regexp: /^\+(.+)/,
        method: function (capture) {
            return this.now() + (new this.constructor(capture)).valueOf();
        }
    },
    default: {
        regexp: /^(\d+(?:\.\d+))$/,
    }
};

},{}],18:[function(require,module,exports){
"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
var Vox_1 = require("../core/Vox");
var Time_1 = require("./Time");
var Ticks = /** @class */ (function (_super) {
    __extends(Ticks, _super);
    function Ticks(val, unit) {
        var _this = _super.call(this) || this;
        _this.TimeObject = true;
        _this._defaultUnits = 'i';
        _this._val = val;
        _this._units = unit;
        if (_this._units !== undefined && Vox_1.Vox.isString(_this._val) &&
            !!parseFloat(_this._val) && _this._val.charAt(0) !== '+') {
            _this._val = parseFloat(_this._val);
            _this._units = _this._defaultUnits;
        }
        else if (val && val.constructor === _this.constructor) {
            _this._val = val.val;
            _this._units = val._units;
        }
        else if (val.TimeObject === true) {
            _this._val = val.toTicks();
        }
        return _this;
    }
    Ticks.prototype.now = function () {
        return Vox_1.Vox.VoxTransportCtrl.ticks;
    };
    Object.defineProperty(Ticks.prototype, "sampleRate", {
        get: function () {
            return Vox_1.Vox.context._ctx.sampleRate;
        },
        enumerable: true,
        configurable: true
    });
    Ticks.prototype.valueOf = function () {
        return Time_1.Time.prototype.valueOf.call(this);
    };
    Ticks.prototype.beatesToUnits = function (beats) {
        return this.getPPQ() * beats;
    };
    Ticks.prototype.ticksToUnits = function (ticks) {
        return ticks;
    };
    Ticks.prototype.toTicks = function () {
        return this.valueOf();
    };
    Ticks.prototype.getBpm = function () {
        return Time_1.Time.prototype.getBpm.call(this);
    };
    Ticks.prototype.getTimeSignature = function () {
        return Time_1.Time.prototype.getTimeSignature.call(this);
    };
    Ticks.prototype.getPPQ = function () {
        return Time_1.Time.prototype.getPPQ.call(this);
    };
    Ticks.prototype.frequencyToUnits = function (freq) {
        return Time_1.Time.prototype.frequencyToUnits.call(this, freq);
    };
    Ticks.prototype.beatsToUnits = function (beats) {
        return Time_1.Time.prototype.beatsToUnits.call(this, beats);
    };
    Ticks.prototype.secondsToUnits = function (seconds) {
        console.log('call Ticks secondsToUnits', seconds);
        return Math.floor(seconds / (60 / this.getBpm())) * this.getPPQ();
    };
    Ticks.prototype.toSeconds = function () {
        return (this.valueOf() / this.getPPQ()) * (60 / this.getBpm());
    };
    Ticks.prototype.toFrequency = function () {
        return Time_1.Time.prototype.toFrequency.call(this);
    };
    Ticks.prototype.toSamples = function () {
        return Time_1.Time.prototype.toSamples.call(this);
    };
    Ticks.prototype.toMilliseconds = function () {
        return Time_1.Time.prototype.toMilliseconds.call(this);
    };
    Ticks.prototype.toNotation = function () {
        return Time_1.Time.prototype.toNotation.call(this);
    };
    return Ticks;
}(Vox_1.Vox));
exports.Ticks = Ticks;
Vox_1.Vox.Ticks = Ticks;

},{"../core/Vox":42,"./Time":19}],19:[function(require,module,exports){
"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
var Vox_1 = require("../core/Vox");
var RegexTest_1 = require("./RegexTest");
var Time = /** @class */ (function (_super) {
    __extends(Time, _super);
    function Time(val, unit) {
        var _this = _super.call(this) || this;
        _this.TimeObject = true;
        _this._defaultUnits = 's';
        _this._val = val;
        _this._units = unit;
        if (_this._units !== undefined && Vox_1.Vox.isString(_this._val) &&
            !!parseFloat(_this._val) && _this._val.charAt(0) !== '+') {
            _this._val = parseFloat(_this._val);
            _this._units = _this._defaultUnits;
        }
        else if (val && val.constructor === _this.constructor) {
            _this._val = val.val;
            _this._units = val._units;
        }
        else if (val.TimeObject === true) {
            _this._val = val.toSeconds();
        }
        return _this;
    }
    Time.prototype.valueOf = function () {
        if (Vox_1.Vox.isUndef(this._val)) {
            return this.now();
        }
        else if (Vox_1.Vox.isString(this._val) && Vox_1.Vox.isUndef(this._units)) {
            for (var key in RegexTest_1.expressions) {
                if (RegexTest_1.expressions[key].regexp.test(this._val.trim())) {
                    this._units = key;
                    break;
                }
            }
        }
        if (Vox_1.Vox.isDefined(this._units)) {
            var expression = RegexTest_1.expressions[this._units];
            var matching = this._val.toString().trim().match(expression.regexp);
            if (matching) {
                return expression.method.apply(this, matching.slice(1));
            }
            else {
                return expression.method.call(this, parseFloat(this._val));
            }
        }
        else {
            return this._val;
        }
    };
    Object.defineProperty(Time.prototype, "sampleRate", {
        get: function () {
            return Vox_1.Vox.context._ctx.sampleRate;
        },
        enumerable: true,
        configurable: true
    });
    Time.prototype.toSeconds = function () {
        return this.valueOf();
    };
    Time.prototype.toFrequency = function () {
        return 1 / this.toSeconds();
    };
    Time.prototype.toSamples = function () {
        return this.toSeconds() * Vox_1.Vox.context._ctx.sampleRate;
    };
    Time.prototype.toMilliseconds = function () {
        return this.toSeconds() * 1000;
    };
    Time.prototype.getBpm = function () {
        if (Vox_1.Vox.VoxTransportCtrl) {
            return Vox_1.Vox.VoxTransportCtrl.bpm.value;
        }
        else {
            return 120;
        }
    };
    Time.prototype.getTimeSignature = function () {
        if (Vox_1.Vox.VoxTransportCtrl) {
            return Vox_1.Vox.VoxTransportCtrl.timeSignature;
        }
        else {
            return 4;
        }
    };
    Time.prototype.getPPQ = function () {
        if (Vox_1.Vox.VoxTransportCtrl) {
            return Vox_1.Vox.VoxTransportCtrl.PPQ;
        }
        else {
            return 192;
        }
    };
    Time.prototype.frequencyToUnits = function (freq) {
        console.log('timeBase freqcyToUnits');
        return 1 / freq;
    };
    Time.prototype.beatsToUnits = function (beats) {
        return (60 / this.getBpm()) * beats;
    };
    Time.prototype.secondsToUnits = function (seconds) {
        console.log('call TimeBase secondsToUnits', seconds);
        return seconds;
    };
    Time.prototype.ticksToUnits = function (ticks) {
        return ticks * (this.beatsToUnits(1) / this.getPPQ());
    };
    Time.prototype.toNotation = function () {
        var time = this.toSeconds();
        var testNotations = ['1m'];
        for (var power = 1; power < 8; power++) {
            var subdiv = Math.pow(2, power);
            testNotations.push(subdiv + 'n.');
            testNotations.push(subdiv + 'n');
            testNotations.push(subdiv + 't');
        }
        testNotations.push('0');
        var closest = testNotations[0];
        var closestSeconds = (new Vox_1.Vox.Time(testNotations[0])).toSeconds();
        testNotations.forEach(function (notation) {
            var notationSeconds = (new Vox_1.Vox.Time(notation)).toSeconds();
            if (Math.abs(notationSeconds - time) < Math.abs(closestSeconds - time)) {
                closest = notation;
                closestSeconds = notationSeconds;
            }
        });
        return closest;
    };
    Time.prototype.toTicks = function () {
        var quarterTime = this.beatsToUnits(1);
        var quarters = this.valueOf() / quarterTime;
        return Math.round(quarters * this.getPPQ());
    };
    return Time;
}(Vox_1.Vox));
exports.Time = Time;
Vox_1.Vox.Time = Time;

},{"../core/Vox":42,"./RegexTest":17}],20:[function(require,module,exports){
"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
var Vox_1 = require("../core/Vox");
var Time_1 = require("./Time");
var TransportTime = /** @class */ (function (_super) {
    __extends(TransportTime, _super);
    function TransportTime(val, unit) {
        var _this = _super.call(this) || this;
        _this.TimeObject = true;
        _this._defaultUnits = 's';
        _this._val = val;
        _this._units = unit;
        if (_this._units !== undefined && Vox_1.Vox.isString(_this._val) &&
            !!parseFloat(_this._val) && _this._val.charAt(0) !== '+') {
            _this._val = parseFloat(_this._val);
            _this._units = _this._defaultUnits;
        }
        else if (val && val.constructor === _this.constructor) {
            _this._val = val.val;
            _this._units = val._units;
        }
        else if (val.TimeObject === true) {
            _this._val = val.toSeconds();
        }
        return _this;
    }
    TransportTime.prototype.now = function () {
        return Vox_1.Vox.VoxTransportCtrl.seconds;
    };
    Object.defineProperty(TransportTime.prototype, "sampleRate", {
        get: function () {
            return Vox_1.Vox.context._ctx.sampleRate;
        },
        enumerable: true,
        configurable: true
    });
    TransportTime.prototype.valueOf = function () {
        return Time_1.Time.prototype.valueOf.call(this);
    };
    TransportTime.prototype.toSeconds = function () {
        return Time_1.Time.prototype.toSeconds.call(this);
    };
    TransportTime.prototype.toFrequency = function () {
        return Time_1.Time.prototype.toFrequency.call(this);
    };
    TransportTime.prototype.toSamples = function () {
        return Time_1.Time.prototype.toSamples.call(this);
    };
    TransportTime.prototype.toMilliseconds = function () {
        return Time_1.Time.prototype.toMilliseconds.call(this);
    };
    TransportTime.prototype.toNotation = function () {
        return Time_1.Time.prototype.toNotation.call(this);
    };
    TransportTime.prototype.toTicks = function () {
        return Time_1.Time.prototype.toTicks.call(this);
    };
    TransportTime.prototype.getBpm = function () {
        return Time_1.Time.prototype.getBpm.call(this);
    };
    TransportTime.prototype.getTimeSignature = function () {
        return Time_1.Time.prototype.getTimeSignature.call(this);
    };
    TransportTime.prototype.getPPQ = function () {
        return Time_1.Time.prototype.getPPQ.call(this);
    };
    TransportTime.prototype.frequencyToUnits = function (freq) {
        return Time_1.Time.prototype.frequencyToUnits.call(this, freq);
    };
    TransportTime.prototype.beatsToUnits = function (beats) {
        return Time_1.Time.prototype.beatsToUnits.call(this, beats);
    };
    TransportTime.prototype.secondsToUnits = function (seconds) {
        return Time_1.Time.prototype.secondsToUnits.call(this, seconds);
    };
    TransportTime.prototype.ticksToUnits = function (ticks) {
        return Time_1.Time.prototype.ticksToUnits.call(this, ticks);
    };
    return TransportTime;
}(Vox_1.Vox));
exports.TransportTime = TransportTime;
Vox_1.Vox.TransportTime = TransportTime;

},{"../core/Vox":42,"./Time":19}],21:[function(require,module,exports){
"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
var Vox_1 = require("../core/Vox");
var type_1 = require("../type");
var VoxBufferSource = /** @class */ (function (_super) {
    __extends(VoxBufferSource, _super);
    function VoxBufferSource(opt) {
        var _this = _super.call(this) || this;
        _this._sourceStarted = false;
        _this._sourceStopped = false;
        _this._startTime = -1;
        _this._stopTime = -1;
        _this.onended = (opt.onended === undefined ? function () { } : opt.onended);
        opt.onload = (opt.onload === undefined ? function () { } : opt.onload);
        opt.playbackRate = (opt.playbackRate === undefined ? 1 : opt.playbackRate);
        _this._gainNode = _this.output = new Vox_1.Vox.VoxGain(0, type_1.VoxType.Default);
        _this._source = _this.context._ctx.createBufferSource();
        Vox_1.Vox.connect(_this._source, _this._gainNode);
        _this._source.onended = _this._onended.bind(_this);
        _this._buffer = new Vox_1.Vox.VoxBuffer({ src: opt.buffer, onload: opt.onload });
        _this.playbackRate = new Vox_1.Vox.VoxAudioParam({
            param: _this._source.playbackRate,
            units: type_1.VoxType.Positive,
            value: opt.playbackRate,
        });
        _this.fadeInDuration = (opt.fadeInDuration === undefined ? 0 : opt.fadeInDuration);
        _this.fadeOutDuration = (opt.fadeOutDuration === undefined ? 0 : opt.fadeOutDuration);
        _this.fadeCurve = (opt.fadeCurve === undefined ? type_1.FadeCurve.Linear : opt.fadeCurve);
        _this._onendedTimeout = -1;
        _this.loop = (opt.loop === undefined ? false : opt.loop);
        _this.loopStartMoment = (opt.loopStartMoment === undefined ? 0 : opt.loopStartMoment);
        _this.loopEndMoment = (opt.loopEndMoment === undefined ? 0 : opt.loopEndMoment);
        return _this;
    }
    VoxBufferSource.prototype.getStateAtTime = function (time) {
        time = this.toSeconds(time);
        if (this._startTime !== -1 && this._startTime <= time &&
            (this._stopTime === -1 || time < this._stopTime) &&
            !this._sourceStopped) {
            return type_1.PlayState.Started;
        }
        else {
            return type_1.PlayState.Stopped;
        }
    };
    VoxBufferSource.prototype.start = function (time, offset, duration, gain) {
        if (!(this._startTime === -1)) {
            throw ('can only be start once');
        }
        if (!this.buffer.loaded) {
            throw ('buffer is either not set or not loaded');
        }
        if (this._sourceStopped) {
            throw ('source is already stopped');
        }
        time = this.toSeconds(time);
        if (this.loop) {
            offset = (offset === undefined ? this.loopStartMoment : offset);
        }
        else {
            offset = (offset === undefined ? 0 : offset);
        }
        offset = Math.max(this.toSeconds(offset), 0);
        gain = (gain === undefined ? 1 : gain);
        var fadeInDuration = this.toSeconds(this.fadeInDuration);
        if (fadeInDuration > 0) {
            this._gainNode.gain.setValueAtTime(0, time);
            if (this.fadeCurve === type_1.FadeCurve.Exponential) {
                this._gainNode.gain.exponentialApproachValueAtTime(gain, time, fadeInDuration);
            }
            else {
                this._gainNode.gain.linearRampToValueAtTime(gain, time + fadeInDuration);
            }
        }
        else {
            this._gainNode.gain.setValueAtTime(gain, time);
        }
        this._startTime = time;
        if (duration !== undefined) {
            duration = Math.max(this.toSeconds(duration), 0);
            this.stop(time + duration);
        }
        if (this.loop) {
            var loopEnd = this.loopEndMoment || this.buffer.duration;
            var loopStart = this.loopStartMoment;
            var loopDuration = loopEnd - loopStart;
            if (offset >= loopEnd) {
                offset = ((offset - loopStart) % loopDuration) + loopStart;
            }
        }
        this._source.buffer = this.buffer.get();
        this._source.loopEnd = this.loopEndMoment || this.buffer.duration;
        if (offset < this._buffer.duration) {
            this._sourceStarted = true;
            this._source.start(time, offset);
        }
        return this;
    };
    VoxBufferSource.prototype.stop = function (time) {
        console.log('stop', time);
        if (!this.buffer.loaded) {
            console.log('空buffer');
            return;
        }
        if (this._sourceStopped) {
            console.log('已经被停止过');
            return;
        }
        time = this.toSeconds(time);
        // 如果已经有了停止的事件
        if (this._stopTime !== -1) {
            this.cancelStop();
        }
        var fadeOutDuration = this.toSeconds(this.fadeOutDuration);
        this._stopTime = time + fadeOutDuration;
        if (fadeOutDuration > 0) {
            if (this.fadeCurve == type_1.FadeCurve.Linear) {
                this._gainNode.gain.linearRampTo(0, fadeOutDuration, time);
            }
            else {
                this._gainNode.gain.targetRampTo(0, fadeOutDuration, time);
            }
        }
        else {
            this._gainNode.gain.cancelAndHoldAtTime(time);
            this._gainNode.gain.setValueAtTime(0, time);
        }
        Vox_1.Vox.context.clearTimeout(this._onendedTimeout);
        this._onendedTimeout = Vox_1.Vox.context.setTimeout(this._onended.bind(this), this._stopTime - this.now());
        return this;
    };
    VoxBufferSource.prototype.cancelStop = function () {
        if (this._startTime !== -1 && !this._sourceStopped) {
            var fedeInMoment = this.toSeconds(this.fadeInDuration);
            this._gainNode.gain.cancelScheduledValues(this._startTime + this.fadeInDuration + this.sampleTime);
            this.context.clearTimeout(this._onendedTimeout);
            this._stopTime = -1;
        }
        return this;
    };
    VoxBufferSource.prototype._onended = function () {
        if (!this._sourceStopped) {
            this._sourceStopped = true;
            //allow additional time for the exponential curve to fully decay
            var additionalTail = this.fadeCurve === type_1.FadeCurve.Exponential ? this.fadeOutDuration * 2 : 0;
            if (this._sourceStarted && this._stopTime !== -1) {
                this._source.stop(this._stopTime + additionalTail);
            }
            this.onended(this);
            console.log('source _onended');
        }
    };
    Object.defineProperty(VoxBufferSource.prototype, "buffer", {
        get: function () {
            return this._buffer;
        },
        set: function (buf) {
            this._buffer.set(buf);
        },
        enumerable: true,
        configurable: true
    });
    return VoxBufferSource;
}(Vox_1.Vox.VoxAudioNode));
exports.VoxBufferSource = VoxBufferSource;
Vox_1.Vox.VoxBufferSource = VoxBufferSource;

},{"../core/Vox":42,"../type":48}],22:[function(require,module,exports){
"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
var Vox_1 = require("../core/Vox");
var Source_1 = require("./Source");
var type_1 = require("../type");
var Oscillator = /** @class */ (function (_super) {
    __extends(Oscillator, _super);
    function Oscillator(opt) {
        var _this = _super.call(this) || this;
        _this._oscillator = null;
        opt = opt === undefined ? {} : opt;
        opt.type = opt.type === undefined ? 'sine' : opt.type;
        _this.frequency = new Vox_1.Vox.Signal({
            value: opt.frequency === undefined ? 440 : opt.frequency,
            units: type_1.VoxType.Frequency,
        });
        _this.detune = new Vox_1.Vox.Signal({
            value: opt.detune === undefined ? 0 : opt.detune,
            units: type_1.VoxType.Cents,
        });
        _this._wave = null;
        _this._partials = opt.partials === undefined ? [] : opt.partials;
        _this._partialCount = opt.partialCount === undefined ? 0 : opt.partialCount;
        _this._phase = opt.phase === undefined ? 0 : opt.phase;
        _this._type = opt.type === undefined ? type_1.OscilType.sine : opt.type;
        _this.type = _this._type;
        return _this;
    }
    Oscillator.prototype._getRealImaginary = function (type, phase) {
        var fftSize = 4096;
        var periodicWaveSize = fftSize / 2;
        var real = new Float32Array(periodicWaveSize);
        var imag = new Float32Array(periodicWaveSize);
        var partialCount = 1;
        if (type === type_1.OscilType.custom) {
        }
        else {
            var partial = /^(sine|triangle|square|sawtooth)(\d+)$/.exec(type);
            if (partial) {
                partialCount = parseInt(partial[2]) + 1;
                this._partialCount = parseInt(partial[2]);
                type = partial[1];
                partialCount = Math.max(partialCount, 2);
                periodicWaveSize = partialCount;
            }
            else {
                this._partialCount = 0;
            }
            this._partials = [];
        }
        // https://webaudio.github.io/web-audio-api/#periodicwave
        for (var n = 1; n < periodicWaveSize; ++n) {
            var piFactor = 2 / (n * Math.PI);
            var b = void 0;
            switch (type) {
                case type_1.OscilType.sine:
                    b = (n <= partialCount) ? 1 : 0;
                    this._partials[n - 1] = b;
                    break;
                case type_1.OscilType.square:
                    b = (n & 1) ? 2 * piFactor : 0;
                    this._partials[n - 1] = b;
                    break;
                case type_1.OscilType.triangle:
                    if (n & 1) {
                        b = 2 * (piFactor * piFactor) * ((((n - 1) >> 1) & 1) ? -1 : 1);
                    }
                    else {
                        b = 0;
                    }
                    this._partials[n - 1] = b;
                    break;
                case type_1.OscilType.sawtooth:
                    b = piFactor * ((n & 1) ? 1 : -1);
                    this._partials[n - 1] = b;
                    break;
                case type_1.OscilType.custom:
                    b = this._partials[n - 1];
                    break;
                default:
                    throw new TypeError('Oscillator: invalid type: ' + type);
            }
            if (b !== 0) {
                real[n] = -b * Math.sin(phase * n);
                imag[n] = b * Math.cos(phase * n);
            }
            else {
                real[n] = 0;
                imag[n] = 0;
            }
        }
        return [real, imag];
    };
    Object.defineProperty(Oscillator.prototype, "type", {
        get: function () {
            return this._type;
        },
        set: function (t) {
            console.log('Oscillator set Type');
            var coefs = this._getRealImaginary(t, this._phase);
            var periodicWave = this.context._ctx.createPeriodicWave(coefs[0], coefs[1]);
            this._wave = periodicWave;
            if (this._oscillator !== null) {
                this._oscillator.setPeriodicWave(this._wave);
            }
            this._type = t;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(Oscillator.prototype, "phase", {
        get: function () {
            return this._phase * (180 / Math.PI);
        },
        enumerable: true,
        configurable: true
    });
    Oscillator.prototype._start = function (time) {
        console.log('start');
        this._oscillator = new Vox_1.Vox.VoxOscillatorNode();
        this._oscillator.setPeriodicWave(this._wave);
        this._oscillator.connect(this.output);
        this.frequency.connect(this._oscillator.frequency);
        this.detune.connect(this._oscillator.detune);
        time = this.toSeconds(time);
        this._oscillator.start(time);
    };
    Oscillator.prototype._stop = function (time) {
        if (this._oscillator) {
            time = this.toSeconds(time);
            this._oscillator.stop(time);
        }
        return this;
    };
    Oscillator.prototype.restart = function (time) {
        if (this._oscillator) {
            this._oscillator.cancelStop();
        }
        this._state.cancelAfter(this.toSeconds(time));
        return this;
    };
    return Oscillator;
}(Source_1.VoxSource));
exports.Oscillator = Oscillator;
Vox_1.Vox.Oscillator = Oscillator;

},{"../core/Vox":42,"../type":48,"./Source":25}],23:[function(require,module,exports){
"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
var Vox_1 = require("../core/Vox");
var type_1 = require("../type");
var AudioParam_1 = require("../core/AudioParam");
var VoxOscillatorNode = /** @class */ (function (_super) {
    __extends(VoxOscillatorNode, _super);
    function VoxOscillatorNode(opt) {
        var _this = _super.call(this) || this;
        _this._gain = 1;
        _this._startTime = -1;
        _this._stopTime = -1;
        opt = opt === undefined ? {} : opt;
        _this.onended = opt.onended === undefined ? function () { } : opt.onended;
        _this._oscillator = _this.context._ctx.createOscillator();
        // 包络
        _this._gainNode = _this.output = new Vox_1.Vox.VoxGain(0, type_1.VoxType.Default);
        Vox_1.Vox.connect(_this._oscillator, _this._gainNode);
        _this.type = opt.type === undefined ? type_1.OscilType.sine : opt.type;
        // 频率
        _this.frequency = new AudioParam_1.VoxAudioParam({
            param: _this._oscillator.frequency,
            units: type_1.VoxType.Frequency,
            value: opt.frequency === undefined ? 440 : opt.frequency,
        });
        // 音差
        _this.detune = new AudioParam_1.VoxAudioParam({
            param: _this._oscillator.detune,
            units: type_1.VoxType.Cents,
            value: opt.detune === undefined ? 0 : opt.detune
        });
        return _this;
    }
    VoxOscillatorNode.prototype.start = function (time) {
        if (this._startTime === -1) {
            this._startTime = this.toSeconds(time);
            this._startTime = Math.max(this._startTime, this.context._ctx.currentTime);
            this._oscillator.start(this._startTime);
            this._gainNode.gain.setValueAtTime(1, this._startTime);
        }
        else {
            console.warn('OscillatorNode 已经 start 过了');
        }
        return this;
    };
    VoxOscillatorNode.prototype.stop = function (time) {
        if (this._startTime === -1) {
            console.warn('必须现调用 satrt 才能 stop');
            return;
        }
        this.cancelStop();
        this._stopTime = this.toSeconds(time);
        this._stopTime = Math.max(this._stopTime, this.context._ctx.currentTime);
        if (this._stopTime > this._startTime) {
            this._gainNode.gain.setValueAtTime(0, this._stopTime);
            this._timeout = this.context.setTimeout(function () {
                this._oscillator.stop(this.now());
                this.onended();
            }.bind(this), this._stopTime - this.context._ctx.currentTime);
        }
        else {
        }
        return this;
    };
    VoxOscillatorNode.prototype.cancelStop = function () {
        if (this._startTime !== -1) {
            this._gainNode.gain.cancelScheduledValues(this._startTime + this.sampleTime);
            if (this._timeout !== undefined) {
                this.context.clearTimeout(this._timeout);
            }
            this._stopTime = -1;
        }
        return this;
    };
    Object.defineProperty(VoxOscillatorNode.prototype, "type", {
        get: function () {
            return this._oscillator.type;
        },
        set: function (value) {
            this._oscillator.type = value;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(VoxOscillatorNode.prototype, "state", {
        get: function () {
            return this.getStateAtTime(this.now());
        },
        enumerable: true,
        configurable: true
    });
    VoxOscillatorNode.prototype.getStateAtTime = function (time) {
        time = this.toSeconds(time);
        if (this._startTime !== -1 && time >= this._startTime && (this._stopTime === -1 || time <= this._stopTime)) {
            return type_1.PlayState.Started;
        }
        else {
            return type_1.PlayState.Stopped;
        }
    };
    VoxOscillatorNode.prototype.setPeriodicWave = function (periodicWave) {
        this._oscillator.setPeriodicWave(periodicWave);
        return this;
    };
    return VoxOscillatorNode;
}(Vox_1.Vox.VoxAudioNode));
exports.VoxOscillatorNode = VoxOscillatorNode;
Vox_1.Vox.VoxOscillatorNode = VoxOscillatorNode;

},{"../core/AudioParam":32,"../core/Vox":42,"../type":48}],24:[function(require,module,exports){
"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
var Vox_1 = require("../core/Vox");
var type_1 = require("../type");
var Player = /** @class */ (function (_super) {
    __extends(Player, _super);
    function Player(opt) {
        var _this = _super.call(this) || this;
        _this._activeSource = [];
        opt.onload = opt.onload === undefined ? function () { } : opt.onload;
        opt.reverse = opt.reverse === undefined ? false : opt.reverse;
        _this._playbackRate = opt.playbackRate === undefined ? 1 : opt.playbackRate;
        _this._loop = opt.loop === undefined ? false : opt.loop;
        _this.autostart = opt.autostart === undefined ? false : opt.autostart;
        _this._loopStartMoment = opt.loopStartMoment === undefined ? 0 : opt.loopStartMoment;
        _this._loopEndMoment = opt.loopEndMoment === undefined ? 0 : opt.loopEndMoment;
        _this.fadeInDuration = opt.fadeInDuration === undefined ? 0 : opt.fadeInDuration;
        _this.fadeOutDuration = opt.fadeOutDuration === undefined ? 0 : opt.fadeOutDuration;
        _this._buffer = new Vox_1.Vox.VoxBuffer({
            src: opt.src,
            onload: _this._onload.bind(_this, opt.onload)
        });
        return _this;
    }
    Player.prototype.load = function (src, callback) {
        return this._buffer.load(src, this._onload.bind(this, callback), function () { });
    };
    Player.prototype._onload = function (callback) {
        console.log('player._onload');
        if (callback !== undefined) {
            callback(this);
        }
        if (this.autostart) {
            this.start();
        }
    };
    Player.prototype._start = function (startTime, offset, duration) {
        if (this._loop) {
            offset = offset === undefined ? this._loopStartMoment : offset;
        }
        else {
            offset = offset === undefined ? 0 : offset;
        }
        offset = this.toSeconds(offset);
        var computedDuration = duration === undefined ? Math.max(this._buffer.duration - offset, 0) : duration;
        computedDuration = this.toSeconds(computedDuration) / this._playbackRate;
        startTime = this.toSeconds(startTime);
        // 每次都要 new 是因为 Source 是一次性的，start 方法只能被调用一次
        var source = new Vox_1.Vox.VoxBufferSource({
            buffer: this._buffer,
            loop: this._loop,
            loopStartMoment: this._loopStartMoment,
            loopEndMoment: this._loopEndMoment,
            onended: this._onSourceEnd.bind(this),
            playbackRate: this._playbackRate,
            fadeInDuration: this.fadeInDuration,
            fadeOutDuration: this.fadeOutDuration,
        }).connect(this.output);
        if (!this._loop) {
            this._state.setStateAtTime(type_1.PlayState.Stopped, startTime + computedDuration);
        }
        this._activeSource.push(source);
        if (this._loop && duration !== undefined) {
            source.start(startTime, offset);
        }
        else {
            source.start(startTime, offset, computedDuration - this.toSeconds(this.fadeOutDuration));
        }
        return this;
    };
    Player.prototype._stop = function (time) {
        time = this.toSeconds(time);
        this._activeSource.forEach(function (source) {
            source.stop(time);
        });
        return this;
    };
    Player.prototype.restart = function (time, offset, duration) {
        this._stop(time);
        this._start(time, offset, duration);
        return this;
    };
    Player.prototype._onSourceEnd = function (source) {
        var idx = this._activeSource.indexOf(source);
        this._activeSource.splice(idx, 1);
        if (this._activeSource.length === 0) {
            this._state.setStateAtTime(type_1.PlayState.Stopped, this.now());
        }
    };
    return Player;
}(Vox_1.Vox.VoxSource));
exports.Player = Player;
Vox_1.Vox.Player = Player;

},{"../core/Vox":42,"../type":48}],25:[function(require,module,exports){
"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
var Vox_1 = require("../core/Vox");
var type_1 = require("../type");
var VoxSource = /** @class */ (function (_super) {
    __extends(VoxSource, _super);
    function VoxSource(opt) {
        var _this = _super.call(this) || this;
        _this._scheduled = [];
        opt = (opt === undefined ? {} : opt);
        opt.mute = (opt.mute === undefined ? false : opt.mute);
        opt.volume = (opt.volume === undefined ? 0 : opt.volume);
        _this._volume = new Vox_1.Vox.Volume(opt.volume);
        _this.output = _this._volume;
        _this.volume = _this._volume.volume;
        _this._volume.output.output.channelCount = 2;
        _this._volume.output.output.channelCountMode = 'explicit';
        _this._state = new Vox_1.Vox.TimelineState(type_1.PlayState.Stopped);
        _this._state.memory = 100;
        _this._synced = false;
        _this.mute = opt.mute;
        return _this;
    }
    Object.defineProperty(VoxSource.prototype, "mute", {
        get: function () {
            return this._volume.mute;
        },
        set: function (val) {
            console.log('set mute', val);
            this._volume.mute = val;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(VoxSource.prototype, "state", {
        get: function () {
            if (this._synced) {
            }
            else {
                return this._state;
            }
        },
        enumerable: true,
        configurable: true
    });
    // Start the source at the specified time.
    VoxSource.prototype.start = function (time, offset, duration) {
        if (time === undefined && this._synced) {
        }
        else {
            time = this.toSeconds(time);
            time = Math.max(time, this.context._ctx.currentTime);
        }
        if (this._state.getRecentValueAtTime(time) === type_1.PlayState.Started) {
            this._state.cancelAfter(time);
            this._state.setStateAtTime(type_1.PlayState.Started, time);
            this.restart(time, offset, duration);
        }
        else {
            this._state.setStateAtTime(type_1.PlayState.Started, time);
            if (this._synced) {
            }
            else {
                this._start.apply(this, arguments);
            }
        }
        return this;
    };
    VoxSource.prototype.stop = function (time) {
        if (time === undefined && this._synced) {
        }
        else {
            time = this.toSeconds(time);
            time = Math.max(time, this.context._ctx.currentTime);
        }
        if (!this._synced) {
            this._stop.apply(this, arguments);
        }
        else {
        }
        this._state.cancelAfter(time);
        this._state.setStateAtTime(type_1.PlayState.Stopped, time);
    };
    return VoxSource;
}(Vox_1.Vox.VoxAudioNode));
exports.VoxSource = VoxSource;
Vox_1.Vox.VoxSource = VoxSource;

},{"../core/Vox":42,"../type":48}],26:[function(require,module,exports){
"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
var Vox_1 = require("../core/Vox");
var type_1 = require("../type");
var TickSource = /** @class */ (function (_super) {
    __extends(TickSource, _super);
    function TickSource(frequency) {
        var _this = _super.call(this) || this;
        frequency = frequency === undefined ? 1 : frequency;
        _this.frequency = new Vox_1.Vox.TickCounter(frequency);
        _this._state = new Vox_1.Vox.TimelineState(type_1.PlayState.Stopped);
        _this._state.setStateAtTime(type_1.PlayState.Stopped, 0);
        _this._tickOffset = new Vox_1.Vox.Timeline(Infinity);
        _this.setTicksAtTime(0, 0);
        return _this;
    }
    TickSource.prototype.getTimeOfTick = function (tick, before) {
        before = before === undefined ? this.now() : before;
        var offset = this._tickOffset.getMostRecent(before);
        var event = this._state.getMostRecent(before);
        var startTime = Math.max(offset.time, event.time);
        var absoluteTicks = this.frequency.getTicksAtTime(startTime);
        return this.frequency.getTimeOfTick(absoluteTicks);
    };
    TickSource.prototype.setTicksAtTime = function (ticks, time) {
        time = this.toSeconds(time);
        this._tickOffset.cancelAfter(time);
        this._tickOffset.add({
            time: time,
            ticks: ticks,
            seconds: this.frequency.getDurationOfTicks(ticks, time),
        });
        return this;
    };
    TickSource.prototype.getTicksAtTime = function (time) {
        var _this = this;
        time = this.toSeconds(time);
        var stopEvent = this._state.getLastState(type_1.PlayState.Stopped, time);
        var tmpEvent = {
            state: type_1.PlayState.Paused,
            time: time,
        };
        this._state.add(tmpEvent);
        var lastState = stopEvent;
        var elapsedTicks = 0;
        this._state.forEachBetween(stopEvent.time, time + this.sampleTime, function (e) {
            var periodStartTime = lastState.time;
            var offsetEvent = _this._tickOffset.getMostRecent(e.time);
            if (offsetEvent.time >= lastState.time) {
                elapsedTicks = offsetEvent.ticks;
                periodStartTime = offsetEvent.time;
            }
            if (lastState.state === type_1.PlayState.Started && e.state !== type_1.PlayState.Started) {
                elapsedTicks += _this.frequency.getTicksAtTime(e.time) - _this.frequency.getTicksAtTime(periodStartTime);
            }
            lastState = e;
        });
        this._state.remove(tmpEvent);
        return elapsedTicks;
    };
    Object.defineProperty(TickSource.prototype, "ticks", {
        get: function () {
            return this.getTicksAtTime(this.now());
        },
        set: function (t) {
            this.setTicksAtTime(t, this.now());
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(TickSource.prototype, "seconds", {
        get: function () {
            return this.getSecondsAtTime(this.now());
        },
        set: function (s) {
            var now = this.now();
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(TickSource.prototype, "state", {
        get: function () {
            return this._state.getRecentValueAtTime(this.now());
        },
        enumerable: true,
        configurable: true
    });
    TickSource.prototype.getSecondsAtTime = function (time) {
        var _this = this;
        time = this.toSeconds(time);
        var stopEvent = this._state.getLastState(type_1.PlayState.Stopped, time);
        var tmpEvent = { state: type_1.PlayState.Paused, time: time };
        this._state.add(tmpEvent);
        var lastState = stopEvent;
        var elapsedSeconds = 0;
        this._state.forEachBetween(stopEvent.time, time + this.sampleTime, function (e) {
            var periodStartTime = lastState.time;
            var offsetEvent = _this._tickOffset.getMostRecent(e.time);
            if (offsetEvent.time >= lastState.time) {
                elapsedSeconds = offsetEvent.seconds;
                periodStartTime = offsetEvent.time;
            }
            if (lastState.state === type_1.PlayState.Started && e.state !== type_1.PlayState.Started) {
                elapsedSeconds += e.time - periodStartTime;
            }
            lastState = e;
        });
        this._state.remove(tmpEvent);
        return elapsedSeconds;
    };
    TickSource.prototype.start = function (time, offset) {
        time = this.toSeconds(time);
        if (this._state.getRecentValueAtTime(time) !== type_1.PlayState.Started) {
            this._state.setStateAtTime(type_1.PlayState.Started, time);
            if (Vox_1.Vox.isDefined(offset)) {
                this.setTicksAtTime(offset, time);
            }
        }
        return this;
    };
    TickSource.prototype.pause = function (time) {
        time = this.toSeconds(time);
        if (this._state.getRecentValueAtTime(time) === type_1.PlayState.Started) {
            this._state.setStateAtTime(type_1.PlayState.Paused, time);
        }
        return this;
    };
    TickSource.prototype.stop = function (time) {
        time = this.toSeconds(time);
        if (this._state.getRecentValueAtTime(time) === type_1.PlayState.Stopped) {
            var event_1 = this._state.getMostRecent(time);
            if (event_1.time > 0) {
                this._tickOffset.cancelAfter(event_1.time);
                this._state.cancelAfter(event_1.time);
            }
        }
        this._state.cancelAfter(time);
        this._state.setStateAtTime(type_1.PlayState.Stopped, time);
        this.setTicksAtTime(0, time);
        return this;
    };
    TickSource.prototype.forEachTickBetween = function (startTime, endTime, callback) {
        var _this = this;
        // 
        var lastStateEvent = this._state.getMostRecent(startTime);
        this._state.forEachBetween(startTime, endTime, function (event) {
            if (lastStateEvent.state === type_1.PlayState.Started && event.state !== type_1.PlayState.Started) {
                _this.forEachTickBetween(Math.max(lastStateEvent.time, startTime), event.time - _this.sampleTime, callback);
            }
            lastStateEvent = event;
        });
        // console.log('lastStateEvent', lastStateEvent);
        startTime = Math.max(lastStateEvent.time, startTime);
        if (lastStateEvent.state === type_1.PlayState.Started && this._state) {
            var startTicks = this.frequency.getTicksAtTime(startTime);
            var ticksAtStart = this.frequency.getTicksAtTime(lastStateEvent.time);
            var diff = startTicks - ticksAtStart;
            var offset = diff % 1;
            if (offset !== 0) {
                offset = 1 - offset;
            }
            var nextTickTime = this.frequency.getTimeOfTick(startTicks + offset);
            while (nextTickTime < endTime && this._state) {
                try {
                    var tick = Math.round(this.getTicksAtTime(nextTickTime));
                    callback(nextTickTime, tick);
                }
                catch (e) {
                    console.log('error', e);
                    break;
                }
                if (this._state) {
                    nextTickTime += this.frequency.getDurationOfTicks(1, nextTickTime);
                }
            }
        }
        return this;
    };
    return TickSource;
}(Vox_1.Vox));
exports.TickSource = TickSource;
Vox_1.Vox.TickSource = TickSource;

},{"../core/Vox":42,"../type":48}],27:[function(require,module,exports){
"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
var Vox_1 = require("../core/Vox");
var type_1 = require("../type");
var AmplitudeEnvelope = /** @class */ (function (_super) {
    __extends(AmplitudeEnvelope, _super);
    function AmplitudeEnvelope(opt) {
        var _this = _super.call(this, opt) || this;
        _this.input = _this.output = new Vox_1.Vox.VoxGain(1, type_1.VoxType.Default);
        _this.sig.connect(_this.output.gain);
        return _this;
    }
    return AmplitudeEnvelope;
}(Vox_1.Vox.Envelope));
exports.AmplitudeEnvelope = AmplitudeEnvelope;
Vox_1.Vox.AmplitudeEnvelope = AmplitudeEnvelope;

},{"../core/Vox":42,"../type":48}],28:[function(require,module,exports){
"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
var Vox_1 = require("../core/Vox");
var util_1 = require("util");
var linear = 'linear';
var exponential = 'exponential';
var EnvelopeDefault = {
    attack: 0.01,
    decay: 0.1,
    sustain: 0.5,
    release: 1,
    attackCurve: linear,
    decayCurve: exponential,
    releaseCurve: exponential,
};
var Envelope = /** @class */ (function (_super) {
    __extends(Envelope, _super);
    function Envelope(opt) {
        var _this = _super.call(this) || this;
        opt = (opt === undefined) ? {} : opt;
        _this.attack = (opt.attack === undefined) ? EnvelopeDefault.attack : opt.attack;
        _this.decay = (opt.decay === undefined) ? EnvelopeDefault.decay : opt.decay;
        _this.sustain = (opt.sustain === undefined) ? EnvelopeDefault.sustain : opt.sustain;
        _this.release = (opt.release === undefined) ? EnvelopeDefault.release : opt.release;
        _this._attackCurve = linear;
        _this._releaseCurve = exponential;
        _this.sig = _this.output = new Vox_1.Vox.Signal({ value: 0 });
        _this.attackCurve = opt.attackCurve === undefined ? linear : opt.attackCurve;
        _this.releaseCurve = opt.releaseCurve === undefined ? exponential : opt.releaseCurve;
        _this.decayCurve = opt.decayCurve === undefined ? exponential : opt.decayCurve;
        _this.connect = Vox_1.Vox.Signal.prototype.connect.bind(_this);
        return _this;
    }
    Envelope.prototype._getCurve = function (curve, direction) {
        if (Vox_1.Vox.isString(curve)) {
            return curve;
        }
        else if (util_1.isArray(curve)) {
            for (var t in Envelope.Type) {
                if (Envelope.Type[t][direction] === curve) {
                    return t;
                }
            }
        }
    };
    Envelope.prototype._setCurve = function (name, direction, curve) {
        if (Envelope.Type.hasOwnProperty(curve)) {
            var curveDef = Envelope.Type[curve];
            if (util_1.isObject(curveDef)) {
                this[name] = curveDef[direction];
            }
            else {
                this[name] = curveDef;
            }
        }
        else if (util_1.isArray(curve)) {
            this[name] = curve;
        }
        else {
            throw new Error('Envelopt: invalid curve: ' + curve);
        }
    };
    Object.defineProperty(Envelope.prototype, "attackCurve", {
        get: function () {
            return this._getCurve(this._attackCurve, 'In');
        },
        set: function (curve) {
            this._setCurve('_attackCurve', 'In', curve);
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(Envelope.prototype, "releaseCurve", {
        get: function () {
            return this._getCurve(this._releaseCurve, 'Out');
        },
        set: function (curve) {
            this._setCurve('_releaseCurve', 'Out', curve);
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(Envelope.prototype, "decayCurve", {
        get: function () {
            return this._decayCurve;
        },
        set: function (curve) {
            if (curve !== linear && curve != exponential) {
                throw new Error('Envelope: invalid curve ' + curve);
            }
            else {
                this._decayCurve = curve;
            }
        },
        enumerable: true,
        configurable: true
    });
    Envelope.prototype.triggerAttack = function (time, velocity) {
        console.log('triggerAttack', time, velocity);
        time = this.toSeconds(this.attack);
        var originalAttack = this.toSeconds(this.attack);
        var attack = originalAttack;
        var decay = this.toSeconds(this.decay);
        velocity = velocity === undefined ? 1 : velocity;
        var currentValue = this.getValueAtTime(time);
        if (currentValue > 0) {
            var attackRate = 1 / attack;
            var remainingDistance = 1 - currentValue;
            attack = remainingDistance / attackRate;
        }
        if (this._attackCurve === linear) {
            this.sig.linearRampTo(velocity, attack, time);
        }
        else if (this._attackCurve === exponential) {
            this.sig.targetRampTo(velocity, attack, time);
        }
        else if (attack > 0) {
            this.sig.cancelAndHoldAtTime(time);
            // _attackCurve 是一个数组的情况，就是自定义的包络函数
            var curve = this._attackCurve;
            for (var i = 0; i < curve.length; i++) {
                if (curve[i - 1] <= currentValue && currentValue <= curve[i]) {
                    curve = this._attackCurve.slice(i);
                    curve[0] = currentValue;
                    break;
                }
            }
            this.sig.setValueCurveAtTime(curve, time, attack, velocity);
        }
        if (decay) {
            var decayValue = velocity * this.sustain;
            var decayStart = time + attack;
            console.log('decay', decayStart);
            if (this._decayCurve === linear) {
                this.sig.linearRampTo(decayValue, decay, decayStart + this.sampleTime);
            }
            else if (this._decayCurve === exponential) {
                this.sig.exponentialApproachValueAtTime(decayValue, decayStart, decay);
            }
        }
        return this;
    };
    Envelope.prototype.triggerRelease = function (time) {
        console.log('triggerRelease', time);
        time = this.toSeconds(time);
        var currentValue = this.getValueAtTime(time);
        if (currentValue > 0) {
            var release = this.toSeconds(this.release);
            if (this._releaseCurve === linear) {
                this.sig.linearRampTo(0, release, time);
            }
            else if (this._releaseCurve === exponential) {
                this.sig.targetRampTo(0, release, time);
            }
            else {
                var curve = this._releaseCurve;
                if (util_1.isArray(curve)) {
                    this.sig.cancelAndHoldAtTime(time);
                    this.sig.setValueCurveAtTime(curve, time, release, currentValue);
                }
            }
        }
        return this;
    };
    Envelope.prototype.getValueAtTime = function (time) {
        return this.sig.getValueAtTime(time);
    };
    Envelope.prototype.triggerAttackRelease = function (duration, time, velocity) {
        time = this.toSeconds(time);
        this.triggerAttack(time, velocity);
        this.triggerRelease(time + this.toSeconds(duration));
        return this;
    };
    Envelope.prototype.cancel = function (after) {
        this.sig.cancelScheduledValues(after);
        return this;
    };
    return Envelope;
}(Vox_1.Vox.VoxAudioNode));
exports.Envelope = Envelope;
(function _createCurves() {
    var curveLen = 128;
    var i;
    var k;
    var cosineCurve = [];
    for (i = 0; i < curveLen; i++) {
        cosineCurve[i] = Math.sin((i / (curveLen - 1)) * (Math.PI / 2));
    }
    var rippleCurve = [];
    var rippleCurveFreq = 6.4;
    for (i = 0; i < curveLen - 1; i++) {
        k = (i / (curveLen - 1));
        var sineWave = Math.sin(k * (Math.PI * 2) * rippleCurveFreq - Math.PI / 2) + 1;
        rippleCurve[i] = sineWave / 10 + k * 0.83;
    }
    rippleCurve[curveLen - 1] = 1;
    var stairsCurve = [];
    var steps = 5;
    for (i = 0; i < curveLen; i++) {
        stairsCurve[i] = Math.ceil((i / (curveLen - 1)) * steps) / steps;
    }
    var sineCurve = [];
    for (i = 0; i < curveLen; i++) {
        k = i / (curveLen - 1);
        sineCurve[i] = 0.5 * (1 - Math.cos(Math.PI * k));
    }
    var bounceCurve = [];
    for (i = 0; i < curveLen; i++) {
        k = i / (curveLen - 1);
        var freq = Math.pow(k, 3) * 4 + 0.2;
        var val = Math.cos(freq * Math.PI * 2 * k);
        bounceCurve[i] = Math.abs(val * (1 - k));
    }
    function invertCurve(curve) {
        var out = new Array(curve.length);
        for (var j = 0; j < curve.length; j++) {
            out[j] = 1 - curve[j];
        }
        return out;
    }
    function reverseCurve(curve) {
        return curve.slice(0).reverse();
    }
    if (!Envelope.Type) {
        Envelope.Type = {
            linear: linear,
            exponential: exponential,
            bounce: {
                In: invertCurve(bounceCurve),
                Out: bounceCurve
            },
            cosine: {
                In: cosineCurve,
                Out: reverseCurve(cosineCurve)
            },
            step: {
                In: stairsCurve,
                Out: invertCurve(stairsCurve)
            },
            ripple: {
                In: rippleCurve,
                Out: invertCurve(rippleCurve)
            },
            sine: {
                In: sineCurve,
                Out: invertCurve(sineCurve)
            }
        };
    }
})();
Vox_1.Vox.Envelope = Envelope;

},{"../core/Vox":42,"util":14}],29:[function(require,module,exports){
"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
var Vox_1 = require("../core/Vox");
var type_1 = require("../type");
var TickCounter = /** @class */ (function (_super) {
    __extends(TickCounter, _super);
    function TickCounter(value) {
        var _this = this;
        value = value === undefined ? 1 : value;
        _this = _super.call(this, { units: type_1.VoxType.Ticks, value: value }) || this;
        _this.output = Vox_1.Vox.context._ctx.createGain();
        _this.input = _this.output.gain;
        _this._param = _this.input;
        _this._timelineEv.memory = Infinity;
        _this.cancelScheduledValues(0);
        _this._timelineEv.add({
            type: Vox_1.Vox.VoxAudioParam.ActionType.SetValue,
            time: 0,
            value: value,
        });
        return _this;
    }
    TickCounter.prototype.setValueAtTime = function (value, time) {
        time = this.toSeconds(time);
        value = this._fromUnits(value);
        this._timelineEv.add({
            time: time,
            value: value,
            type: Vox_1.Vox.VoxAudioParam.ActionType.SetValue,
        });
        this._param.setValueAtTime(value, time);
        var event = this._timelineEv.getMostRecent(time);
        var previousEvent = this._timelineEv.previousEvent(event);
        var ticksTillTime = this._getTicksSinceEvent(previousEvent, time);
        event.ticks = Math.max(ticksTillTime, 0);
        return this;
    };
    TickCounter.prototype.linearRampToValueAtTime = function (value, endTime) {
        value = this._fromUnits(value);
        endTime = this.toSeconds(endTime);
        this._timelineEv.add({
            type: Vox_1.Vox.VoxAudioParam.ActionType.Linear,
            value: value,
            time: endTime,
        });
        this._param.linearRampToValueAtTime(value, endTime);
        var event = this._timelineEv.getMostRecent(endTime);
        var previousEvent = this._timelineEv.previousEvent(event);
        var ticksTillTime = this._getTicksSinceEvent(previousEvent, endTime);
        event.ticks = Math.max(ticksTillTime, 0);
        return this;
    };
    TickCounter.prototype._getTicksSinceEvent = function (event, time) {
        if (event === null) {
            event = {
                ticks: 0,
                time: 0
            };
        }
        else if (Vox_1.Vox.isUndef(event.ticks)) {
            var previousEvent = this._timelineEv.previousEvent(event);
            event.ticks = this._getTicksSinceEvent(previousEvent, event.time);
        }
        var val0 = this.getValueAtTime(event.time);
        var val1 = this.getValueAtTime(time);
        if (this._timelineEv.getMostRecent(time).time === time &&
            this._timelineEv.getMostRecent(time).type === Vox_1.Vox.VoxAudioParam.ActionType.SetValue) {
            val1 = this.getValueAtTime(time - this.sampleTime);
        }
        return 0.5 * (time - event.time) * (val0 + val1) + event.ticks;
    };
    TickCounter.prototype.getTicksAtTime = function (time) {
        time = this.toSeconds(time);
        var event = this._timelineEv.getMostRecent(time);
        return Math.max(this._getTicksSinceEvent(event, time), 0);
    };
    TickCounter.prototype.getTimeOfTick = function (tick) {
        var recent = this._timelineEv.getMostRecent(tick, 'ticks');
        var after = this._timelineEv.getAfter(tick, 'ticks');
        if (recent && recent.ticks === tick) {
            return recent.time;
        }
        else if (recent && after &&
            after.type === Vox_1.Vox.VoxAudioParam.ActionType.Linear &&
            recent.value !== after.value) {
            var val0 = this.getValueAtTime(recent.time);
            var val1 = this.getValueAtTime(after.time);
            var delta = (val1 - val0) / (after.time - recent.time);
            var k = Math.sqrt(Math.pow(val0, 2) - 2 * delta * (recent.ticks - tick));
            var sol1 = (-val0 + k) / delta;
            var sol2 = (-val1 - k) / delta;
            return (sol1 > 0 ? sol1 : sol2) + recent.time;
        }
        else if (recent) {
            if (recent.value === 0) {
                return Infinity;
            }
            else {
                return recent.time + (tick - recent.ticks) / recent.value;
            }
        }
        else {
            return tick / this._initValue;
        }
    };
    TickCounter.prototype.ticksToTime = function (ticks, when) {
        when = this.toSeconds(when);
        return new Vox_1.Vox.Time(this.getDurationOfTicks(ticks, when));
    };
    TickCounter.prototype.getDurationOfTicks = function (ticks, time) {
        time = this.toSeconds(time);
        var currentTick = this.getTicksAtTime(time);
        return this.getTimeOfTick(currentTick + ticks) - time;
    };
    TickCounter.prototype.timeToTicks = function (duration, when) {
        when = this.toSeconds(when);
        duration = this.toSeconds(duration);
        var startTicks = this.getTicksAtTime(when);
        var endTicks = this.getTicksAtTime(when + duration);
        return new Vox_1.Vox.Ticks(endTicks - startTicks);
    };
    return TickCounter;
}(Vox_1.Vox.VoxAudioParam));
exports.TickCounter = TickCounter;
Vox_1.Vox.TickCounter = TickCounter;

},{"../core/Vox":42,"../type":48}],30:[function(require,module,exports){
"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
var Vox_1 = require("../core/Vox");
var type_1 = require("../type");
var Volume = /** @class */ (function (_super) {
    __extends(Volume, _super);
    function Volume(volume) {
        var _this = _super.call(this) || this;
        // 数值为 分贝
        _this.output = _this.input = new Vox_1.Vox.VoxGain(volume, type_1.VoxType.Decibels);
        _this.initialVolume = volume;
        _this.volume = _this.output.gain;
        _this.mute = false;
        return _this;
    }
    Object.defineProperty(Volume.prototype, "mute", {
        get: function () {
            return this.volume.value === -Infinity;
        },
        set: function (mute) {
            if (!this.mute && mute) {
                this.initialVolume = this.volume.value;
                this.volume.value = -Infinity;
            }
            else if (this.mute && !mute) {
                this.volume.value = this.initialVolume;
            }
        },
        enumerable: true,
        configurable: true
    });
    return Volume;
}(Vox_1.Vox.VoxAudioNode));
exports.Volume = Volume;
Vox_1.Vox.Volume = Volume;

},{"../core/Vox":42,"../type":48}],31:[function(require,module,exports){
"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
var Vox_1 = require("./Vox");
var VoxAudioNode = /** @class */ (function (_super) {
    __extends(VoxAudioNode, _super);
    function VoxAudioNode() {
        var _this = _super.call(this) || this;
        _this.context = Vox_1.Vox.context;
        return _this;
    }
    VoxAudioNode.prototype.createInsOuts = function (inputs, outputs) {
        if (inputs === 1) {
            this.input = this.context._ctx.createGain();
        }
        else if (inputs > 1) {
            this.input = new Array(inputs);
        }
        if (outputs === 1) {
            this.output = this.context._ctx.createGain();
        }
        else if (outputs > 1) {
            this.output = new Array(outputs);
        }
    };
    Object.defineProperty(VoxAudioNode.prototype, "channelCount", {
        get: function () {
            if (Array.isArray(this.output)) {
                return;
            }
            return this.output.channelCount;
        },
        set: function (c) {
            if (Array.isArray(this.output)) {
                return;
            }
            this.output.channelCount = c;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(VoxAudioNode.prototype, "channelCountMode", {
        get: function () {
            if (Array.isArray(this.output)) {
                return;
            }
            return this.output.channelCountMode;
        },
        set: function (mode) {
            if (Array.isArray(this.output)) {
                return;
            }
            this.output.channelCountMode = mode;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(VoxAudioNode.prototype, "numberOfInputs", {
        get: function () {
            if (this.input) {
                if (Array.isArray(this.input)) {
                    return this.input.length;
                }
                else {
                    return 1;
                }
            }
            else {
                return 0;
            }
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(VoxAudioNode.prototype, "numberOfOutpus", {
        get: function () {
            if (this.output) {
                if (Array.isArray(this.output)) {
                    return this.output.length;
                }
                else {
                    return 1;
                }
            }
            else {
                return 0;
            }
        },
        enumerable: true,
        configurable: true
    });
    VoxAudioNode.prototype.connect = function (unit, outputNum, inputNum) {
        if (Array.isArray(this.output)) {
            this.output[outputNum].connect(unit, 0, inputNum);
        }
        else {
            Vox_1.Vox.connect(this.output, unit, outputNum, inputNum);
        }
        return this;
    };
    VoxAudioNode.prototype.disconnect = function (destination, outputNum, inputNum) {
        if (Array.isArray(this.output)) {
            outputNum = (outputNum === undefined ? 0 : outputNum);
            this.output[outputNum].disconnect(destination, 0, inputNum);
        }
        else {
            Vox_1.Vox.disconnect(this.output, destination, outputNum, inputNum);
        }
        return this;
    };
    VoxAudioNode.prototype.toMaster = function () {
        this.connect(this.context.master);
        return this;
    };
    VoxAudioNode.prototype.toString = function () {
        console.log('Hi, I am VoxAudioNode');
    };
    return VoxAudioNode;
}(Vox_1.Vox));
exports.VoxAudioNode = VoxAudioNode;
Vox_1.Vox.VoxAudioNode = VoxAudioNode;

},{"./Vox":42}],32:[function(require,module,exports){
"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
var Vox_1 = require("./Vox");
var type_1 = require("../type");
var VoxAudioParam = /** @class */ (function (_super) {
    __extends(VoxAudioParam, _super);
    function VoxAudioParam(opt) {
        var _this = _super.call(this) || this;
        _this._miniOutput = 1e-5;
        _this.overridden = false;
        _this._param = _this.input = opt.param;
        _this.units = opt.units;
        _this.convert = (opt.convert === undefined ? true : opt.convert);
        _this._timelineEv = new Vox_1.Vox.Timeline(1000);
        if (Vox_1.Vox.isDefined(opt.value) && _this._param) {
            _this.setValueAtTime(opt.value, 0);
        }
        return _this;
    }
    Object.defineProperty(VoxAudioParam.prototype, "value", {
        get: function () {
            return this._toUnits(this.getValueAtTime(this.now()));
        },
        set: function (val) {
            this._initValue = this._fromUnits(val);
            this.cancelScheduledValues(this.now());
            this.setValueAtTime(val, this.now());
        },
        enumerable: true,
        configurable: true
    });
    // get minValue() {
    //   if (this.units === VoxType.Time || this.units === VoxType.Frequency ||
    //       this.units === VoxType.Positive || this.units === VoxType.BPM) {
    //     return 0;
    //   } else if (this.units === VoxType.Decibels) {
    //     return -Infinity;
    //   } else {
    //     return this._param.minValue;
    //   }
    // }
    // get maxValue() {
    //   return this._param.maxValue;
    // }
    VoxAudioParam.prototype.setValueCurveAtTime = function (values, startTime, duration, scaling) {
        if (scaling === void 0) { scaling = 1; }
        duration = this.toSeconds(duration);
        startTime = this.toSeconds(startTime);
        this.setValueAtTime(values[0] * scaling, startTime);
        var segTime = duration / (values.lenght - 1);
        for (var i = 1; i < values.lenght; i++) {
            this.linearRampToValueAtTime(values[i] * scaling, startTime + i * segTime);
        }
        return this;
    };
    VoxAudioParam.prototype.cancelScheduledValues = function (time) {
        time = this.toSeconds(time);
        this._timelineEv.cancelAfter(time);
        this._param.cancelScheduledValues(time);
        console.log('cancelScheduledValues', time);
        return this;
    };
    VoxAudioParam.prototype.cancelAndHoldAtTime = function (time) {
        var valueAtTime = this.getValueAtTime(time);
        console.log('cancelScheduledValues', time, 'value = ', valueAtTime);
        this._param.cancelScheduledValues(time);
        var recent = this._timelineEv.getMostRecent(time);
        var after = this._timelineEv.getAfter(time);
        if (recent && recent.time === time) {
            if (after) {
                this._timelineEv.cancelAfter(after.time);
            }
            else {
                this._timelineEv.cancelAfter(time + this.sampleTime);
            }
        }
        else if (after) {
            this._timelineEv.cancelAfter(after.time);
            if (after.type === VoxAudioParam.ActionType.Linear) {
                this.linearRampToValueAtTime(valueAtTime, time);
            }
            else if (after.type === VoxAudioParam.ActionType.Exponential) {
                this.exponentialRampToValueAtTime(valueAtTime, time);
            }
        }
        this._timelineEv.add({
            type: VoxAudioParam.ActionType.SetValue,
            value: valueAtTime,
            time: time,
        });
        this._param.setValueAtTime(valueAtTime, time);
        return this;
    };
    VoxAudioParam.prototype.setValueAtTime = function (value, time) {
        time = this.toSeconds(time);
        value = this._fromUnits(value);
        this._timelineEv.add({
            time: time,
            value: value,
            type: VoxAudioParam.ActionType.SetValue,
        });
        this._param.setValueAtTime(value, time);
        console.log(VoxAudioParam.ActionType.SetValue, value, time);
        return this;
    };
    VoxAudioParam.prototype.setRampPoint = function (time) {
        time = this.toSeconds(time);
        var currentVal = this.getValueAtTime(time);
        this.cancelAndHoldAtTime(time);
        if (currentVal === 0) {
            currentVal = this._miniOutput;
        }
        this.setValueAtTime(this._toUnits(currentVal), time);
        return this;
    };
    VoxAudioParam.prototype.targetRampTo = function (value, rampTime, startTime) {
        startTime = this.toSeconds(startTime);
        this.setRampPoint(startTime);
        this.exponentialApproachValueAtTime(value, startTime, rampTime);
        return this;
    };
    // 没有 startTime 就默认是当前时间
    VoxAudioParam.prototype.exponentialRampTo = function (value, rampTime, startTime) {
        startTime = this.toSeconds(startTime);
        this.setRampPoint(startTime);
        this.exponentialRampToValueAtTime(value, startTime + this.toSeconds(rampTime));
        return this;
    };
    // 没有 startTime 就默认是当前时间
    VoxAudioParam.prototype.linearRampTo = function (value, rampTime, startTime) {
        startTime = this.toSeconds(startTime);
        this.setRampPoint(startTime);
        console.log('startTime:', startTime, 'endTime', startTime + this.toSeconds(rampTime));
        this.linearRampToValueAtTime(value, startTime + this.toSeconds(rampTime));
        return this;
    };
    VoxAudioParam.prototype.exponentialApproachValueAtTime = function (value, time, rampTime) {
        var timeConstant = Math.log(this.toSeconds(rampTime) + 1) / Math.log(200);
        time = this.toSeconds(time);
        return this.setTargetAtTime(value, time, timeConstant);
    };
    VoxAudioParam.prototype.linearRampToValueAtTime = function (value, endTime) {
        value = this._fromUnits(value);
        endTime = this.toSeconds(endTime);
        this._timelineEv.add({
            type: VoxAudioParam.ActionType.Linear,
            value: value,
            time: endTime,
        });
        console.log(VoxAudioParam.ActionType.Linear, value, endTime);
        this._param.linearRampToValueAtTime(value, endTime);
        return this;
    };
    VoxAudioParam.prototype.exponentialRampToValueAtTime = function (value, endTime) {
        value = this._fromUnits(value);
        value = Math.max(this._miniOutput, value);
        endTime = this.toSeconds(endTime);
        this._timelineEv.add({
            type: VoxAudioParam.ActionType.Exponential,
            time: endTime,
            value: value,
        });
        console.log(VoxAudioParam.ActionType.Exponential, value, endTime);
        this._param.exponentialRampToValueAtTime(value, endTime);
        return this;
    };
    VoxAudioParam.prototype._toUnits = function (value) {
        if (this.convert || Vox_1.Vox.isDefined(this.convert)) {
            if (this.units === type_1.VoxType.Decibels) {
                return this.gainToDb(value);
            }
            else {
                return value;
            }
        }
        else {
            return value;
        }
    };
    VoxAudioParam.prototype._fromUnits = function (value) {
        if (this.convert || Vox_1.Vox.isUndef(this.convert)) {
            switch (this.units) {
                case type_1.VoxType.Time:
                    return this.toSeconds(value);
                case type_1.VoxType.Decibels:
                    return this.dbToGain(value);
                case type_1.VoxType.Frequency:
                    return this.toFrequency(value);
                default:
                    return value;
            }
        }
        else {
            return value;
        }
    };
    VoxAudioParam.prototype.setTargetAtTime = function (value, startTime, timeConstant) {
        value = this._fromUnits(value);
        if (timeConstant <= 0) {
            throw new Error("timeConstant must be greater than 0");
        }
        startTime = this.toSeconds(startTime);
        this._timelineEv.add({
            type: VoxAudioParam.ActionType.Target,
            value: value,
            time: startTime,
            constant: timeConstant,
        });
        console.log('setTargetAtTime', value, startTime, timeConstant);
        this._param.setTargetAtTime(value, startTime, timeConstant);
        return this;
    };
    VoxAudioParam.prototype.getValueAtTime = function (time) {
        time = this.toSeconds(time);
        var after = this._timelineEv.getAfter(time);
        var recent = this._timelineEv.getMostRecent(time);
        var initValue = (this._initValue !== undefined) ? this._initValue : this._param.defaultValue;
        var value = initValue;
        if (recent === null) {
            value = initValue;
        }
        else if (recent.type === VoxAudioParam.ActionType.Target) {
            // 因为 SetTarget 事件的 value 是终止值，所以要获得起始值还要再往前找
            var previous = this._timelineEv.getBefore(recent.time);
            var previousVal = void 0;
            if (previous === null) {
                previousVal = initValue;
            }
            else {
                previousVal = previous.value;
            }
            value = this._exponentialApproach(recent.time, previousVal, recent.value, recent.constant, time);
        }
        else if (after === null) {
            value = recent.value;
        }
        else if (after.type === VoxAudioParam.ActionType.Linear) {
            value = this._linearInterpolate(recent.time, recent.value, after.time, after.value, time);
        }
        else if (after.type === VoxAudioParam.ActionType.Exponential) {
            value = this._exponentialInterpolate(recent.time, recent.value, after.time, after.value, time);
        }
        else {
            value = recent.value;
        }
        return value;
    };
    ///////////////////////////////////////////////////////////////////////////
    //	AUTOMATION CURVE CALCULATIONS
    //	MIT License, copyright (c) 2014 Jordan Santell
    ///////////////////////////////////////////////////////////////////////////
    VoxAudioParam.prototype._exponentialApproach = function (t0, v0, v1, timeConstant, t) {
        return v1 + (v0 - v1) * Math.exp(-(t - t0) / timeConstant);
    };
    VoxAudioParam.prototype._linearInterpolate = function (t0, v0, t1, v1, t) {
        return v0 + (v1 - v0) * ((t - t0) / (t1 - t0));
    };
    VoxAudioParam.prototype._exponentialInterpolate = function (t0, v0, t1, v1, t) {
        return v0 * Math.pow(v1 / v0, (t - t0) / (t1 - t0));
    };
    VoxAudioParam.ActionType = {
        Linear: 'linearRampToValueAtTime',
        Exponential: 'exponentialRampToValueAtTime',
        Target: 'setTargetAtTime',
        SetValue: 'setValueAtTime',
        Cancel: 'cancelScheduledValues',
    };
    return VoxAudioParam;
}(Vox_1.Vox.VoxAudioNode));
exports.VoxAudioParam = VoxAudioParam;
Vox_1.Vox.VoxAudioParam = VoxAudioParam;

},{"../type":48,"./Vox":42}],33:[function(require,module,exports){
"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
var Vox_1 = require("./Vox");
var ts_promise_1 = require("ts-promise");
var VoxBuffer = /** @class */ (function (_super) {
    __extends(VoxBuffer, _super);
    function VoxBuffer(opt) {
        var _this = _super.call(this) || this;
        _this._buffer = null;
        _this._reversed = false;
        _this.onload = function () { };
        _this.name = 'VoxBuffer';
        opt = opt === undefined ? {} : opt;
        opt.onload = (opt.onload === undefined) ? (function () { }) : opt.onload;
        opt.onerror = (opt.onerror === undefined) ? (function () { }) : opt.onerror;
        if (opt.src) {
            if (opt.src instanceof AudioBuffer || opt.src instanceof VoxBuffer) {
                _this.set(opt.src);
                if (!_this.loaded) {
                    _this.onload = opt.onload;
                }
            }
            else if (Vox_1.Vox.isString(opt.src)) {
                _this.load(opt.src).then(opt.onload).catch(opt.onerror);
            }
        }
        return _this;
    }
    VoxBuffer.prototype.set = function (buffer) {
        var _this = this;
        if (buffer instanceof VoxBuffer) {
            if (buffer.loaded) {
                this._buffer = buffer.get();
            }
            else {
                buffer.onload = function () {
                    _this.set(buffer);
                    _this.onload(_this);
                };
            }
        }
        else {
            this._buffer = buffer;
        }
        return this;
    };
    VoxBuffer.prototype.get = function () {
        return this._buffer;
    };
    VoxBuffer.prototype.load = function (url, onload, onerror) {
        var _this = this;
        onload = onload === undefined ? function () { } : onload;
        onerror = onerror === undefined ? function () { } : onerror;
        var promise = new ts_promise_1.default(function (resolve, reject) {
            _this._xhr = VoxBuffer.load(url, function (buffer) {
                _this._xhr = null;
                _this.set(buffer);
                resolve(_this);
                _this.onload(_this);
                if (onload) {
                    onload(_this);
                }
                console.log('buffer', buffer);
            }, function (err) {
                _this._xhr = null;
                console.log('err:', err);
                reject(err);
                if (onerror) {
                    onerror(err);
                }
            });
        });
        return promise;
    };
    Object.defineProperty(VoxBuffer.prototype, "duration", {
        get: function () {
            if (this._buffer) {
                return this._buffer.duration;
            }
            else {
                return 0;
            }
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(VoxBuffer.prototype, "length", {
        get: function () {
            if (this._buffer) {
                return this._buffer.length;
            }
            else {
                return 0;
            }
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(VoxBuffer.prototype, "loaded", {
        get: function () {
            return this.length > 0;
        },
        enumerable: true,
        configurable: true
    });
    VoxBuffer.load = function (url, onload, onerror) {
        function onError(e) {
            VoxBuffer._removeFromDownloadQueue(request);
            if (onerror) {
                onerror(e);
            }
            else {
                throw e;
            }
        }
        function onProgress() {
            var totalProgress = 0;
            for (var i = 0; i < VoxBuffer._downloadQueue.length; i++) {
                totalProgress += VoxBuffer._downloadQueue[i].progress;
            }
            console.log('progress:', totalProgress / VoxBuffer._downloadQueue.length);
        }
        var request = new XMLHttpRequest();
        request.open('GET', url, true);
        request.responseType = 'arraybuffer';
        request.progress = 0;
        VoxBuffer._downloadQueue.push(request);
        request.addEventListener('load', function () {
            if (request.status === 200) {
                console.log('request.response', request.response);
                Vox_1.Vox.context._ctx.decodeAudioData(request.response).then(function (buffer) {
                    request.progress = 1;
                    onProgress();
                    onload(buffer);
                    VoxBuffer._removeFromDownloadQueue(request);
                    if (VoxBuffer._downloadQueue.length === 0) {
                        console.log('all loaded');
                    }
                }).catch(function () {
                    VoxBuffer._removeFromDownloadQueue(request);
                    onError('VoxBuffer: could not decode audio data: ' + url);
                });
            }
            else {
                onError('VoxBuffer: could not locate file: ' + url);
            }
        });
        request.addEventListener('error', onError);
        request.addEventListener('progress', function (event) {
            if (event.lengthComputable) {
                // downloading only go to 95%, the last 5% is when the audio is decoding
                request.progress = (event.loaded / event.total) * 0.95;
                onProgress();
            }
        });
        request.send();
        return request;
    };
    VoxBuffer._removeFromDownloadQueue = function (request) {
        var index = VoxBuffer._downloadQueue.indexOf(request);
        if (index !== -1) {
            VoxBuffer._downloadQueue.splice(index, 1);
        }
    };
    VoxBuffer.cancelDownloads = function () {
        VoxBuffer._downloadQueue.slice().forEach(function (request) {
            VoxBuffer._removeFromDownloadQueue(request);
            request.abort();
        });
        return VoxBuffer;
    };
    VoxBuffer._downloadQueue = [];
    return VoxBuffer;
}(Vox_1.Vox));
exports.VoxBuffer = VoxBuffer;
Vox_1.Vox.VoxBuffer = VoxBuffer;

},{"./Vox":42,"ts-promise":9}],34:[function(require,module,exports){
"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
var Vox_1 = require("./Vox");
var type_1 = require("../type");
var Clock = /** @class */ (function (_super) {
    __extends(Clock, _super);
    function Clock(opt) {
        var _this = _super.call(this) || this;
        _this._nextTick = 0;
        _this._lastUpdate = 0;
        opt = opt === undefined ? {} : opt;
        _this.callback = opt.callback === undefined ? function () { } : opt.callback;
        opt.frequency = opt.callback === undefined ? 1 : opt.frequency;
        _this._tickSource = new Vox_1.Vox.TickSource(opt.frequency);
        _this.frequency = _this._tickSource.frequency;
        _this._state = new Vox_1.Vox.TimelineState(type_1.PlayState.Stopped);
        _this._state.setStateAtTime(type_1.PlayState.Stopped, 0);
        _this._boundLoop = _this._loop.bind(_this);
        Vox_1.Vox.context.on('tick', _this._boundLoop);
        return _this;
    }
    Object.defineProperty(Clock.prototype, "ticks", {
        get: function () {
            return Math.ceil(this._tickSource.getTicksAtTime(this.now()));
        },
        set: function (t) {
            this._tickSource.ticks = t;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(Clock.prototype, "seconds", {
        get: function () {
            return this._tickSource.seconds;
        },
        set: function (s) {
            this._tickSource.seconds = s;
        },
        enumerable: true,
        configurable: true
    });
    Clock.prototype.getSecondsAtTime = function (time) {
        return this._tickSource.getSecondsAtTime(time);
    };
    Clock.prototype.setTicksAtTime = function (ticks, time) {
        this._tickSource.setTicksAtTime(ticks, time);
        return this;
    };
    Clock.prototype.getTicksAtTime = function (time) {
        return this._tickSource.getTicksAtTime(time);
    };
    Clock.prototype._loop = function () {
        var _this = this;
        var startTime = this._lastUpdate;
        var endTime = this.now();
        this._lastUpdate = endTime;
        if (startTime !== endTime) {
            this._state.forEachBetween(startTime, endTime, function (e) {
                var offset = _this._tickSource.getTicksAtTime(e.time);
                console.log('tick(offset),', offset);
                switch (e.state) {
                    case type_1.PlayState.Started:
                        var offset_1 = _this._tickSource.getTicksAtTime(e.time);
                        // console.log('tick(offset),', offset);
                        _this.emit(['start', e.time, offset_1]);
                        break;
                    case type_1.PlayState.Stopped:
                        if (e.time !== 0) {
                            _this.emit(['stop', e.time]);
                        }
                        break;
                    case type_1.PlayState.Paused:
                        _this.emit(['pause', e.time]);
                        break;
                }
            });
            this._tickSource.forEachTickBetween(startTime, endTime, function (time, ticks) {
                // console.log('time', time);
                // console.log('ticks', ticks);
                _this.callback(time, ticks);
            });
        }
    };
    Clock.prototype.getStateAtTime = function (time) {
        time = this.toSeconds(time);
        return this._state.getRecentValueAtTime(time);
    };
    Clock.prototype.start = function (time, offset) {
        Vox_1.Vox.context._ctx.resume();
        time = this.toSeconds(time);
        if (this._state.getRecentValueAtTime(time) !== type_1.PlayState.Started) {
            this._state.setStateAtTime(type_1.PlayState.Started, time);
            this._tickSource.start(time, offset);
            if (time < this._lastUpdate) {
                this.emit(['start', time, offset]);
            }
        }
        return this;
    };
    Clock.prototype.stop = function (time) {
        time = this.toSeconds(time);
        this._state.cancelAfter(time);
        this._state.setStateAtTime(type_1.PlayState.Stopped, time);
        this._tickSource.stop(time);
        if (time < this._lastUpdate) {
            this.emit(['stop', time]);
        }
        return this;
    };
    Clock.prototype.pause = function (time) {
        time = this.toSeconds(time);
        if (this._state.getRecentValueAtTime(time) === type_1.PlayState.Started) {
            this._state.setStateAtTime(type_1.PlayState.Paused, time);
            if (time < this._lastUpdate) {
                this.emit(['pause', time]);
            }
        }
        return this;
    };
    return Clock;
}(Vox_1.Vox));
exports.Clock = Clock;
Vox_1.Vox.Clock = Clock;

},{"../type":48,"./Vox":42}],35:[function(require,module,exports){
"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
var Vox_1 = require("./Vox");
var type_1 = require("../type");
var Ticker = /** @class */ (function () {
    function Ticker(callback, type, updateInterval) {
        this._type = type;
        this._updateInterval = updateInterval;
        this._callback = callback;
        this._createClock();
    }
    Ticker.prototype._createWorker = function () {
        var _this = this;
        var _URL = window.URL || window.webkitURL;
        var blob = new Blob(["\n      //the initial timeout time\n      var timeoutTime = " + (this._updateInterval * 1000).toFixed(1) + ";\n      //onmessage callback\n      self.onmessage = function(msg){\n        timeoutTime = parseInt(msg.data);\n      };\n      //the tick function which posts a message\n      //and schedules a new tick\n      function tick(){\n        setTimeout(tick, timeoutTime);\n        self.postMessage('tick');\n      }\n      //call tick initially\n      tick();\n    "]);
        var blobUrl = _URL.createObjectURL(blob);
        var worker = new Worker(blobUrl);
        worker.onmessage = function () {
            _this._callback();
        };
        this._worker = worker;
    };
    Ticker.prototype._createTimeout = function () {
        var _this = this;
        this._timeout = setTimeout(function () {
            _this._createTimeout();
            _this._callback();
        }, this._updateInterval * 1000);
    };
    Ticker.prototype._createClock = function () {
        if (this._type === type_1.VoxTick.Worker) {
            try {
                this._createWorker();
            }
            catch (e) {
                this._type = type_1.VoxTick.Timeout;
                this._createTimeout();
            }
        }
        else if (this._type === type_1.VoxTick.Timeout) {
            this._createTimeout();
        }
    };
    Ticker.prototype._disposeClock = function () {
        if (this._timeout) {
            clearTimeout(this._timeout);
            this._timeout = null;
        }
        if (this._worker) {
            this._worker.terminate();
            this._worker.onmessage = null;
            this._worker = null;
        }
    };
    Ticker.prototype.dispose = function () {
        this._disposeClock();
        this._callback = null;
    };
    return Ticker;
}());
var VoxContext = /** @class */ (function (_super) {
    __extends(VoxContext, _super);
    function VoxContext(context, opt) {
        var _this = _super.call(this) || this;
        _this._ctx = context;
        opt = (opt === undefined ? {} : opt);
        opt.clockSrc = (opt.clockSrc === undefined ? type_1.VoxTick.Worker : opt.clockSrc);
        opt.latencyHint = (opt.latencyHint === undefined ? 'interactive' : opt.latencyHint);
        opt.lookAhead = (opt.lookAhead === undefined ? 0.1 : opt.lookAhead);
        opt.updateInterval = (opt.updateInterval === undefined ? 0.03 : opt.updateInterval);
        _this._latencyHint = opt.latencyHint;
        _this._constants = {};
        _this.lookAhead = opt.lookAhead;
        _this._computedUpdateInterval = 0;
        _this.timeoutLoop = _this.timeoutLoop.bind(_this);
        _this._ticker = new Ticker(function () {
            _this.emit(['tick']);
        }, opt.clockSrc, opt.updateInterval);
        _this._timeouts = new Vox_1.Vox.Timeline(Infinity);
        _this._timeoutIds = 0;
        _this.on('tick', _this.timeoutLoop);
        _this._ctx.onstatechange = function (e) {
            console.log('stagechange', e);
        };
        return _this;
    }
    VoxContext.prototype.now = function () {
        return this._ctx.currentTime + this.lookAhead;
    };
    VoxContext.prototype.timeoutLoop = function () {
        var now = this.now();
        while (this._timeouts && this._timeouts.length && this._timeouts.peek().time <= now) {
            this._timeouts.shift().callback();
        }
    };
    VoxContext.prototype.setTimeout = function (fn, timeout) {
        this._timeoutIds++;
        var now = this.now();
        this._timeouts.add({
            callback: fn,
            time: now + timeout,
            id: this._timeoutIds,
        });
    };
    VoxContext.prototype.clearTimeout = function (id) {
    };
    return VoxContext;
}(Vox_1.Vox));
exports.VoxContext = VoxContext;
Vox_1.Vox.VoxContext = VoxContext;
if (!(Vox_1.Vox.context instanceof VoxContext)) {
    Vox_1.Vox.context = new VoxContext(new AudioContext());
    console.log('create context');
}
else {
    console.log('context already exist');
}

},{"../type":48,"./Vox":42}],36:[function(require,module,exports){
"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
var Vox_1 = require("./Vox");
var VoxGain = /** @class */ (function (_super) {
    __extends(VoxGain, _super);
    function VoxGain(gain, units) {
        var _this = _super.call(this) || this;
        _this.input = _this.output = _this._gainNode = _this.context._ctx.createGain();
        _this.gain = new Vox_1.Vox.VoxAudioParam({
            param: _this._gainNode.gain,
            units: units,
            convert: true,
            value: gain,
        });
        return _this;
    }
    return VoxGain;
}(Vox_1.Vox.VoxAudioNode));
exports.VoxGain = VoxGain;
Vox_1.Vox.VoxGain = VoxGain;

},{"./Vox":42}],37:[function(require,module,exports){
"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
var Vox_1 = require("./Vox");
var VoxMaster = /** @class */ (function (_super) {
    __extends(VoxMaster, _super);
    function VoxMaster() {
        var _this = _super.call(this) || this;
        _this.createInsOuts(1, 0);
        _this._volume = _this.output = new Vox_1.Vox.Volume(1);
        _this.volume = _this._volume.volume;
        Vox_1.Vox.connect(_this.input, _this.output);
        Vox_1.Vox.connect(_this.output, _this.context._ctx.destination);
        _this.context.master = _this;
        return _this;
    }
    Object.defineProperty(VoxMaster.prototype, "mute", {
        get: function () {
            return this._volume.mute;
        },
        set: function (val) {
            this._volume.mute = val;
        },
        enumerable: true,
        configurable: true
    });
    return VoxMaster;
}(Vox_1.Vox.VoxAudioNode));
exports.VoxMaster = VoxMaster;
if (!(Vox_1.Vox.VoxMaster instanceof VoxMaster)) {
    Vox_1.Vox.VoxMaster = new VoxMaster();
    console.log('create context');
}
else {
    console.log('context already exist');
}

},{"./Vox":42}],38:[function(require,module,exports){
"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
var Vox_1 = require("./Vox");
;
var Timeline = /** @class */ (function (_super) {
    __extends(Timeline, _super);
    function Timeline(memory) {
        var _this = _super.call(this) || this;
        _this._timeline = [];
        _this.memory = memory;
        return _this;
    }
    Object.defineProperty(Timeline.prototype, "length", {
        get: function () {
            return this._timeline.length;
        },
        enumerable: true,
        configurable: true
    });
    Timeline.prototype.add = function (event) {
        if (Vox_1.Vox.isUndef(event)) {
            throw new Error('Timeline: add events must have a time attribute');
        }
        if (event.time instanceof Vox_1.Vox.Ticks) {
            console.log('Ticks:', event.time, '->', event.time.valueOf());
        }
        event.time = event.time.valueOf();
        // 按照时间先后插入
        var idx = this._searchAloneTime(event.time);
        this._timeline.splice(idx + 1, 0, event);
        if (idx > this.memory) {
            var overflow = this.length - this.memory;
            this._timeline.splice(0, overflow);
        }
        return this;
    };
    Timeline.prototype.remove = function (event) {
        var index = this._timeline.indexOf(event);
        if (index !== -1) {
            this._timeline.splice(index, 1);
        }
        return this;
    };
    // 在时间线上查找某个时间点
    Timeline.prototype._searchAloneTime = function (time, field) {
        field = field === undefined ? 'time' : field;
        if (this._timeline.length === 0) {
            return -1;
        }
        var len = this._timeline.length;
        var start = 0;
        var end = len;
        if (len > 0 && this._timeline[len - 1][field] <= time) {
            return len - 1;
        }
        while (start < end) {
            var mid = Math.floor(start + (end - start) / 2);
            var event_1 = this._timeline[mid];
            var nextEv = this._timeline[mid + 1];
            if (event_1[field] === time) {
                for (var i = mid; i < this._timeline.length; i++) {
                    if (this._timeline[i][field] === time) {
                        mid = i;
                    }
                }
                return mid;
            }
            else if (event_1[field] < time && nextEv[field] > time) {
                return mid;
            }
            else if (event_1[field] > time) {
                end = mid;
            }
            else {
                start = mid + 1;
            }
        }
        return -1;
    };
    Timeline.prototype.getAfter = function (time, field) {
        var idx = this._searchAloneTime(time, field);
        if (idx + 1 < this._timeline.length) {
            return this._timeline[idx + 1];
        }
        else {
            return null;
        }
    };
    Timeline.prototype.getMostRecent = function (time, field) {
        var idx = this._searchAloneTime(time, field);
        if (idx !== -1) {
            return this._timeline[idx];
        }
        else {
            return null;
        }
    };
    Timeline.prototype.getBefore = function (time, field) {
        field = field === undefined ? 'time' : field;
        var len = this._timeline.length;
        if (len > 0 && this._timeline[len - 1][field] < time) {
            return this._timeline[len - 1];
        }
        var index = this._searchAloneTime(time);
        if (index - 1 >= 0) {
            return this._timeline[index - 1];
        }
        else {
            return null;
        }
    };
    Timeline.prototype.peek = function () {
        return this._timeline[0];
    };
    Timeline.prototype.shift = function () {
        return this._timeline.shift();
    };
    Timeline.prototype.cancelAfter = function (after) {
        if (this._timeline.length > 1) {
            var idx = this._searchAloneTime(after);
            if (idx >= 0) {
                if (this._timeline[idx].time === after) {
                    for (var i = idx; i >= 0; i--) {
                        if (this._timeline[i].time === after) {
                            idx = i;
                        }
                        else {
                            break;
                        }
                    }
                    this._timeline = this._timeline.slice(0, idx);
                }
                else {
                    this._timeline = this._timeline.slice(0, idx + 1);
                }
            }
            else {
                this._timeline = [];
            }
        }
        else if (this._timeline.length === 1) {
            if (this._timeline[0].time >= after) {
                this._timeline = [];
            }
        }
        return this;
    };
    Timeline.prototype.cancelBefore = function (time) {
        var idx = this._searchAloneTime(time);
        if (idx >= 0) {
            this._timeline = this._timeline.slice(idx + 1);
        }
        return this;
    };
    Timeline.prototype._iterate = function (callback, begin, end) {
        var _this = this;
        begin = begin === undefined ? 0 : begin;
        end = end === undefined ? this._timeline.length - 1 : end;
        this._timeline.slice(begin, end + 1).forEach(function (event) {
            callback.call(_this, event);
        });
    };
    Timeline.prototype.forEach = function (callback) {
        this._iterate(callback);
        return this;
    };
    Timeline.prototype.forEachBefore = function (time, callback) {
        var end = this._searchAloneTime(time);
        if (end !== -1) {
            this._iterate(callback, 0, end);
        }
        return this;
    };
    Timeline.prototype.forEachAfter = function (time, callback) {
        var start = this._searchAloneTime(time);
        this._iterate(callback, start + 1);
        return this;
    };
    Timeline.prototype.forEachBetween = function (startTime, endTime, callback) {
        var end = this._searchAloneTime(endTime);
        var start = this._searchAloneTime(startTime);
        if (start !== -1 && end !== -1) {
            if (this._timeline[start].time !== startTime) {
                start += 1;
            }
            if (this._timeline[end].time === endTime) {
                end -= 1;
            }
            this._iterate(callback, start, end);
        }
        else if (start === -1) {
            this._iterate(callback, 0, end);
        }
        return this;
    };
    Timeline.prototype.forEachAtTime = function (time, callback) {
        var end = this._searchAloneTime(time);
        if (end !== -1) {
            this._iterate(function (event) {
                if (event.time === time) {
                    callback.call(this, event);
                }
            }, 0, end);
        }
        return this;
    };
    Timeline.prototype.previousEvent = function (event) {
        var index = this._timeline.indexOf(event);
        if (index > 0) {
            return this._timeline[index - 1];
        }
        else {
            return null;
        }
    };
    return Timeline;
}(Vox_1.Vox));
exports.Timeline = Timeline;
Vox_1.Vox.Timeline = Timeline;

},{"./Vox":42}],39:[function(require,module,exports){
"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
var Vox_1 = require("./Vox");
var TimelineState = /** @class */ (function (_super) {
    __extends(TimelineState, _super);
    function TimelineState(initialState) {
        var _this = _super.call(this, Infinity) || this;
        _this._initialState = initialState;
        return _this;
    }
    TimelineState.prototype.getRecentValueAtTime = function (time) {
        var timelineEvent = this.getMostRecent(time);
        if (timelineEvent !== null) {
            return timelineEvent.state;
        }
        else {
            return this._initialState;
        }
    };
    TimelineState.prototype.setStateAtTime = function (state, time) {
        this.add({
            state: state,
            time: time,
        });
        return this;
    };
    TimelineState.prototype.getLastState = function (state, time) {
        time = this.toSeconds(time);
        var idx = this._searchAloneTime(time);
        for (var i = idx; i >= 0; i--) {
            var timelineEvent = this._timeline[i];
            if (timelineEvent.state === state) {
                return timelineEvent;
            }
        }
    };
    TimelineState.prototype.getNextState = function (state, time) {
        time = this.toSeconds(time);
        var idx = this._searchAloneTime(time);
        if (idx !== -1) {
            for (var i = idx; i < this._timeline.length; i++) {
                var timelineEvent = this._timeline[i];
                if (timelineEvent.state === state) {
                    return timelineEvent;
                }
            }
        }
    };
    return TimelineState;
}(Vox_1.Vox.Timeline));
exports.TimelineState = TimelineState;
Vox_1.Vox.TimelineState = TimelineState;

},{"./Vox":42}],40:[function(require,module,exports){
"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
var Vox_1 = require("./Vox");
var type_1 = require("../type");
var TransportCtrl = /** @class */ (function (_super) {
    __extends(TransportCtrl, _super);
    function TransportCtrl() {
        var _this = _super.call(this) || this;
        _this.loop = false;
        _this._loopEnd = 0;
        _this._loopStart = 0;
        _this._ppq = TransportCtrl.default.PPQ;
        _this._clock = new Vox_1.Vox.Clock({
            callback: _this._processTick.bind(_this),
            frequency: 0,
        });
        _this._bindClockEvents();
        _this.bpm = _this._clock.frequency;
        _this.bpm._toUnits = _this._toUnits.bind(_this);
        _this.bpm._fromUnits = _this._fromUnits.bind(_this);
        _this.bpm.units = type_1.VoxType.BPM;
        _this.bpm.value = TransportCtrl.default.bpm;
        _this._timeSignature = TransportCtrl.default.timeSignature;
        _this._secheduleEvents = {};
        _this._timeline = new Vox_1.Vox.Timeline(Infinity);
        _this._swingTicks = TransportCtrl.default.PPQ;
        _this._swingAmount = 0;
        return _this;
    }
    Object.defineProperty(TransportCtrl.prototype, "state", {
        get: function () {
            return this._clock.getStateAtTime(this.now());
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(TransportCtrl.prototype, "ticks", {
        get: function () {
            return this._clock.ticks;
        },
        set: function (t) {
            if (this._clock.ticks !== t) {
                var now = this.now();
                if (this.state === type_1.PlayState.Started) {
                    this.emit(['stop', now]);
                    this._clock.setTicksAtTime(t, now);
                    this.emit(['start', now, this.seconds]);
                }
                else {
                    this._clock.setTicksAtTime(t, now);
                }
            }
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(TransportCtrl.prototype, "seconds", {
        get: function () {
            return this._clock.seconds;
        },
        set: function (s) {
            var now = this.now();
            var ticks = this.bpm.timeToTicks(s, now);
            this.ticks = ticks.valueOf();
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(TransportCtrl.prototype, "timeSignature", {
        get: function () {
            return this._timeSignature;
        },
        set: function (timeSig) {
            if (Array.isArray(timeSig)) {
                timeSig = (timeSig[0] / timeSig[1]) * 4;
            }
            this._timeSignature = timeSig;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(TransportCtrl.prototype, "PPQ", {
        get: function () {
            return this._ppq;
        },
        set: function (value) {
            var bpm = this.bpm.value;
            this._ppq = value;
            // 通过 param 的 value setter 重新设置
            this.bpm.value = bpm;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(TransportCtrl.prototype, "loopStart", {
        get: function () {
            return (new Vox_1.Vox.Ticks(this._loopStart)).toSeconds();
        },
        set: function (startPosition) {
            this._loopStart = this.toTicks(startPosition);
        },
        enumerable: true,
        configurable: true
    });
    TransportCtrl.prototype._processTick = function (tickTime, ticks) {
        // console.log('_processTick');
        if (this.loop) {
            if (ticks >= this._loopEnd) {
                this.emit(['loopEnd', tickTime]);
                this._clock.setTicksAtTime(this._loopStart, tickTime);
                ticks = this._loopStart;
                this.emit(['loopStart', tickTime, this._clock.getSecondsAtTime(tickTime)]);
                this.emit(['loop', tickTime]);
            }
        }
        this._timeline.forEachAtTime(ticks, function (event) {
            event.invoke(tickTime);
        });
    };
    TransportCtrl.prototype.schedule = function (callback, time) {
        var event = new Vox_1.Vox.TransportEvent(this, {
            time: (new Vox_1.Vox.TransportTime(time)),
            callback: callback,
        });
        console.log(event);
        return this._addEvent(event, this._timeline);
    };
    TransportCtrl.prototype.scheduleOnce = function (callback, time) {
        var event = new Vox_1.Vox.TransportEvent(this, {
            time: new Vox_1.Vox.TransportTime(time),
            callback: callback,
            once: true,
        });
        return this._addEvent(event, this._timeline);
    };
    TransportCtrl.prototype.clear = function (eventId) {
        if (this._secheduleEvents.hasOwnProperty(eventId)) {
            var item = this._secheduleEvents[eventId.toString()];
            item.timeline.remove(item.event);
            item.event.dispose();
            delete this._secheduleEvents[eventId.toString()];
        }
        return this;
    };
    TransportCtrl.prototype._addEvent = function (event, timeline) {
        this._secheduleEvents[event.id.toString()] = {
            event: event,
            timeline: timeline,
        };
        timeline.add(event);
        return event.id;
    };
    TransportCtrl.prototype.cancelAfter = function (time) {
        time = time === undefined ? 0 : time;
    };
    TransportCtrl.prototype._bindClockEvents = function () {
        var _this = this;
        this._clock.on('start', function (time, offset) {
            offset = (new Vox_1.Vox.Ticks(offset)).toSeconds();
            _this.emit(['start', time, offset]);
        });
        this._clock.on('stop', function (time) {
            _this.emit(['stop', time]);
        });
        this._clock.on('pause', function (time) {
            _this.emit(['pause', time]);
        });
    };
    TransportCtrl.prototype._fromUnits = function (bpm) {
        return 1 / (60 / bpm / this.PPQ);
    };
    // convert from frequency into BPM
    TransportCtrl.prototype._toUnits = function (freq) {
        return (freq / this.PPQ) * 60;
    };
    TransportCtrl.prototype.start = function (time, offset) {
        if (Vox_1.Vox.isDefined(offset)) {
            offset = this.toTicks(offset);
        }
        this._clock.start(time, offset);
        return this;
    };
    TransportCtrl.prototype.stop = function (time) {
        this._clock.stop(time);
        return this;
    };
    TransportCtrl.default = {
        bpm: 120,
        swing: 0,
        swingSubdivision: "8n",
        timeSignature: 4,
        loopStart: 0,
        loopEnd: "4m",
        PPQ: 192
    };
    return TransportCtrl;
}(Vox_1.Vox));
exports.TransportCtrl = TransportCtrl;
if (Vox_1.Vox.VoxTransportCtrl === undefined) {
    Vox_1.Vox.VoxTransportCtrl = new TransportCtrl();
}

},{"../type":48,"./Vox":42}],41:[function(require,module,exports){
"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
var Vox_1 = require("./Vox");
var TransportEvent = /** @class */ (function (_super) {
    __extends(TransportEvent, _super);
    function TransportEvent(transportCtrl, opt) {
        var _this = _super.call(this) || this;
        _this.callback = function (time) { };
        _this.transportCtrl = transportCtrl;
        opt = opt === undefined ? {} : opt;
        _this._once = opt.once === undefined ? false : opt.once;
        _this.callback = opt.callback === undefined ? function () { } : opt.callback;
        _this.id = Vox_1.Vox.TransportEvent._eventId++;
        _this.time = new Vox_1.Vox.Ticks(opt.time);
        return _this;
    }
    TransportEvent.prototype.invoke = function (time) {
        if (this.callback) {
            this.callback(time);
            if (this._once && this.transportCtrl) {
                this.transportCtrl.clear(this.id);
            }
        }
    };
    TransportEvent._eventId = 0;
    return TransportEvent;
}(Vox_1.Vox));
exports.TransportEvent = TransportEvent;
Vox_1.Vox.TransportEvent = TransportEvent;

},{"./Vox":42}],42:[function(require,module,exports){
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var AudioNode_1 = require("./AudioNode");
var util_1 = require("util");
var Vox = /** @class */ (function () {
    function Vox() {
        this.name = 'vox';
        this._events = {};
    }
    Vox.prototype.toString = function () {
    };
    Vox.prototype.toSeconds = function (time) {
        if (Vox.isNumber(time)) {
            return time;
        }
        else if (Vox.isUndef(time)) {
            return this.now();
        }
        else if (Vox.isString(time)) {
            return (new Vox.Time(time)).toSeconds();
        }
    };
    Vox.prototype.toFrequency = function (freq) {
        console.log('in toFrequency', freq);
        if (util_1.isNumber(freq)) {
            return freq;
        }
        else if (Vox.isString(freq) || util_1.isUndefined(freq)) {
            return (new Vox.Frequency(freq)).valueOf();
        }
        else if (freq.TimeObject === true) {
            return freq.toFrequency();
        }
    };
    Vox.prototype.toTicks = function (time) {
        if (Vox.isNumber(time) || Vox.isString(time)) {
            return;
        }
        else if (Vox.isUndef(time)) {
            return Vox.VoxTransportCtrl.ticks;
        }
        else if (time.TimeObject === true) {
            return time.toTicks();
        }
    };
    Vox.prototype.now = function () {
        return Vox.context.now();
    };
    Object.defineProperty(Vox.prototype, "sampleTime", {
        get: function () {
            return 1 / Vox.context._ctx.sampleRate;
        },
        enumerable: true,
        configurable: true
    });
    Vox.connect = function (srcNode, dstNode, outputNumber, inputNumber) {
        outputNumber = (outputNumber === undefined ? 0 : outputNumber);
        inputNumber = (inputNumber === undefined ? 0 : inputNumber);
        while (Vox.isDefined(dstNode.input)) {
            if (Array.isArray(dstNode.input)) {
                dstNode = dstNode.input[inputNumber];
                inputNumber = 0;
            }
            else if (dstNode.input) {
                dstNode = dstNode.input;
            }
        }
        if (dstNode instanceof AudioParam) {
            srcNode.connect(dstNode, outputNumber);
        }
        else if (dstNode instanceof AudioNode) {
            srcNode.connect(dstNode, outputNumber, inputNumber);
        }
        return Vox;
    };
    Vox.disconnect = function (srcNode, dstNode, outputNumber, inputNumber) {
        if (dstNode) {
            if (Vox.isDefined(dstNode.input) && (dstNode instanceof AudioNode_1.VoxAudioNode)) {
                if (Array.isArray(dstNode.input)) {
                    if (Vox.isDefined(inputNumber)) {
                        Vox.disconnect(srcNode, dstNode.input[inputNumber], outputNumber);
                    }
                    else {
                        dstNode.input.forEach(function (dstNode) {
                            Vox.disconnect(srcNode, dstNode, outputNumber);
                        });
                    }
                }
                else if (dstNode.input) {
                    dstNode = dstNode.input;
                }
            }
            if (dstNode instanceof AudioParam) {
                srcNode.disconnect(dstNode, outputNumber, inputNumber);
            }
            else if (dstNode instanceof AudioNode) {
                srcNode.disconnect(dstNode, outputNumber, inputNumber);
            }
        }
        else {
            srcNode.disconnect();
        }
        return Vox;
    };
    Vox.isUndef = function (val) {
        return typeof val === "undefined";
    };
    Vox.isDefined = function (val) {
        return !Vox.isUndef(val);
    };
    Vox.isFunction = function (val) {
        return typeof val === "function";
    };
    Vox.isNumber = function (arg) {
        return (typeof arg === "number");
    };
    Vox.isString = function (arg) {
        return (typeof arg === 'string');
    };
    Vox.isNote = function (arg) {
        return Vox.isString(arg) && /^([a-g]{1}(?:b|#|x|bb)?)(-?[0-9]+)/i.test(arg);
    };
    ;
    Vox.prototype.gainToDb = function (value) {
        return 20 * (Math.log(value) / Math.LN10);
    };
    Vox.prototype.dbToGain = function (db) {
        return Math.pow(10, db / 20);
    };
    Vox.prototype.on = function (event, callback) {
        if (!this._events.hasOwnProperty(event)) {
            this._events[event] = [];
        }
        this._events[event].push(callback);
        return this;
    };
    Vox.prototype.once = function (event, callback) {
        var self = this;
        function onceWrapper() {
            callback.apply(self, arguments);
            self.off(event, onceWrapper);
        }
        this.on(event, onceWrapper);
        return this;
    };
    Vox.prototype.off = function (event, callback) {
        if (this._events.hasOwnProperty(event)) {
            if (Vox.isUndef(callback)) {
                this._events[event] = [];
            }
            else {
                var listeners = this._events[event];
                if (listeners) {
                    for (var i = 0; i < listeners.length; i++) {
                        if (callback === listeners[i]) {
                            listeners.splice(i, 1);
                        }
                    }
                }
            }
        }
        return this;
    };
    Vox.prototype.emit = function (params) {
        var event = params[0];
        if (this._events) {
            var args = Array.apply(null, params).slice(1);
            if (this._events.hasOwnProperty(event)) {
                var eventList = this._events[event].slice(0);
                for (var i = 0, len = eventList.length; i < len; i++) {
                    eventList[i].apply(this, args);
                }
            }
        }
        return this;
    };
    return Vox;
}());
exports.Vox = Vox;

},{"./AudioNode":31,"util":14}],43:[function(require,module,exports){
"use strict";
function __export(m) {
    for (var p in m) if (!exports.hasOwnProperty(p)) exports[p] = m[p];
}
Object.defineProperty(exports, "__esModule", { value: true });
__export(require("./core/AudioNode"));
__export(require("./core/AudioParam"));
__export(require("./core/Timeline"));
__export(require("./core/TimelineState"));
__export(require("./core/Buffer"));
__export(require("./core/Gain"));
__export(require("./components/Volume"));
__export(require("./components/Envelope"));
__export(require("./components/AmplitudeEnvelope"));
__export(require("./components/TickCounter"));
__export(require("./signal/Signal"));
__export(require("./audioSource/Source"));
__export(require("./audioSource/TickSource"));
__export(require("./audioSource/BufferSource"));
__export(require("./audioSource/Player"));
__export(require("./audioSource/OscillatorNode"));
__export(require("./audioSource/Oscillator"));
// export * from './core/TimeBase';
// export * from './core/Time';
// export * from './core/Frequency';
// export * from './core/TransportTime';
// export * from './core/Ticks';
__export(require("./Time/Time"));
__export(require("./Time/Frequency"));
__export(require("./Time/TransportTime"));
__export(require("./Time/Ticks"));
__export(require("./instrument/Instrument"));
__export(require("./instrument/Monophonic"));
__export(require("./instrument/Synth"));
__export(require("./core/Context"));
__export(require("./core/Master"));
__export(require("./core/Clock"));
__export(require("./core/TransportEvent"));
__export(require("./core/TransportCtrl"));
__export(require("./core/Vox"));

},{"./Time/Frequency":16,"./Time/Ticks":18,"./Time/Time":19,"./Time/TransportTime":20,"./audioSource/BufferSource":21,"./audioSource/Oscillator":22,"./audioSource/OscillatorNode":23,"./audioSource/Player":24,"./audioSource/Source":25,"./audioSource/TickSource":26,"./components/AmplitudeEnvelope":27,"./components/Envelope":28,"./components/TickCounter":29,"./components/Volume":30,"./core/AudioNode":31,"./core/AudioParam":32,"./core/Buffer":33,"./core/Clock":34,"./core/Context":35,"./core/Gain":36,"./core/Master":37,"./core/Timeline":38,"./core/TimelineState":39,"./core/TransportCtrl":40,"./core/TransportEvent":41,"./core/Vox":42,"./instrument/Instrument":44,"./instrument/Monophonic":45,"./instrument/Synth":46,"./signal/Signal":47}],44:[function(require,module,exports){
"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
var Vox_1 = require("../core/Vox");
var Instrument = /** @class */ (function (_super) {
    __extends(Instrument, _super);
    function Instrument(opt) {
        var _this = _super.call(this) || this;
        opt = opt === undefined ? {} : opt;
        opt.volume = opt.volume === undefined ? 0 : opt.volume;
        _this._volume = _this.output = new Vox_1.Vox.Volume(opt.volume);
        _this.volume = _this._volume.volume;
        return _this;
    }
    Instrument.prototype.triggerAttackRelease = function (note, duration, time, velocity) {
        time = this.toSeconds(time);
        duration = this.toSeconds(duration);
        this.triggerAttack(note, time, velocity);
        this.triggerRelease(time + duration);
        return this;
    };
    return Instrument;
}(Vox_1.Vox.VoxAudioNode));
exports.Instrument = Instrument;
Vox_1.Vox.Instrument = Instrument;

},{"../core/Vox":42}],45:[function(require,module,exports){
"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
var Vox_1 = require("../core/Vox");
var Monophonic = /** @class */ (function (_super) {
    __extends(Monophonic, _super);
    function Monophonic(opt) {
        var _this = this;
        opt = opt === undefined ? {} : opt;
        opt.portamento = opt.portamento === undefined ? 0 : opt.portamento;
        _this = _super.call(this, opt) || this;
        // 滑音
        _this.portamento = opt.portamento;
        return _this;
    }
    Monophonic.prototype.getLevelAtTime = function (time) {
        time = this.toSeconds(time);
        return this.envelope.getValueAtTime(time);
    };
    Monophonic.prototype.triggerAttack = function (note, time, velocity) {
        time = this.toSeconds(time);
        time = this.toSeconds(time);
        this._triggerEnvelopeAttack(time, velocity);
        this.setNote(note, time);
        return this;
    };
    Monophonic.prototype.triggerRelease = function (time) {
        time = this.toSeconds(time);
        this._triggerEnvelopeRelease(time);
        return this;
    };
    Monophonic.prototype.setNote = function (note, time) {
        time = this.toSeconds(time);
        if (this.portamento > 0 && this.getLevelAtTime(time) > 0.05) {
            var portTime = this.toSeconds(this.portamento);
            this.frequency.exponentialRampTo(note, portTime, time);
        }
        else {
            this.frequency.setValueAtTime(note, time);
        }
        return this;
    };
    return Monophonic;
}(Vox_1.Vox.Instrument));
exports.Monophonic = Monophonic;
Vox_1.Vox.Monophonic = Monophonic;

},{"../core/Vox":42}],46:[function(require,module,exports){
"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
var Vox_1 = require("../core/Vox");
var Monophonic_1 = require("./Monophonic");
var type_1 = require("../type");
var Synth = /** @class */ (function (_super) {
    __extends(Synth, _super);
    function Synth(opt) {
        var _this = _super.call(this, opt) || this;
        opt = opt === undefined ? {} : opt;
        opt.oscillator = opt.oscillator == undefined ? { type: type_1.OscilType.triangle } : opt.oscillator;
        opt.envelope = opt.envelope === undefined ? {} : opt.envelope;
        opt.envelope.attack = opt.envelope.attack === undefined ? 0.005 : opt.envelope.attack;
        opt.envelope.decay = opt.envelope.decay === undefined ? 0.1 : opt.envelope.decay;
        opt.envelope.sustain = opt.envelope.sustain === undefined ? 0.3 : opt.envelope.sustain;
        opt.envelope.release = opt.envelope.release === undefined ? 1 : opt.envelope.release;
        _this.oscillator = new Vox_1.Vox.Oscillator(opt.oscillator);
        _this.frequency = _this.oscillator.frequency;
        _this.detuen = _this.oscillator.detune;
        _this.envelope = new Vox_1.Vox.AmplitudeEnvelope(opt.envelope);
        _this.oscillator.connect(_this.envelope);
        _this.envelope.connect(_this.output);
        return _this;
    }
    Synth.prototype._triggerEnvelopeAttack = function (time, velocity) {
        this.envelope.triggerAttack(time, velocity);
        this.oscillator.start(time);
        if (this.envelope.sustain === 0) {
            this.oscillator.stop(time + this.envelope.attack + this.envelope.decay);
        }
        return this;
    };
    Synth.prototype._triggerEnvelopeRelease = function (time) {
        time = this.toSeconds(time);
        this.envelope.triggerRelease(time);
        this.oscillator.stop(time + this.envelope.release);
        return this;
    };
    return Synth;
}(Monophonic_1.Monophonic));
exports.Synth = Synth;
Vox_1.Vox.Synth = Synth;

},{"../core/Vox":42,"../type":48,"./Monophonic":45}],47:[function(require,module,exports){
"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
/**
 * 信号系统中，一个节点的值不仅仅可以用简单的类型设置，也可以
 * 使用另一个信号进行调制
 */
var Vox_1 = require("../core/Vox");
var type_1 = require("../type");
var Signal = /** @class */ (function (_super) {
    __extends(Signal, _super);
    function Signal(opt) {
        var _this = this;
        opt = opt === undefined ? {} : opt;
        opt.units = opt.units === undefined ? type_1.VoxType.Default : opt.units;
        opt.value = opt.value === undefined ? 0 : opt.value;
        _this = _super.call(this, { value: opt.value, units: opt.units }) || this;
        _this._constantSource = _this.context._ctx.createConstantSource();
        _this._constantSource.start(0);
        _this._param = _this._constantSource.offset;
        _this.value = opt.value;
        _this.output = _this._constantSource;
        _this.input = _this._param = _this.output.offset;
        _this.disconnect = Vox_1.Vox.VoxAudioNode.prototype.disconnect.bind(_this);
        return _this;
    }
    Signal.prototype.connect = function (node, outputNumber, inputNumber) {
        console.log('signal Connect');
        if (node.constructor === Vox_1.Vox.Signal || node.constructor === Vox_1.Vox.VoxAudioParam) {
            node._param.cancelScheduledValues(0);
            node._param.setValueAtTime(0, 0);
            node.overridden = true;
        }
        else if (node instanceof AudioParam) {
            node.cancelScheduledValues(0);
            node.setValueAtTime(0, 0);
        }
        Vox_1.Vox.VoxAudioNode.prototype.connect.call(this, node, outputNumber, inputNumber);
        return this;
    };
    Signal.prototype.getValueAtTime = function (time) {
        return Vox_1.Vox.VoxAudioParam.prototype.getValueAtTime.call(this, time);
    };
    return Signal;
}(Vox_1.Vox.VoxAudioParam));
exports.Signal = Signal;
Vox_1.Vox.Signal = Signal;

},{"../core/Vox":42,"../type":48}],48:[function(require,module,exports){
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var VoxType;
(function (VoxType) {
    VoxType[VoxType["Default"] = 0] = "Default";
    VoxType[VoxType["Time"] = 1] = "Time";
    VoxType[VoxType["Frequency"] = 2] = "Frequency";
    VoxType[VoxType["Decibels"] = 3] = "Decibels";
    VoxType[VoxType["BPM"] = 4] = "BPM";
    VoxType[VoxType["Positive"] = 5] = "Positive";
    VoxType[VoxType["Cents"] = 6] = "Cents";
    VoxType[VoxType["Ticks"] = 7] = "Ticks";
})(VoxType = exports.VoxType || (exports.VoxType = {}));
var VoxTick;
(function (VoxTick) {
    VoxTick[VoxTick["Worker"] = 0] = "Worker";
    VoxTick[VoxTick["Timeout"] = 1] = "Timeout";
    VoxTick[VoxTick["Offline"] = 2] = "Offline";
})(VoxTick = exports.VoxTick || (exports.VoxTick = {}));
var PlayState;
(function (PlayState) {
    PlayState[PlayState["Started"] = 0] = "Started";
    PlayState[PlayState["Stopped"] = 1] = "Stopped";
    PlayState[PlayState["Paused"] = 2] = "Paused";
})(PlayState = exports.PlayState || (exports.PlayState = {}));
var FadeCurve;
(function (FadeCurve) {
    FadeCurve[FadeCurve["Linear"] = 0] = "Linear";
    FadeCurve[FadeCurve["Exponential"] = 1] = "Exponential";
})(FadeCurve = exports.FadeCurve || (exports.FadeCurve = {}));
exports.OscilType = {
    sine: 'sine',
    square: 'square',
    triangle: 'triangle',
    sawtooth: 'sawtooth',
    custom: 'custom',
};

},{}]},{},[15]);
